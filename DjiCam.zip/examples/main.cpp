#include "djicam/djicam.h"
#include <opencv2/opencv.hpp>
#include <csignal>
#include <unistd.h>
#include <cstdio>
#include <ctime>
#include <sys/stat.h>   // mkdir

static volatile bool g_running = true;
static const char *kSaveDir = "/root/Temp";

static void SaveFrame(const cv::Mat &mat)
{
    time_t t = time(nullptr);
    tm *lt = localtime(&t);
    char filename[256];
    snprintf(filename, sizeof(filename), "%s/frame_%04d%02d%02d_%02d%02d%02d.jpg",
             kSaveDir,
             lt->tm_year + 1900, lt->tm_mon + 1, lt->tm_mday,
             lt->tm_hour, lt->tm_min, lt->tm_sec);

    if (cv::imwrite(filename, mat)) {
        printf("saved: %s\n", filename);
    } else {
        fprintf(stderr, "save failed: %s\n", filename);
    }
}

static void OnFrame(const djicam::Image &img, const djicam::FlightData &fd)
{
    cv::Mat mat(img.height, img.width, CV_8UC3,
                const_cast<uint8_t *>(img.data.data()), img.width * 3);
    cv::cvtColor(mat, mat, cv::COLOR_RGB2BGR);

    if (fd.valid) {
        printf("lon=%.7f lat=%.7f alt=%.2fm  pitch=%.2f roll=%.2f yaw=%.2f\n",
               fd.longitude, fd.latitude, fd.altitude, fd.pitch, fd.roll, fd.yaw);
    } else {
        printf("flight data not ready yet (no gps fix / not subscribed).\n");
    }

    cv::imshow("MAIN_CAM", mat);
    int key = cv::waitKey(1);
    if (key == 's' || key == 'S') {
        SaveFrame(mat);
    }
}

static void OnSigint(int)
{
    g_running = false;
}

int main(int argc, char **argv)
{
    std::signal(SIGINT, OnSigint);
    if (!djicam::Init(argc, argv)) {
        fprintf(stderr, "djicam init failed, see Logs/ for detail.\n");
        return -1;
    }

    if (!djicam::StartCamera(djicam::CAMERA_MAIN, OnFrame)) {
        fprintf(stderr, "start main camera failed.\n");
        djicam::Deinit();
        return -1;
    }

    while (g_running) {
        sleep(1);
    }

    djicam::StopCamera(djicam::CAMERA_MAIN);
    djicam::Deinit();

    return 0;
}