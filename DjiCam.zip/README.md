# djicam

把 DJI Payload-SDK 相机直播 + 飞控位置/姿态订阅这一堆样例代码,
封装成一个静态库 `libdjicam.a`,业务代码只需要:

```cpp
#include "djicam/djicam.h"

static void OnFrame(const djicam::Image &img, const djicam::FlightData &fd)
{
    // img.data: RGB24 裸数据, img.width / img.height
    // fd.longitude / fd.latitude / fd.altitude / fd.pitch / fd.roll / fd.yaw
}

int main(int argc, char **argv)
{
    djicam::Init(argc, argv);
    djicam::StartCamera(djicam::CAMERA_MAIN, OnFrame);
    ...
    djicam::StopCamera(djicam::CAMERA_MAIN);
    djicam::Deinit();
}
```

不用再关心 `Application` / `LiveviewSample` / `DJICameraStreamDecoder` /
`osal` / `hal` 这些内部实现细节。

## 目录结构

```
djicam/
├── CMakeLists.txt          顶层构建脚本(和你原来的一样,只是改成先出静态库)
├── include/djicam/djicam.h 唯一对外头文件
├── src/                    库的内部实现(application、liveview、解码器、
│                           飞控数据订阅等),不需要看,能编译过就行
├── osal/                   平台适配:任务/互斥锁/信号量/文件/socket
├── hal/                    平台适配:串口/USB Bulk/网卡
└── examples/main.cpp       用法示例(对应你原来的 main.cpp)
```

## 编译

跟原来一模一样,唯一要改的还是 `CMakeLists.txt` 里的 `SDK_ROOT`:

```bash
mkdir build && cd build
cmake ..
make -j$(nproc)
```

产物:
- `build/libdjicam.a` —— 静态库,业务工程只要链接这一个文件 + 上面那个头文件
- `build/bin/djicam_example` —— 示例可执行程序(依赖 OpenCV,仅用于演示取到的画面)

如果你的业务工程完全不需要 OpenCV/显示画面,把 `CMakeLists.txt` 里
"示例程序" 那一段和 `examples/` 目录整个删掉即可,`djicam` 这个
target 本身不依赖 OpenCV。

## 飞控数据说明

`FlightData` 取的是:

- 位置:`DJI_FC_SUBSCRIPTION_TOPIC_POSITION_FUSED`(融合定位:经纬度弧度转角度,
  altitude 是 WGS84 参考椭球下的海拔高度,单位米)
- 姿态:`DJI_FC_SUBSCRIPTION_TOPIC_QUATERNION`(四元数换算欧拉角,单位度)

`fd.valid == false` 一般是还没起飞、卫星数不够或者订阅还没生效,建议
业务代码对 `valid` 做判断,不要在没定位时把 0 当成有效经纬度用。

若还需要速度、RTK、云台角度等其它话题,在 `src/flight_data_subscriber.cpp`
里按同样方式 `DjiFcSubscription_SubscribeTopic` / `GetLatestValueOfTopic`
加一路即可,`djicam::FlightData` 里加对应字段。

## 已知限制 / 请自行编译验证

这份代码是在没有 `SDK_ROOT`(psdk_lib)、没有交叉编译工具链、没有
FFmpeg/OPUS/libusb、也没有网络的沙盒环境里写的,**没有经过实际编译**。
逻辑上和你原来能跑通的 `application.cpp` 初始化顺序保持完全一致
(该文件原样搬进了 `src/`,没有做任何改动),`dji_fc_subscription`
相关的函数名/结构体字段名基于 DJI 官方文档和示例核对过,但如果你那边
SDK 版本的头文件里字段名/枚举值略有出入,请以编译报错为准做小幅调整。
