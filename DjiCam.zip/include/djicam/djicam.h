/**
 ********************************************************************
 * @file    djicam.h
 * @brief   djicam 库对外唯一的公开头文件。
 *
 *          把 application / liveview / stream_decoder / fc_subscription
 *          等一大堆 DJI Payload-SDK 样例代码封装成一个静态库,
 *          业务代码只需要 #include "djicam/djicam.h" 并链接 libdjicam.a
 *          即可拿到相机画面 + 飞控经纬高/俯仰横滚偏航数据。
 *
 * @note    本文件不依赖任何 DJI 头文件,可以放心拷贝到不引用 SDK_ROOT
 *          的业务工程里使用。
 *********************************************************************
 */

#ifndef DJICAM_H
#define DJICAM_H

#include <cstdint>
#include <vector>
#include <functional>

namespace djicam {

/* 与 test_liveview.cpp 中 4 路镜头一一对应 */
enum CameraPosition {
    CAMERA_FPV  = 0,    // 避障/图传镜头
    CAMERA_MAIN = 1,    // 主摄(NO_1),main.cpp 原来用的那一路
    CAMERA_VICE = 2,    // 云台第二路镜头(NO_2)
    CAMERA_TOP  = 3,    // 云台第三路镜头(NO_3)
};

/* 一帧图像,RGB24 裸数据,rawData.size() == width * height * 3 */
struct Image {
    std::vector<uint8_t> data;
    int width  = 0;
    int height = 0;
};

/* 飞控位置/姿态数据。取的是融合定位(POSITION_FUSED)+ 四元数(QUATERNION) */
struct FlightData {
    bool   valid     = false; // false表示本次没能取到有效数据(比如还没定位/未起飞前卫星少)
    double longitude = 0.0;   // 经度,单位:度
    double latitude  = 0.0;   // 纬度,单位:度
    double altitude  = 0.0;   // 融合高度,WGS84参考椭球,单位:米
    float  pitch     = 0.0f;  // 俯仰角,单位:度
    float  roll      = 0.0f;  // 横滚角,单位:度
    float  yaw       = 0.0f;  // 偏航角,单位:度
};

/*
 * 每来一帧图像就会回调一次,回调里已经带上了"和这一帧同步取到的"
 * 最新飞控数据,不需要用户自己再去另外订阅。
 */
using ImageCallback = std::function<void(const Image &image, const FlightData &flightData)>;

/**
 * @brief 初始化整个 SDK:环境搭建(osal/hal注册) + DjiCore_Init + 身份校验 +
 *        飞控数据订阅模块初始化。对应原来 main.cpp 里的 `Application application(argc, argv);`
 * @return true 成功,false 失败(失败原因会通过 DJI logger 打印出来,参考 Logs/ 目录)
 */
bool Init(int argc, char **argv);

/**
 * @brief 启动某一路摄像头的直播流解码,每解出一帧 RGB 图像就回调一次。
 * @param position 镜头位置
 * @param callback 图像+飞控数据回调。
 *        注意:回调运行在解码线程里,耗时操作请自行拷贝数据后丢到别的线程处理。
 * @return true 成功,false 失败
 */
bool StartCamera(CameraPosition position, const ImageCallback &callback);

/**
 * @brief 停止某一路摄像头直播流
 */
void StopCamera(CameraPosition position);

/**
 * @brief 不依赖相机帧,单独查询一次最新的飞控位置/姿态数据。
 */
bool GetLatestFlightData(FlightData &out);

/**
 * @brief 释放全部资源(对应程序退出前调用一次)
 */
void Deinit();

} // namespace djicam

#endif // DJICAM_H
/************************ (C) COPYRIGHT DJI Innovations *******END OF FILE******/
