/**
 ********************************************************************
 * @file    djicam.cpp
 * @brief   djicam.h 对外接口的具体实现,把 Application / LiveviewSample /
 *          FlightDataSubscriber 三块粘合起来,内部用 std::map 管理各路
 *          摄像头的用户回调。
 *
 * @copyright (c) 2021 DJI. All rights reserved.
 *********************************************************************
 */

#include "djicam/djicam.h"
#include "application.hpp"
#include "test_liveview.hpp"
#include "flight_data_subscriber.hpp"
#include "dji_logger.h"

#include <cstdint>
#include <map>
#include <mutex>
#include <exception>

namespace djicam {

namespace {

Application *g_application = nullptr;
LiveviewSample *g_liveview = nullptr;
FlightDataSubscriber *g_flightSub = nullptr;

std::mutex g_callbackMutex;
std::map<CameraPosition, ImageCallback> g_callbacks;

/* 注册给 DJICameraStreamDecoder 的 C 风格回调,负责把数据转成 djicam 的类型 */
void TrampolineCallback(CameraRGBImage img, void *userData)
{
    auto position = static_cast<CameraPosition>(reinterpret_cast<intptr_t>(userData));

    ImageCallback callback;
    {
        std::lock_guard<std::mutex> lock(g_callbackMutex);
        auto it = g_callbacks.find(position);
        if (it == g_callbacks.end()) {
            return;
        }
        callback = it->second;
    }

    if (!callback) {
        return;
    }

    Image image;
    image.width = img.width;
    image.height = img.height;
    image.data = std::move(img.rawData);

    FlightData flightData;
    if (g_flightSub != nullptr) {
        g_flightSub->GetLatest(flightData);
    }

    callback(image, flightData);
}

} // namespace

bool Init(int argc, char **argv)
{
    // 执行 /hzhy/carrierTest/AI528-uart-enable-onx-Jp5.x  命令
    int ret = std::system("/hzhy/carrierTest/AI528-uart-enable-onx-Jp5.x");
    if (ret != 0) {
        USER_LOG_WARN("Failed to execute AI528-uart-enable-onx-Jp5.x, ret=%d", ret);
    } else {
        USER_LOG_WARN("AI528-uart-enable-onx-Jp5.x executed successfully.");
    }

    if (g_application != nullptr)
    {
        USER_LOG_WARN("djicam already initialized.");
        return true;
    }

    try {
        g_application = new Application(argc, argv);
    } catch (const std::exception &e) {
        USER_LOG_ERROR("djicam application init failed: %s", e.what());
        g_application = nullptr;
        return false;
    } catch (...) {
        USER_LOG_ERROR("djicam application init failed with unknown exception.");
        g_application = nullptr;
        return false;
    }

    g_flightSub = new FlightDataSubscriber();
    if (!g_flightSub->Init()) {
        delete g_flightSub;
        g_flightSub = nullptr;
        delete g_application;
        g_application = nullptr;
        return false;
    }

    try {
        g_liveview = new LiveviewSample();
    } catch (...) {
        USER_LOG_ERROR("djicam liveview init failed.");
        delete g_flightSub;
        g_flightSub = nullptr;
        delete g_application;
        g_application = nullptr;
        return false;
    }

    return true;
}

bool StartCamera(CameraPosition position, const ImageCallback &callback)
{
    if (g_liveview == nullptr) {
        USER_LOG_ERROR("djicam not initialized, call djicam::Init() first.");
        return false;
    }

    {
        std::lock_guard<std::mutex> lock(g_callbackMutex);
        g_callbacks[position] = callback;
    }

    auto userData = reinterpret_cast<void *>(static_cast<intptr_t>(position));
    T_DjiReturnCode returnCode;

    switch (position) {
        case CAMERA_FPV:
            returnCode = g_liveview->StartFpvCameraStream(TrampolineCallback, userData);
            break;
        case CAMERA_MAIN:
            returnCode = g_liveview->StartMainCameraStream(TrampolineCallback, userData);
            break;
        case CAMERA_VICE:
            returnCode = g_liveview->StartViceCameraStream(TrampolineCallback, userData);
            break;
        case CAMERA_TOP:
            returnCode = g_liveview->StartTopCameraStream(TrampolineCallback, userData);
            break;
        default:
            USER_LOG_ERROR("djicam unknown camera position: %d", (int) position);
            return false;
    }

    if (returnCode != DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        std::lock_guard<std::mutex> lock(g_callbackMutex);
        g_callbacks.erase(position);
        return false;
    }

    return true;
}

void StopCamera(CameraPosition position)
{
    if (g_liveview == nullptr) {
        return;
    }

    switch (position) {
        case CAMERA_FPV:
            g_liveview->StopFpvCameraStream();
            break;
        case CAMERA_MAIN:
            g_liveview->StopMainCameraStream();
            break;
        case CAMERA_VICE:
            g_liveview->StopViceCameraStream();
            break;
        case CAMERA_TOP:
            g_liveview->StopTopCameraStream();
            break;
        default:
            break;
    }

    std::lock_guard<std::mutex> lock(g_callbackMutex);
    g_callbacks.erase(position);
}

bool GetLatestFlightData(FlightData &out)
{
    if (g_flightSub == nullptr) {
        out.valid = false;
        return false;
    }

    return g_flightSub->GetLatest(out);
}

void Deinit()
{
    if (g_liveview != nullptr) {
        delete g_liveview;
        g_liveview = nullptr;
    }

    if (g_flightSub != nullptr) {
        g_flightSub->Deinit();
        delete g_flightSub;
        g_flightSub = nullptr;
    }

    if (g_application != nullptr) {
        delete g_application;
        g_application = nullptr;
    }

    std::lock_guard<std::mutex> lock(g_callbackMutex);
    g_callbacks.clear();
}

} // namespace djicam

/****************** (C) COPYRIGHT DJI Innovations *****END OF FILE****/
