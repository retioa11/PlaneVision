/**
 ********************************************************************
 * @file    flight_data_subscriber.hpp
 * @brief   对 dji_fc_subscription 模块的简单封装:
 *          订阅融合定位(POSITION_FUSED)与姿态四元数(QUATERNION),
 *          随时可以取"最新一次"的经纬高 + 俯仰横滚偏航。
 *
 * @copyright (c) 2021 DJI. All rights reserved.
 *********************************************************************
 */

#ifndef FLIGHT_DATA_SUBSCRIBER_HPP
#define FLIGHT_DATA_SUBSCRIBER_HPP

#include "djicam/djicam.h"

class FlightDataSubscriber {
public:
    FlightDataSubscriber();
    ~FlightDataSubscriber();

    /* 初始化 fc_subscription 模块并订阅所需 topic */
    bool Init();

    /* 取消订阅并反初始化 */
    void Deinit();

    /* 取最新一次的位置/姿态数据,内部直接读取PSDK缓存的最新值,不阻塞 */
    bool GetLatest(djicam::FlightData &out);

private:
    bool m_inited;
};

#endif // FLIGHT_DATA_SUBSCRIBER_HPP
/************************ (C) COPYRIGHT DJI Innovations *******END OF FILE******/
