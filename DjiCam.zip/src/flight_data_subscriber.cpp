/**
 ********************************************************************
 * @file    flight_data_subscriber.cpp
 * @brief
 *
 * @copyright (c) 2021 DJI. All rights reserved.
 *********************************************************************
 */

#include "flight_data_subscriber.hpp"
#include "dji_fc_subscription.h"
#include "dji_logger.h"
#include <cmath>

FlightDataSubscriber::FlightDataSubscriber() : m_inited(false)
{
}

FlightDataSubscriber::~FlightDataSubscriber()
{
    Deinit();
}

bool FlightDataSubscriber::Init()
{
    T_DjiReturnCode returnCode;

    returnCode = DjiFcSubscription_Init();
    if (returnCode != DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        USER_LOG_ERROR("Init fc subscription module error: 0x%08X", returnCode);
        return false;
    }

    /* 融合定位:经度/纬度(弧度)+ 海拔(米,WGS84) */
    returnCode = DjiFcSubscription_SubscribeTopic(DJI_FC_SUBSCRIPTION_TOPIC_POSITION_FUSED,
                                                   DJI_DATA_SUBSCRIPTION_TOPIC_50_HZ, nullptr);
    if (returnCode != DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        USER_LOG_ERROR("Subscribe topic position_fused error: 0x%08X", returnCode);
        return false;
    }

    /* 姿态四元数,用于换算 pitch/roll/yaw */
    returnCode = DjiFcSubscription_SubscribeTopic(DJI_FC_SUBSCRIPTION_TOPIC_QUATERNION,
                                                   DJI_DATA_SUBSCRIPTION_TOPIC_50_HZ, nullptr);
    if (returnCode != DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        USER_LOG_ERROR("Subscribe topic quaternion error: 0x%08X", returnCode);
        return false;
    }

    m_inited = true;

    return true;
}

void FlightDataSubscriber::Deinit()
{
    if (!m_inited) {
        return;
    }

    DjiFcSubscription_UnSubscribeTopic(DJI_FC_SUBSCRIPTION_TOPIC_QUATERNION);
    DjiFcSubscription_UnSubscribeTopic(DJI_FC_SUBSCRIPTION_TOPIC_POSITION_FUSED);
    DjiFcSubscription_DeInit();

    m_inited = false;
}

bool FlightDataSubscriber::GetLatest(djicam::FlightData &out)
{
    T_DjiReturnCode returnCode;
    T_DjiDataTimestamp timestamp = {0};
    T_DjiFcSubscriptionPositionFused positionFused;
    T_DjiFcSubscriptionQuaternion quaternion;

    out.valid = false;

    if (!m_inited) {
        return false;
    }

    returnCode = DjiFcSubscription_GetLatestValueOfTopic(DJI_FC_SUBSCRIPTION_TOPIC_POSITION_FUSED,
                                                          (uint8_t *) &positionFused, sizeof(positionFused),
                                                          &timestamp);
    if (returnCode != DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        return false;
    }

    returnCode = DjiFcSubscription_GetLatestValueOfTopic(DJI_FC_SUBSCRIPTION_TOPIC_QUATERNION,
                                                          (uint8_t *) &quaternion, sizeof(quaternion),
                                                          &timestamp);
    if (returnCode != DJI_ERROR_SYSTEM_MODULE_CODE_SUCCESS) {
        return false;
    }

    /* PositionFused 里经纬度单位是弧度,转成角度更符合直觉 */
    out.longitude = positionFused.longitude * 180.0 / M_PI;
    out.latitude  = positionFused.latitude * 180.0 / M_PI;
    out.altitude  = positionFused.altitude;

    /* 四元数 -> 欧拉角,公式与 DJI 官方样例 dji_test_fc_subscription.c 一致 */
    out.pitch = (float) (asinf(-2.0f * quaternion.q1 * quaternion.q3 + 2.0f * quaternion.q0 * quaternion.q2) *
                          57.29578f);
    out.roll = (float) (atan2f(2.0f * quaternion.q2 * quaternion.q3 + 2.0f * quaternion.q0 * quaternion.q1,
                                -2.0f * quaternion.q1 * quaternion.q1 - 2.0f * quaternion.q2 * quaternion.q2 + 1.0f) *
                         57.29578f);
    out.yaw = (float) (atan2f(2.0f * quaternion.q1 * quaternion.q2 + 2.0f * quaternion.q0 * quaternion.q3,
                               -2.0f * quaternion.q2 * quaternion.q2 - 2.0f * quaternion.q3 * quaternion.q3 + 1.0f) *
                        57.29578f);

    out.valid = true;

    return true;
}

/****************** (C) COPYRIGHT DJI Innovations *****END OF FILE****/
