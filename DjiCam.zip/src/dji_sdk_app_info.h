/**
 ********************************************************************
 * @file    dji_sdk_app_info.h
 * @brief   This is the header file for defining the structure and (exported) function prototypes.
 *
 * @copyright (c) 2018 DJI. All rights reserved.
 *
 * All information contained herein is, and remains, the property of DJI.
 * The intellectual and technical concepts contained herein are proprietary
 * to DJI and may be covered by U.S. and foreign patents, patents in process,
 * and protected by trade secret or copyright law.  Dissemination of this
 * information, including but not limited to data and other proprietary
 * material(s) incorporated within the information, in any form, is strictly
 * prohibited without the express written consent of DJI.
 *
 * If you receive this source code without DJI’s authorization, you may not
 * further disseminate the information, and you must immediately remove the
 * source code and notify DJI of its removal. DJI reserves the right to pursue
 * legal actions against you for any loss(es) or damage(s) caused by your
 * failure to do so.
 *
 *********************************************************************
 */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef DJI_SDK_APP_INFO_H
#define DJI_SDK_APP_INFO_H

/* Includes ------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/* Exported constants --------------------------------------------------------*/
// ATTENTION: User must goto https://developer.dji.com/user/apps/#all to create your own dji sdk application, get dji sdk application
// information then fill in the application information here.
#define USER_APP_NAME               "AI660"
#define USER_APP_ID                 "133254"
#define USER_APP_KEY                "b94de191a75fed89fa595dd01d03589"
#define USER_APP_LICENSE            "UbEI/yEgWra2G1jDGsbH/vRR+WinKoeMccdvwmTXTFin5oad/0eBPD2vFQLq9ajr3TBsKBx89GHheIUVE+RS+h+7pggYtM6jfF5IqxQLtrEFkrs+YD/F+Kyk3A6qidSQkBxb61dBQV3HSwRl0pOljB5PL6BbbcxTWcaqretxV8LwGw+nrfKj/BLBA+4u4B/bJki+He6KH0wmqtF3viljoHMdh6he9EnLBpMcShfnUruHcTHB7AmusTmFENgd7taAYCDc1glSr47UI5SWTV2iKnguwOiDKZk43oTD/UhdUCxmYd+lEOO1aUadiUNHkI6Iyi7RXIJkmpe+cCvC4XMM5Q=="
#define USER_DEVELOPER_ACCOUNT      "2381783554@qq.com"
#define USER_BAUD_RATE              "460800"

/* Exported types ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/


#ifdef __cplusplus
}
#endif

#endif // DJI_SDK_APP_INFO_H
/************************ (C) COPYRIGHT DJI Innovations *******END OF FILE******/
