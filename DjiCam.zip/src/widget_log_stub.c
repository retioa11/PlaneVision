//
// Created by Administrator on 2026/7/31.
//
#include <stdarg.h>
#include <stdio.h>

void DjiTest_WidgetLogAppend(const char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    vprintf(fmt, args);   // 直接打印到终端就行，等效于把widget日志改成打印日志
    va_end(args);
}