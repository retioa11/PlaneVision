
function(IncludeAndLinkCommon target)
    if(WIN32)
        # SpdLog
        set(SpdLog_Dir )
        target_include_directories(${target} PRIVATE F:/ThirdPartyLibrary/SpdLog1.x/Include)
        target_link_directories(${target} PRIVATE F:/ThirdPartyLibrary/SpdLog1.x/Lib)
        target_link_libraries(${target} PRIVATE spdlog)
        # OnnxRuntime
        target_include_directories(${target} PRIVATE F:/ThirdPartyLibrary/onnxruntime-win-x64-gpu-1.19.2/include)
        target_link_directories(${target} PRIVATE F:/ThirdPartyLibrary/onnxruntime-win-x64-gpu-1.19.2/lib)
        target_link_libraries(${target} PRIVATE onnxruntime onnxruntime_providers_cuda)
        # OpenCV
        target_include_directories(${target} PRIVATE F:/ThirdPartyLibrary/OpenCV4.11.0_VS2019_X64/include)
        target_link_directories(${target} PRIVATE F:/ThirdPartyLibrary/OpenCV4.11.0_VS2019_X64/x64/vc16/lib)
        target_link_libraries(${target} PRIVATE opencv_world4110d)
        # Qt
        target_include_directories(${target} PRIVATE D:/Qt/6.5.2/msvc2019_64/include)
        target_link_directories(${target} PRIVATE D:/Qt/6.5.2/msvc2019_64/lib)
        target_link_libraries(${target} PRIVATE Qt6Core Qt6Gui Qt6Widgets)
        # ShapeLib
        target_include_directories(${target} PRIVATE F:/ThirdPartyLibrary/ShapeLib/Include)
        target_link_directories(${target} PRIVATE F:/ThirdPartyLibrary/ShapeLib/Lib)
        target_link_libraries(${target} PRIVATE shp)
        # GDAL
#        target_include_directories(${target} PRIVATE F:/ThirdPartyLibrary/GDAL3.13/include)
#        target_link_directories(${target} PRIVATE F:/ThirdPartyLibrary/GDAL3.13/lib)
#        target_link_libraries(${target} PRIVATE gdal_i)
        target_include_directories(${target} PRIVATE F:/ThirdPartyLibrary/OSGeo4W/include)
        target_link_directories(${target} PRIVATE F:/ThirdPartyLibrary/OSGeo4W/lib)
        target_link_libraries(${target} PRIVATE gdal_i)
        # ZeroMQ
        target_include_directories(${target} PRIVATE F:/ThirdPartyLibrary/Zmq4.3.5_VS2022_X64/cppzmq_x64-windows/include)
        target_include_directories(${target} PRIVATE F:/ThirdPartyLibrary/Zmq4.3.5_VS2022_X64/zeromq_x64-windows/include)
        target_link_directories(${target} PRIVATE F:/ThirdPartyLibrary/Zmq4.3.5_VS2022_X64/zeromq_x64-windows/lib)
        target_link_directories(${target} PRIVATE F:/ThirdPartyLibrary/Zmq4.3.5_VS2022_X64/zeromq_x64-windows/debug/lib)
        target_link_libraries(${target} PRIVATE libzmq-mt-gd-4_3_5.lib optimized libzmq-mt-4_3_5.lib)
    else ()
        # Qt
        target_include_directories(${target} PRIVATE /usr/include/aarch64-linux-gnu/qt6)
        target_link_directories(${target} PRIVATE /usr/lib/aarch64-linux-gnu)
        target_link_libraries(${target} PRIVATE Qt6Core Qt6Gui Qt6Widgets)
        # OnnxRuntime
        target_include_directories(${target} PRIVATE /workspace/ThirdPartyLibrary/OnnxRuntime-1.20.0-gpu/include)
        target_link_directories(${target} PRIVATE /workspace/ThirdPartyLibrary/OnnxRuntime-1.20.0-gpu/lib)
        target_link_libraries(${target} PRIVATE onnxruntime)
        # OpenCV
        target_include_directories(${target} PRIVATE /workspace/ThirdPartyLibrary/OpenCV4.11.0_Cuda12.6/include/opencv4)
        target_link_directories(${target} PRIVATE /workspace/ThirdPartyLibrary/OpenCV4.11.0_Cuda12.6/lib)
#        target_link_libraries(${target} PRIVATE opencv_calib3d opencv_core opencv_flann opencv_highgui opencv_imgcodecs opencv_imgproc opencv_video opencv_features2d opencv_videoio )
        target_link_libraries(${target} PRIVATE opencv_world)
        # ShapeLib
        target_include_directories(${target} PRIVATE /workspace/ThirdPartyLibrary/ShapeLib/Include)
        target_link_directories(${target} PRIVATE /workspace/ThirdPartyLibrary/ShapeLib/Lib)
        target_link_libraries(${target} PRIVATE shp)
        # ZeroMQ（系统包 libzmq3-dev；FileSender / TextTransferJetson 用）
        target_link_libraries(${target} PRIVATE zmq)
        # GDAL  (apt install -y libgdal-dev gdal-bin)
        target_include_directories(${target} PRIVATE /usr/include/gdal)
        target_link_directories(${target} PRIVATE /usr/lib/aarch64-linux-gnu)
        target_link_libraries(${target} PRIVATE gdal)
#        #RKNN
#        target_include_directories(${target} PRIVATE /workspace/ThirdPartyLibrary/rknn-toolkit2-2.3.2/Include)
#        target_link_directories(${target} PRIVATE /workspace/ThirdPartyLibrary/rknn-toolkit2-2.3.2/Lib)
#        target_link_libraries(${target} PRIVATE rknnrt fmt)
#        # SpdLog
#        target_include_directories(${target} PRIVATE /usr/include)
#        target_link_directories(${target} PRIVATE /usr/lib/aarch64-linux-gnu)
#        target_link_libraries(${target} PRIVATE spdlog)
#        # Eigen
#        target_include_directories(${target} PRIVATE /usr/include/eigen3)

    endif ()

endfunction()

# -----------------------------------------------------------------------------
# CopyEngineDll(target)：各 exe 的 POST_BUILD 共用
#   1) Windows：把 VisionGISAIEngine 动态库复制到 exe 旁边
#   2) 所有平台：把 Src/0.ConfigFile 目录的内容复制到 exe 旁边
# 用法：在 add_executable 之后 CopyEngineDll(<target>)；调用方不用再自己定义这个函数。
# 配置目录必须在这里（文件顶层）求值：函数体里的 CMAKE_CURRENT_LIST_DIR 指向调用者的 CMakeLists。
# -----------------------------------------------------------------------------
get_filename_component(ENGINE_CONFIG_DIR "${CMAKE_CURRENT_LIST_DIR}/../0.ConfigFile" ABSOLUTE)

function(CopyEngineDll target)
    if (WIN32)
        add_custom_command(TARGET ${target} POST_BUILD
                COMMAND ${CMAKE_COMMAND} -E copy_if_different
                $<TARGET_FILE:VisionGISAIEngine> $<TARGET_FILE_DIR:${target}>)
    endif ()
    # 配置复制不挂 POST_BUILD：POST_BUILD 只在 exe 重新链接时才跑，只改 json 时 exe 是最新的，不会复制。
    # 单独建一个"永远过期"的自定义目标（没有 OUTPUT/DEPENDS），每次构建 <target> 都会先跑它，
    # 所以只改了 0.ConfigFile 里的文件、只点一次"构建/运行"也会复制到 exe 旁边。
    add_custom_target(${target}_CopyConfig
            COMMAND ${CMAKE_COMMAND} -E copy_directory
            "${ENGINE_CONFIG_DIR}" $<TARGET_FILE_DIR:${target}>
            COMMENT "Copy 0.ConfigFile -> $<TARGET_FILE_DIR:${target}>")
    add_dependencies(${target} ${target}_CopyConfig)
endfunction()
