﻿// 变化检测入口。流程：读配置 → 解析工作目录 → 建流水线并自检 → 数据源逐帧交给流水线（Ctrl-C 退出）。
// 用法：ChangeDetectExe [--config 配置文件名]；返回 0 正常退出，1 配置 / 工作目录错误（含非 Disk 模式），2 自检有问题
#include <atomic>
#include <csignal>
#include <cstdio>
#include <string>

#include "ChangeDetectConfig.h"
#include "ChangeDetectPipeline.h"
#include "1.Common/LogPrintf.h"
#include "DirectoryFrameSource.h"

namespace {

std::atomic<bool> g_stop{false};

void RunSource(const ChangeDetectConfig& cfg, const WorkPaths& paths, ChangeDetectPipeline& pipeline)
{
    DirectorySourceOptions opt;
    opt.imageDir = paths.imageDir;
    opt.invokeIntervalMs = cfg.invokeIntervalMs;
    opt.minWorkHeight = cfg.minWorkHeight;
    opt.maxWorkHeight = cfg.maxWorkHeight;
    opt.shouldStop = [] { return g_stop.load(); };
    DirectoryFrameSource source(opt);

    LogPrintf("== 数据源（Ctrl-C 退出）==\n");
    PoseFrame frame;
    std::string id;
    while (source.Next(frame, id)) pipeline.Process(frame, id);

    const DirectorySourceCounters& c = source.Counters();
    const PipelineCounters& p = pipeline.Counters();
    LogPrintf("== 结束：数据源交出 %d 帧；跳过 文件名 %d / 缺位姿 %d / 高度 %d / 读不出 %d ==\n", c.delivered, c.skippedBadName, c.skippedNoPose, c.skippedHeight, c.skippedUnreadable);
    LogPrintf("== 流水线：完成 %d（其中配准失败降级 %d）/ 跳过 %d / 失败 %d ==\n", p.done, p.degraded, p.skipped, p.failed);
}

}  // namespace

int main(int argc, char** argv)
{
    std::setbuf(stdout, nullptr);
    std::string configFile;
    for (int i = 1; i < argc; ++i) {
        const std::string a = argv[i];
        if (a == "--config" && i + 1 < argc) configFile = argv[++i];
        else { std::fprintf(stderr, "用法: ChangeDetectExe [--config 配置文件名]\n"); return 1; }
    }
    std::signal(SIGINT,  [](int) { g_stop = true; });
    std::signal(SIGTERM, [](int) { g_stop = true; });

    ChangeDetectConfig cfg;
    WorkPaths paths;
    std::string err, warn;
    if (!LoadChangeDetectConfig(cfg, err, warn, configFile) || !ResolveWorkPaths(cfg, paths, err)) { std::fprintf(stderr, "[ChangeDetect] %s\n", err.c_str()); return 1; }
    // 文本日志通道：端口来自配置（TextSendPort / TextRecvPort）；会等 zmq 握手约 1.3 秒，所以尽早建，之后所有 LogPrintf 都能到地面端
    InitTextLog(cfg.textSendPort, cfg.textRecvPort, true);
    LogPrintf("%s%s", warn.c_str(), DescribeWorkPaths(paths).c_str());
    if (!PrepareOutputDir(paths, err)) { LogPrintf("[ChangeDetect] %s\n", err.c_str()); return 1; }

    ChangeDetectPipeline pipeline(cfg, paths);
    const int problems = pipeline.Start();
    LogPrintf(problems == 0 ? "== 自检通过 ==\n" : "== 自检发现 %d 个问题 ==\n", problems);
    if (problems != 0) return 2;
    if (paths.mode != RunMode::Disk) { LogPrintf("[ChangeDetect] 第一版只支持 Disk 模式（WorkDir 下有 0.CameraImage）；当前是 Camera 模式\n"); return 1; }
    RunSource(cfg, paths, pipeline);
    return 0;
}
