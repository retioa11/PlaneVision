﻿// ChangeDetectPipeline.h —— 变化检测流水线：把数据源交来的帧依次送过 配准 → 变化检测 → 矢量化与下传。
//
// 只做"串联"：自检、每帧 try/catch、计时、DebugStage。具体处理在 Stage/ 下的三个类里，流水线持有它们、用配置填它们的参数结构体。
// 只依赖 PoseFrame，不关心帧从哪来（Source/ 下的类负责）。同步处理：Process 返回时这一帧已经处理完（或跳过）。
// 线程：只能由一个线程调用。
#pragma once

#include <map>
#include <string>

#include <opencv2/core.hpp>

#include "CaptureTypes.h"   // PoseFrame
#include "ChangeAlign.h"
#include "ChangeDetectConfig.h"
#include "ChangeDetector.h"
#include "ChangeExport.h"

class FileSender;   // 1.Common/FileSender.h

enum class FrameStatus { Done, Skipped, Failed };

struct FrameResult
{
    FrameStatus status = FrameStatus::Done;
    std::string reason;       // Skipped / Failed 时的原因
};

struct PipelineCounters
{
    int done = 0, skipped = 0, failed = 0;
    int degraded = 0;   // done 里有多少帧是降级的（匹配 / 拟合失败后用位姿几何继续，没有匹配校正）
};

class ChangeDetectPipeline
{
public:
    // sharedSender：外部创建的下传通道（根目录须是 <paths.outputDir>/GroundEnd），非空时变化检测不再自己创建，cfg.sendToGround / groundFilePort 被忽略；
    //   空 = 按配置自己创建（单独运行的变化检测程序）。生命周期由调用方负责，必须比流水线活得久。
    ChangeDetectPipeline(const ChangeDetectConfig& cfg, const WorkPaths& paths, FileSender* sharedSender = nullptr);

    // 启动前自检（模型 / 类别表 / T1 / 图片文件名），结果打印到标准输出。返回发现的问题个数，0 = 正常。
    // 自检通过 T1 后，ChangeAlign 打开 T1 并加载匹配配准模型（DebugStage=align 时不加载）；再加载变化检测模型（DebugStage=align / match 时不加载），再初始化导出（读类别表、绑定下传端口；DebugStage 非空时不初始化）。
    int Start();

    // 同步处理一帧。内部每帧 try/catch：一帧出错只记录并返回 Failed，不影响后面的帧。id 是不含扩展名的文件名，输出按它命名
    FrameResult Process(const PoseFrame& frame, const std::string& id);

    const PipelineCounters& Counters() const { return counters_; }

private:
    ChangeDetectConfig cfg_;
    WorkPaths paths_;
    PipelineCounters counters_;
    ChangeAlign align_;
    ChangeDetector detector_;
    std::map<std::string, int> debugIds_;   // DebugStage 存过的图：<子目录>/<id> 及次数，同名时报出来而不是覆盖
    ChangeExport export_;
    bool sharedSender_ = false;   // 下传通道是外部给的（只影响自检时打印的文字）

    void SaveAlignDebug(const AlignGeometry& g, const std::string& id);
    cv::Mat BuildMatchCanvas(const AlignResult& r);   // 匹配连线 + 校正前后对比图；DebugStage=match 存它，正常运行时进 HTML 日志
    void SaveMatchDebug(const AlignResult& r, const std::string& id);
    void SaveDetectDebug(const AlignResult& r, const cv::Mat& label, const std::string& id);
    bool ExportEnabled() const { return cfg_.debugStage.empty(); }   // 只有正常运行才矢量化、写文件、下传；任何 DebugStage 都不导出
    bool DetectEnabled() const { return cfg_.debugStage != kDebugStageAlign && cfg_.debugStage != kDebugStageMatch; }   // align / match 只做到配准，不加载也不跑检测
    void SaveDebugImage(const char* subDir, const char* suffix, const std::string& id, const cv::Mat& canvas);
};
