﻿// ChangeDetectWorker.h —— 实时模式下的变化检测"工作线程"：别人把帧交给它（Submit），它在自己的线程里串过流水线。
//
// 为什么要它：流水线处理一帧要几秒（配准、模型、矢量化、下传），交帧的一方（取帧 / 检测线程）不能被它占住。
// 线程模型：
//   - Start() 拉起一个线程，流水线（含 T1 库、两个 ONNX 会话）在这个线程里创建、使用、销毁，别的线程碰不到；
//     Start() 等它初始化完（自检 + 加载模型；首次编译 TensorRT 可能要一两分钟）才返回，所以返回时状态已经是 Ready 或 Failed。
//   - Submit() 非阻塞，深度为 1：线程正在处理（或已有一帧在等）时返回 Busy，不排队、不覆盖。
//   - IsIdle()：就绪且没在处理。采样器据此决定"这一帧要不要同时交给变化检测"。
// 帧的取舍：
//   - 相对高度超出 [MinWorkHeight, MaxWorkHeight] 的帧在 Submit 里就拒收（Disk 模式下这件事由 DirectoryFrameSource 做，实时模式没有它）。
//     MaxWorkHeight <= MinWorkHeight 时不过滤，与 Disk 模式一致。
//   - 位姿是否有限、相对高度是否 > 0 由 ChangeAlign 自己检查，不合格的帧在流水线里记为"跳过"，这里不重复。
// 帧的所有权：Submit 接受后会 clone 一份图像，调用方交完就可以继续用自己的那份。
// stem：输出文件名的前缀（不含扩展名），也是流水线的 id；通常是 MakePoseStem(pose)（hhmmss_RtkLon…_Yaw…）。ChangeExport 在后面接 _Count<图斑数>。
//   调用方要保证 stem 在一次运行里不重复（重复时 ChangeExport 会改成 xxx_dup2）。
// 所有方法都可以在任意线程调用；Start / Stop 不要并发，Stop 之后可以再 Start。
#pragma once

#include <condition_variable>
#include <future>
#include <mutex>
#include <string>
#include <thread>

#include "CaptureTypes.h"   // PoseFrame
#include "ChangeDetectConfig.h"
#include "ChangeDetectPipeline.h"

class FileSender;   // 1.Common/FileSender.h

class ChangeDetectWorker
{
public:
    enum class State { NotStarted, Ready, Failed };
    enum class SubmitResult { Accepted, NotReady, Busy, EmptyImage, BadStem, HeightOutOfRange };

    ChangeDetectWorker() = default;
    ~ChangeDetectWorker() { Stop(); }
    ChangeDetectWorker(const ChangeDetectWorker&)            = delete;
    ChangeDetectWorker& operator=(const ChangeDetectWorker&) = delete;

    // 拉起线程，在线程里建流水线并 Start()（自检、加载模型），等结果。
    // sender：外部创建的下传通道（根目录须是 <paths.outputDir>/GroundEnd），可为空 = 变化检测自己按配置决定是否创建；生命周期由调用方负责，必须比 Worker 活得久。
    // 返回 true = 就绪。返回 false = 失败（自检有问题 / 初始化异常），err 写原因，没有线程在跑，状态是 Failed。
    bool Start(const ChangeDetectConfig& cfg, const WorkPaths& paths, FileSender* sender, std::string& err);

    // 非阻塞。Accepted 才表示这一帧会被处理；其余是拒收原因（见 ToText）。
    SubmitResult Submit(const PoseFrame& frame, const std::string& stem);

    bool  IsIdle() const;     // Ready 且没有帧在等或在处理
    State GetState() const;
    PipelineCounters Counters() const;   // 流水线的完成 / 跳过 / 失败计数（拷贝）

    // 等当前这一帧处理完（可能几秒）再退出线程，丢弃还没开始处理的那一帧。可重复调用。
    void Stop();

    static const char* ToText(SubmitResult r);

private:
    void ThreadMain(ChangeDetectConfig cfg, WorkPaths paths, FileSender* sender, std::promise<std::string> initDone);

    mutable std::mutex      mutex_;
    std::condition_variable cv_;
    std::thread             thread_;
    State                   state_ = State::NotStarted;
    bool                    stop_ = false;
    bool                    busy_ = false;     // 有一帧在等或在处理
    bool                    hasJob_ = false;   // 有一帧在等（还没被线程取走）
    PoseFrame               jobFrame_;
    std::string             jobStem_;
    PipelineCounters        counters_;
    double                  minWorkHeight_ = 0, maxWorkHeight_ = 0;   // Start 里设置，之后只读
};
