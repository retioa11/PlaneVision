﻿#include "ChangeDetectWorker.h"

#include <cmath>
#include <exception>
#include <future>
#include <memory>
#include <utility>

#include "1.Common/LogPrintf.h"

const char* ChangeDetectWorker::ToText(SubmitResult r)
{
    switch (r) {
        case SubmitResult::Accepted:         return "已接收";
        case SubmitResult::NotReady:         return "变化检测未就绪";
        case SubmitResult::Busy:             return "变化检测正在处理上一帧";
        case SubmitResult::EmptyImage:       return "图像为空或不是 BGR 8 位三通道";
        case SubmitResult::BadStem:          return "stem 为空";
        case SubmitResult::HeightOutOfRange: return "相对高度不在工作高度范围内";
    }
    return "未知";
}

bool ChangeDetectWorker::Start(const ChangeDetectConfig& cfg, const WorkPaths& paths, FileSender* sender, std::string& err)
{
    err.clear();
    if (thread_.joinable()) { err = "ChangeDetectWorker 已经启动"; return false; }
    {
        std::lock_guard<std::mutex> lock(mutex_);
        state_ = State::NotStarted;
        stop_ = busy_ = hasJob_ = false;
        jobFrame_ = PoseFrame();
        jobStem_.clear();
        counters_ = PipelineCounters();
    }
    minWorkHeight_ = cfg.minWorkHeight;
    maxWorkHeight_ = cfg.maxWorkHeight;

    std::promise<std::string> initDone;
    std::future<std::string> initResult = initDone.get_future();
    try {
        thread_ = std::thread(&ChangeDetectWorker::ThreadMain, this, cfg, paths, sender, std::move(initDone));
    } catch (const std::exception& e) {
        err = std::string("创建变化检测线程失败: ") + e.what();
        std::lock_guard<std::mutex> lock(mutex_);
        state_ = State::Failed;
        return false;
    }

    const std::string failure = initResult.get();   // 空串 = 就绪；非空 = 失败原因。线程在失败时会自己退出
    if (!failure.empty()) {
        thread_.join();
        err = failure;
        std::lock_guard<std::mutex> lock(mutex_);
        state_ = State::Failed;
        return false;
    }
    return true;
}

void ChangeDetectWorker::ThreadMain(ChangeDetectConfig cfg, WorkPaths paths, FileSender* sender, std::promise<std::string> initDone)
{
    // 流水线在本线程里创建、使用、销毁：T1 库（同一个 LMDB 目录一个进程里不能同时打开两次）和 ONNX 会话都不跨线程
    std::unique_ptr<ChangeDetectPipeline> pipeline;
    std::string failure;
    try {
        pipeline = std::make_unique<ChangeDetectPipeline>(cfg, paths, sender);
        const int problems = pipeline->Start();
        if (problems != 0) failure = "变化检测自检发现 " + std::to_string(problems) + " 个问题（详见日志）";
    } catch (const std::exception& e) {
        failure = std::string("变化检测初始化异常: ") + e.what();
    } catch (...) {
        failure = "变化检测初始化未知异常";
    }
    if (!failure.empty()) {
        pipeline.reset();
        initDone.set_value(failure);
        return;
    }
    {
        std::lock_guard<std::mutex> lock(mutex_);
        state_ = State::Ready;
    }
    initDone.set_value(std::string());

    for (;;) {
        PoseFrame frame;
        std::string stem;
        {
            std::unique_lock<std::mutex> lock(mutex_);
            cv_.wait(lock, [this] { return stop_ || hasJob_; });
            if (stop_) break;
            frame = std::move(jobFrame_);
            stem = std::move(jobStem_);
            jobFrame_ = PoseFrame();
            hasJob_ = false;   // busy_ 保持 true，直到这一帧处理完
        }
        try {
            pipeline->Process(frame, stem);   // 内部已经每帧 try/catch；这里再兜一层，保证线程不会因为任何异常退出
        } catch (const std::exception& e) {
            LogPrintf("[变化检测] 处理 %s 时出现未捕获的异常：%s\n", stem.c_str(), e.what());
        } catch (...) {
            LogPrintf("[变化检测] 处理 %s 时出现未捕获的未知异常\n", stem.c_str());
        }
        std::lock_guard<std::mutex> lock(mutex_);
        counters_ = pipeline->Counters();
        busy_ = false;
    }
}

ChangeDetectWorker::SubmitResult ChangeDetectWorker::Submit(const PoseFrame& frame, const std::string& stem)
{
    if (frame.ImageMat.empty() || frame.ImageMat.type() != CV_8UC3) return SubmitResult::EmptyImage;
    if (stem.empty()) return SubmitResult::BadStem;
    if (maxWorkHeight_ > minWorkHeight_ &&
        !(frame.RelativeHeight >= minWorkHeight_ && frame.RelativeHeight <= maxWorkHeight_))   // 写成取反，NaN 也会被拒
        return SubmitResult::HeightOutOfRange;

    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (state_ != State::Ready) return SubmitResult::NotReady;
        if (busy_) return SubmitResult::Busy;
        busy_ = true;   // 先占位，clone 在锁外做
    }
    PoseFrame copy = frame;
    copy.ImageMat = frame.ImageMat.clone();
    {
        std::lock_guard<std::mutex> lock(mutex_);
        jobFrame_ = std::move(copy);
        jobStem_ = stem;
        hasJob_ = true;
    }
    cv_.notify_one();
    return SubmitResult::Accepted;
}

bool ChangeDetectWorker::IsIdle() const
{
    std::lock_guard<std::mutex> lock(mutex_);
    return state_ == State::Ready && !busy_;
}

ChangeDetectWorker::State ChangeDetectWorker::GetState() const
{
    std::lock_guard<std::mutex> lock(mutex_);
    return state_;
}

PipelineCounters ChangeDetectWorker::Counters() const
{
    std::lock_guard<std::mutex> lock(mutex_);
    return counters_;
}

void ChangeDetectWorker::Stop()
{
    {
        std::lock_guard<std::mutex> lock(mutex_);
        stop_ = true;
    }
    cv_.notify_all();
    if (thread_.joinable()) thread_.join();
    std::lock_guard<std::mutex> lock(mutex_);
    state_ = State::NotStarted;
    stop_ = busy_ = hasJob_ = false;
    jobFrame_ = PoseFrame();
    jobStem_.clear();
}
