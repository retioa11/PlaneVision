﻿// ChangeDetectConfig.h —— 变化检测的配置（项目级 + 参数级 + 平台焦距）
//
// 变化检测的配置与工作目录。
// 配置文件在 Src/0.ConfigFile，构建后复制到 exe 旁边：
//   ChangeDetectConfig.json    ProjectParam（路径类字段可按 {"Windows":..,"Jetson":..} 分写）+ ChangeDetectParam
//   MosaicPlatformConfig.json  PlatformParam 的像素焦距，GSD = 离地高度 / fy
// 默认值只在结构体里写一份，JSON 缺省某键时取默认值。json.hpp 很大，只在 .cpp 里包含。
#pragma once

#include <string>
#include <vector>

inline constexpr const char* kDebugStageAlign = "align";   // DebugStage 的取值之一：只做几何
inline constexpr const char* kDebugStageMatch = "match";   // DebugStage 的取值之一：做到匹配 + 校正，存匹配连线和校正前后对比图
inline constexpr const char* kDebugStageDetect = "detect"; // DebugStage 的取值之一：做到变化检测（不矢量化、不下传），存 基准图 | 实时图 | 检测叠加 对比图
inline constexpr int kGaussZoneDeg = 3;   // 统一 3° 带；中央子午线取自 T1 的带号（zone * 3）

// WorkDir 里的固定目录（单独运行和合并进 TargetTrackExe 都一样）：
//   0.CameraImage    存在 → Disk（回放目录里的图）；不存在 → Camera（实时，帧由相机 / 视频交进来）
//   1.GuaranteedData T1 目录（内含 tiles.lmdb），两种模式都用它
//   2.DetectResult   Disk 模式的输出目录（每次启动先删除再重建）；Camera 模式的输出目录是 <WorkDir>/<GroundEndConfig.json 的 SaveDirName>
// 输出目录里的矢量结果放 <输出目录>/GroundEnd/ChangeDetect（目录名常量见 1.Common/GroundLayout.h），下传以 <输出目录>/GroundEnd/ 为根
inline constexpr const char* kImageSubDir      = "0.CameraImage";
inline constexpr const char* kGuaranteedSubDir = "1.GuaranteedData";
inline constexpr const char* kResultSubDir     = "2.DetectResult";

struct ChangeDetectConfig
{
    // ── ProjectParam：路径、端口、模型 ───────────────────────────────────────
    std::string workDir;               // 必须存在；里面有 0.CameraImage → Disk 回放模式，没有 → Camera 模式；T1 固定取其下的 1.GuaranteedData
    std::string modelDir;              // 模型目录；SplgModelPath / ChangeDetectModelPath 留空时到这里按后缀找
    std::string splgModelPath;         // 匹配模型（SuperPoint+LightGlue）。留空 = 在 modelDir 里找 *SPLG.onnx
    std::string changeDetectModelPath; // 变化检测模型。留空 = 在 modelDir 里找 *CD.onnx
    std::string changeKindFile;        // 变化类别表（Id / Name / Color 的 JSON 数组）；相对路径相对 exe 目录
    int groundFilePort  = 4444;        // 下传文件的 ZMQ 端口（原 Jts2StaFilePort），须与地面端 FileReceiver 连的一致
    bool sendToGround   = true;        // false = 只写文件、不绑定端口、不下传（没有地面端的机器上用，免得每帧刷"没有接收者"）
    int textSendPort    = 8888;        // 文本日志通道（与 TargetTrack 一致）
    int textRecvPort    = 6666;
    int invokeIntervalMs = 5000;       // 两帧之间的最小处理间隔（毫秒），0 = 不限速。旧程序的 InvokeInterval

    // ── ChangeDetectParam：阈值 ─────────────────────────────────────────────
    int    matchModelInputWH = 672;    // 匹配模型的方形输入边长，同时是实时图 / 基准图送去匹配的窗口边长
    int    minAreaThreshold  = 22;     // 变化图斑的最小像素面积，小于它的删除（建议 15~30，随基准图分辨率定）
    double matchScoreThreshold = 0.2;  // 匹配点置信度下限（旧 MFMatchThreshold）
    int    minInliers        = 15;     // 单应矩阵 RANSAC 内点数下限，不够则跳过这一帧
    bool   needCheckHomography = false;// 是否用下面三个阈值限制单应矩阵
    double zoomThreshold     = 0.3;    //   缩放：h00、h11 偏离 1 的最大值（倍数）
    double shiftThreshold    = 150;    //   平移：h02、h12 的最大绝对值（像素）
    double skewThreshold     = 0.25;   //   偏斜：h01、h10 的最大绝对值（占图像宽/高的倍数）
    double minWorkHeight     = 120;    // 相对（离地）高度范围（米），与文件名里的 RelAlt 比较。仅当 max > min 时启用，范围外的帧跳过
    double maxWorkHeight     = 600;    //   用来保证无人机图和底图的分辨率差不多
    bool   needSaveDebugInfo = true;   // 保存调试图片和 Html
    bool   printTimeConsumption = true;// 打印每帧各步骤耗时
    // 输出文件种类，取值 "jpg"（无轮廓）/ "outline"（带轮廓，_outline.jpg）/ "geojson" / "txt"（像素坐标）。jgw 不用配：每张图一个同名 jgw（jpg → <名>.jgw，outline → <名>_outline.jgw）。
    // SendFiles 必须是 SaveFiles 的子集；要下传时必须含 jpg 或 outline（地面端靠 图 + jgw 认一批）。
    std::vector<std::string> saveFiles = {"jpg", "outline", "geojson"};   // 写盘
    std::vector<std::string> sendFiles = {"jpg", "outline", "geojson"};   // 下传
    std::string debugStage;            // 调试阶段：空 = 正常运行；"align" = 只做配准的几何部分，把实时图 / 基准图 / 叠加并排保存，用来肉眼核对航向、偏移、缩放；
                                       // "match" = 做到匹配 + 校正（含每帧一张匹配连线 / 校正前后对比图），不做后面的检测；
                                       // "detect" = 做到变化检测（含每帧一张 基准图 | 实时图 | 检测叠加 图），不矢量化、不下传

    // ── PlatformParam：来自 MosaicPlatformConfig.json ───────────────────────
    double fy          = 1723.01;      // 垂直像素焦距，GSD = 离地高度 / fy
    int    imgHeightPx = 1080;         // fy 按这个原图高度标定

    // ── 由模型文件名解析（xxx_Width640_Height640_Class9_..._CD.onnx）───────────
    int cdInputW = 0, cdInputH = 0, cdNumClass = 0;
};

enum class RunMode { Disk, Camera };

struct WorkPaths
{
    RunMode     mode = RunMode::Disk;
    std::string workDir, imageDir, t1Dir, t1LmdbPath, outputDir;   // imageDir 仅 Disk 模式有值；outputDir 都在 workDir 下
};

// 读取并校验配置；configFile 非空时替换默认的 ChangeDetectConfig.json。
// live = true：被别的程序（合并后的 TargetTrackExe）加载。WorkDir 仍然必填；
//   不校验 GroundFilePort / TextSendPort / TextRecvPort（这几个端口由宿主程序的配置决定，调用方加载后自己覆盖）。
// 返回 false：outError 是原因。返回 true：outWarning 非空时是可继续运行的告警。
bool LoadChangeDetectConfig(ChangeDetectConfig& cfg, std::string& outError, std::string& outWarning,
                            const std::string& configFile = "", bool live = false);

// 检查两个模型和类别表是否存在，返回问题列表（空 = 正常）
std::vector<std::string> CheckChangeDetectPaths(const ChangeDetectConfig& cfg);

// 模型文件名按 '_' 切开，认 Width<n> Height<n> Class<n>；三项都解析到才返回 true
bool ParseModelFileName(const std::string& modelPath, int& width, int& height, int& numClass);

// 单独运行和合并运行共用。WorkDir 必须存在，T1 固定取 <WorkDir>/1.GuaranteedData（须含有效的 tiles.lmdb）。
// <WorkDir>/0.CameraImage 存在 → Disk：输出 <WorkDir>/2.DetectResult；不存在 → Camera：输出 <WorkDir>/<SaveDirName>，
// SaveDirName 读自 exe 旁 GroundEndConfig.json（原样使用，不再拼时间戳）。只解析，不改磁盘。
bool ResolveWorkPaths(const ChangeDetectConfig& cfg, WorkPaths& out, std::string& outError);

// Disk：删除并重建 <WorkDir>/2.DetectResult（只删这个目录，拒绝符号链接）；Camera：新建输出目录，已存在则报错（同一个 SaveDirName 不能重复启动）。都会建 <输出>/GroundEnd/ChangeDetect
bool PrepareOutputDir(const WorkPaths& paths, std::string& outError);

std::string DescribeWorkPaths(const WorkPaths& paths);
