﻿#include "ChangeDetectConfig.h"

#include <algorithm>
#include <cctype>
#include <cstdarg>
#include <cstdio>
#include <chrono>
#include <cstdlib>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <iterator>

#include "ChangeExport.h"   // ExportFiles::Parse（只用来校验文件种类的名字）
#include "1.Common/GroundEndConfig.h"   // LoadGroundEndConfig
#include "1.Common/GroundLayout.h"    // kGroundRootDir / kGroundSubChangeDetect
#include "1.Common/JsonConfig.h"   // LoadJsonNode / JsonRead / JsonPath（带 json.hpp，只能在 .cpp 里包含）

namespace fs = std::filesystem;

namespace {

std::string Fmt(const char* f, ...)
{
    char buf[512];
    va_list ap;
    va_start(ap, f);
    std::vsnprintf(buf, sizeof(buf), f, ap);
    va_end(ap);
    return buf;
}

bool ReadPlatform(ChangeDetectConfig& c, std::string& err)
{
    nlohmann::json p;
    if (!LoadJsonNode("MosaicPlatformConfig.json", "PlatformParam", p, err)) return false;
    if (!JsonRead(p, "FocalLengthYPx", c.fy, err) || !JsonRead(p, "ImgHeightPx", c.imgHeightPx, err)) { err = "[Platform] " + err; return false; }
    if (!(c.fy > 0) || c.imgHeightPx <= 0) {
        err = Fmt("[Platform] Fy(%.2f) 和 ImgHeightPx(%d) 必须 > 0", c.fy, c.imgHeightPx);
        return false;
    }
    return true;
}

bool ReadProject(const std::string& file, ChangeDetectConfig& c, std::string& err)
{
    nlohmann::json p;
    if (!LoadJsonNode(file, "ProjectParam", p, err)) return false;
    try {
        c.workDir               = JsonPath(p, "WorkDir");
        c.modelDir              = JsonPath(p, "ModelDir");
        c.splgModelPath         = JsonPath(p, "SplgModelPath");
        c.changeDetectModelPath = JsonPath(p, "ChangeDetectModelPath");
        c.changeKindFile        = JsonPath(p, "ChangeKindFile");
    } catch (const nlohmann::json::exception& e) {
        err = std::string("[Project] 路径字段类型不对: ") + e.what();
        return false;
    }
    const bool ok = JsonRead(p, "GroundFilePort",   c.groundFilePort,   err) &&
                    JsonRead(p, "SendToGround",     c.sendToGround,     err) &&
                    JsonRead(p, "TextSendPort",     c.textSendPort,     err) &&
                    JsonRead(p, "TextRecvPort",     c.textRecvPort,     err) &&
                    JsonRead(p, "InvokeIntervalMs", c.invokeIntervalMs, err);
    if (!ok) { err = "[Project] " + err; return false; }
    return true;
}

bool ReadParam(const std::string& file, ChangeDetectConfig& c, std::string& err)
{
    nlohmann::json p;
    if (!LoadJsonNode(file, "ChangeDetectParam", p, err)) return false;
    const bool ok = JsonRead(p, "MatchModelInputWH",    c.matchModelInputWH,    err) &&
                    JsonRead(p, "MinAreaThreshold",     c.minAreaThreshold,     err) &&
                    JsonRead(p, "MFMatchThreshold",     c.matchScoreThreshold,  err) &&
                    JsonRead(p, "MinInliers",           c.minInliers,           err) &&
                    JsonRead(p, "NeedCheckHomography",  c.needCheckHomography,  err) &&
                    JsonRead(p, "ZoomThreshold",        c.zoomThreshold,        err) &&
                    JsonRead(p, "ShiftThreshold",       c.shiftThreshold,       err) &&
                    JsonRead(p, "SkewThreshold",        c.skewThreshold,        err) &&
                    JsonRead(p, "MinWorkHeight",        c.minWorkHeight,        err) &&
                    JsonRead(p, "MaxWorkHeight",        c.maxWorkHeight,        err) &&
                    JsonRead(p, "NeedSaveDebugInfo",    c.needSaveDebugInfo,    err) &&
                    JsonRead(p, "PrintTimeConsumption", c.printTimeConsumption, err) &&
                    JsonRead(p, "SaveFiles",            c.saveFiles,            err) &&
                    JsonRead(p, "SendFiles",            c.sendFiles,            err) &&
                    JsonRead(p, "DebugStage",           c.debugStage,           err);
    if (!ok) { err = "[ChangeDetectParam] " + err; return false; }
    return true;
}

// 在 dir 里找以 suffix 结尾的文件，有多个时取文件名最靠后的；count 返回个数
std::string FindBySuffix(const std::string& dir, const std::string& suffix, int& count)
{
    count = 0;
    std::error_code ec;
    std::vector<std::string> hits;
    for (fs::directory_iterator it(dir, ec), end; !ec && it != end; it.increment(ec)) {
        if (!it->is_regular_file(ec)) continue;
        const std::string name = it->path().filename().string();
        if (name.size() >= suffix.size() && name.compare(name.size() - suffix.size(), suffix.size(), suffix) == 0)
            hits.push_back(it->path().string());
    }
    count = static_cast<int>(hits.size());
    if (hits.empty()) return {};
    std::sort(hits.begin(), hits.end());
    return hits.back();
}

std::string BesideExe(const std::string& p)
{
    if (p.empty()) return p;
    const fs::path q(p);
    return q.is_absolute() ? p : (GetExeDir() / q).string();
}

bool AllDigits(const std::string& s)
{
    return !s.empty() && std::all_of(s.begin(), s.end(), [](unsigned char ch) { return std::isdigit(ch) != 0; });
}

bool PortOk(int p) { return p >= 1 && p <= 65535; }

}  // namespace

bool ParseModelFileName(const std::string& modelPath, int& width, int& height, int& numClass)
{
    width = height = numClass = 0;
    const std::string stem = fs::path(modelPath).stem().string();
    size_t pos = 0;
    while (pos <= stem.size()) {
        size_t next = stem.find('_', pos);
        if (next == std::string::npos) next = stem.size();
        const std::string tok = stem.substr(pos, next - pos);
        auto take = [&](const char* key, int& out) {
            const size_t n = std::char_traits<char>::length(key);
            if (tok.size() > n && tok.compare(0, n, key) == 0 && AllDigits(tok.substr(n))) out = std::atoi(tok.c_str() + n);
        };
        take("Width", width);
        take("Height", height);
        take("Class", numClass);
        pos = next + 1;
    }
    return width > 0 && height > 0 && numClass > 0;
}

bool LoadChangeDetectConfig(ChangeDetectConfig& cfg, std::string& outError, std::string& outWarning,
                            const std::string& configFile, bool live)
{
    const std::string file = configFile.empty() ? "ChangeDetectConfig.json" : configFile;
    std::string err;
    outWarning.clear();
    outError.clear();
    if (!ReadPlatform(cfg, err))      { outError = "平台配置读取失败: " + err; return false; }
    if (!ReadProject(file, cfg, err)) { outError = "项目配置读取失败: " + err; return false; }
    if (!ReadParam(file, cfg, err))   { outError = "参数配置读取失败: " + err; return false; }

    // ── 路径补全 ────────────────────────────────────────────────────────────
    if (cfg.changeKindFile.empty()) cfg.changeKindFile = "ChangeKind.json";
    cfg.changeKindFile = BesideExe(cfg.changeKindFile);

    if (cfg.splgModelPath.empty() && !cfg.modelDir.empty()) {
        int n = 0;
        cfg.splgModelPath = FindBySuffix(cfg.modelDir, "SPLG.onnx", n);
        if (n > 1) outWarning += Fmt("[Project] %s 里有 %d 个 *SPLG.onnx，取文件名排最后的：%s\n", cfg.modelDir.c_str(), n, cfg.splgModelPath.c_str());
    }
    if (cfg.changeDetectModelPath.empty() && !cfg.modelDir.empty()) {
        int n = 0;
        cfg.changeDetectModelPath = FindBySuffix(cfg.modelDir, "CD.onnx", n);
        if (n > 1) outWarning += Fmt("[Project] %s 里有 %d 个 *CD.onnx，取文件名排最后的：%s\n", cfg.modelDir.c_str(), n, cfg.changeDetectModelPath.c_str());
    }
    if (!cfg.changeDetectModelPath.empty() &&
        !ParseModelFileName(cfg.changeDetectModelPath, cfg.cdInputW, cfg.cdInputH, cfg.cdNumClass)) {
        outError = "变化检测模型文件名要形如 xxx_Width640_Height640_Class9_..._CD.onnx（用来解析输入尺寸和类别数）: " + cfg.changeDetectModelPath;
        return false;
    }

    // ── 校验 ────────────────────────────────────────────────────────────────
    if (cfg.workDir.empty()) {
        outError = "[Project] WorkDir 不能为空（当前平台没有配置时，检查 Windows / Jetson 键）";
        return false;
    }
    if (cfg.splgModelPath.empty() || cfg.changeDetectModelPath.empty()) {
        outError = "[Project] 找不到匹配模型或变化检测模型：配置 SplgModelPath / ChangeDetectModelPath，或在 ModelDir 里放 *SPLG.onnx 和 *CD.onnx";
        return false;
    }
    if (!live && (!PortOk(cfg.groundFilePort) || !PortOk(cfg.textSendPort) || !PortOk(cfg.textRecvPort) ||
        cfg.groundFilePort == cfg.textSendPort || cfg.groundFilePort == cfg.textRecvPort || cfg.textSendPort == cfg.textRecvPort)) {
        outError = Fmt("[Project] 端口须在 1~65535 且互不相同：GroundFilePort=%d TextSendPort=%d TextRecvPort=%d",
                       cfg.groundFilePort, cfg.textSendPort, cfg.textRecvPort);
        return false;
    }
    if (cfg.invokeIntervalMs < 0) { outError = "[Project] InvokeIntervalMs 不能为负"; return false; }

    if (cfg.matchModelInputWH <= 0 || cfg.minAreaThreshold < 0 ||
        !(cfg.matchScoreThreshold > 0 && cfg.matchScoreThreshold <= 1) || cfg.minInliers < 4 ||
        !(cfg.zoomThreshold > 0) || !(cfg.shiftThreshold > 0) || !(cfg.skewThreshold > 0) ||
        cfg.minWorkHeight < 0 || cfg.maxWorkHeight < 0) {
        outError = "[ChangeDetectParam] 参数越界：MatchModelInputWH>0, MinAreaThreshold>=0, MFMatchThreshold∈(0,1], MinInliers>=4, "
                   "Zoom/Shift/SkewThreshold>0, Min/MaxWorkHeight>=0";
        return false;
    }
    if (cfg.cdInputW > cfg.matchModelInputWH || cfg.cdInputH > cfg.matchModelInputWH) {
        outError = Fmt("[ChangeDetectParam] 变化检测输入 %dx%d 不能大于匹配窗口 MatchModelInputWH=%d（检测输入是从匹配窗口中心裁出来的）",
                       cfg.cdInputW, cfg.cdInputH, cfg.matchModelInputWH);
        return false;
    }
    if (!cfg.debugStage.empty() && cfg.debugStage != kDebugStageAlign && cfg.debugStage != kDebugStageMatch && cfg.debugStage != kDebugStageDetect) {
        outError = "[ChangeDetectParam] DebugStage 只能是空、\"" + std::string(kDebugStageAlign) + "\"、\"" + kDebugStageMatch + "\" 或 \"" + kDebugStageDetect + "\"，当前是 \"" + cfg.debugStage + "\"";
        return false;
    }
    {
        ExportFiles tmp;
        std::string e2;
        if (!ExportFiles::Parse(cfg.saveFiles, tmp, e2)) { outError = "[ChangeDetectParam] SaveFiles: " + e2; return false; }
        if (!ExportFiles::Parse(cfg.sendFiles, tmp, e2)) { outError = "[ChangeDetectParam] SendFiles: " + e2; return false; }
    }
    if (cfg.maxWorkHeight > 0 && cfg.maxWorkHeight <= cfg.minWorkHeight)
        outWarning += "[ChangeDetectParam] MaxWorkHeight <= MinWorkHeight：高度范围过滤不启用\n";
    return true;
}

std::vector<std::string> CheckChangeDetectPaths(const ChangeDetectConfig& cfg)
{
    std::vector<std::string> bad;
    std::error_code ec;
    auto need = [&](const std::string& what, const std::string& path, bool dir) {
        const bool ok = dir ? fs::is_directory(path, ec) : fs::is_regular_file(path, ec);
        if (!ok) bad.push_back(what + " 不存在: " + path);
    };
    need("匹配模型", cfg.splgModelPath, false);
    need("变化检测模型", cfg.changeDetectModelPath, false);
    need("变化类别表 ChangeKindFile", cfg.changeKindFile, false);
    return bad;
}

// ── 工作目录 ────────────────────────────────────────────────────────────────
namespace {

fs::path Normalize(const std::string& p)   // 去掉末尾分隔符，让 parent_path() 取到真正的上一级
{
    fs::path q(p);
    while (!q.has_filename() && q.has_parent_path() && q != q.root_path()) q = q.parent_path();
    return q;
}

bool FindLmdb(const fs::path& t1Dir, std::string& out, std::string& err)   // <dir>/tiles.lmdb 须是含 data.mdb 的目录
{
    std::error_code ec;
    const fs::path lmdb = t1Dir / "tiles.lmdb";
    if (!fs::is_directory(t1Dir, ec)) { err = "T1 目录不存在: " + t1Dir.string(); return false; }
    if (!fs::is_directory(lmdb, ec) || !fs::exists(lmdb / "data.mdb", ec)) { err = "T1 目录里找不到有效的 tiles.lmdb: " + t1Dir.string(); return false; }
    out = lmdb.string();
    return true;
}

bool ReadSaveDirName(std::string& out, std::string& err)   // exe 旁 GroundEndConfig.json 的 SaveDirName（解析在引擎的 LoadGroundEndConfig 里）
{
    GroundEndConfig info;
    if (!LoadGroundEndConfig(info, err)) { err = "Camera 模式需要读 GroundEndConfig.json：" + err; return false; }
    out = info.saveDirName;
    // 它要当作 WorkDir 下的一级目录名：不能为空，也不能带路径分隔符或是 . / ..
    if (out.empty() || out == "." || out == ".." || out.find_first_of("/\\") != std::string::npos) {
        err = "GroundEndConfig.json 的 SaveDirName 须是非空的单级目录名（不能含 / \\，不能是 . 或 ..）: \"" + out + "\"";
        return false;
    }
    return true;
}

}  // namespace

bool ResolveWorkPaths(const ChangeDetectConfig& cfg, WorkPaths& out, std::string& err)
{
    out = WorkPaths();
    err.clear();
    if (cfg.workDir.empty()) { err = "配置 WorkDir 为空（当前平台没有配置时，检查 Windows / Jetson 键）"; return false; }
    const fs::path work = Normalize(cfg.workDir);
    out.workDir = work.string();
    std::error_code ec;
    if (!fs::exists(work, ec))       { err = "WorkDir 不存在: " + out.workDir + "（硬盘没挂载或路径写错？）"; return false; }
    if (!fs::is_directory(work, ec)) { err = "WorkDir 存在但不是目录: " + out.workDir; return false; }

    // T1 两种模式都固定取 <WorkDir>/1.GuaranteedData
    out.t1Dir = (work / kGuaranteedSubDir).string();
    if (!FindLmdb(out.t1Dir, out.t1LmdbPath, err)) return false;

    // <WorkDir>/0.CameraImage 存在 → Disk（读目录里的图，输出固定目录）；不存在 → Camera（实时，输出按 SaveDirName 命名）
    const fs::path imageDir = work / kImageSubDir;
    if (fs::is_directory(imageDir, ec)) {
        out.mode      = RunMode::Disk;
        out.imageDir  = imageDir.string();
        out.outputDir = (work / kResultSubDir).string();
        return true;
    }
    out.mode = RunMode::Camera;
    std::string saveDirName;
    if (!ReadSaveDirName(saveDirName, err)) return false;
    out.outputDir = (work / saveDirName).string();
    return true;
}

bool PrepareOutputDir(const WorkPaths& p, std::string& err)
{
    err.clear();
    std::error_code ec;
    const fs::path out(p.outputDir);
    if (p.mode == RunMode::Disk) {
        if (out != Normalize(p.workDir) / kResultSubDir) { err = "内部错误：输出目录不是 WorkDir/" + std::string(kResultSubDir) + ": " + p.outputDir; return false; }
        const fs::file_status st = fs::symlink_status(out, ec);
        if (fs::exists(st)) {
            if (fs::is_symlink(st) || !fs::is_directory(st)) { err = "输出路径是符号链接或不是目录，拒绝删除: " + p.outputDir; return false; }
            fs::remove_all(out, ec);
            if (ec || fs::exists(out)) { err = "清空输出目录失败（被其他程序占用？）: " + p.outputDir + (ec ? "（" + ec.message() + "）" : ""); return false; }
        }
    } else if (fs::exists(out, ec)) {
        err = "Camera 模式的输出目录已存在（同一个 SaveDirName 重复启动？请换 GroundEndConfig.json 的 SaveDirName）: " + p.outputDir;
        return false;
    }
    const fs::path vecDir = out / kGroundRootDir / kGroundSubChangeDetect;
    fs::create_directories(vecDir, ec);
    if (ec || !fs::is_directory(vecDir, ec)) { err = "创建输出目录失败: " + vecDir.string() + (ec ? "（" + ec.message() + "）" : ""); return false; }
    return true;
}

std::string DescribeWorkPaths(const WorkPaths& p)
{
    std::string s = std::string("[模式] ") + (p.mode == RunMode::Disk ? "Disk（回放）" : "Camera（相机）") + "\n  WorkDir   " + p.workDir + "\n";
    if (p.mode == RunMode::Disk) s += "  图片目录  " + p.imageDir + "\n";
    return s + "  T1        " + p.t1LmdbPath + "\n  输出目录  " + p.outputDir + "\n";
}
