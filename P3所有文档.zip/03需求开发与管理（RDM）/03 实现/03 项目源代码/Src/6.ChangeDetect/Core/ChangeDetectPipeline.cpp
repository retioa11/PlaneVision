﻿#include "ChangeDetectPipeline.h"

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <exception>
#include <filesystem>
#include <stdexcept>
#include <vector>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include "1.Common/EngineFunction.h"   // ParseFramePos / FramePos
#include "1.Common/GroundLayout.h"     // kGroundRootDir / kGroundSubChangeDetect
#include "1.Common/LogPrintf.h"        // LogPrintf：日志同时发地面端
#include "6.GIS/TileDB.h"              // TileDB_Open / TileDB_Close

namespace fs = std::filesystem;

namespace {

AlignParams MakeAlignParams(const ChangeDetectConfig& cfg, const WorkPaths& paths)
{
    AlignParams a;
    a.t1LmdbPath = paths.t1LmdbPath;
    a.splgModelPath = cfg.splgModelPath;
    a.loadMatcher = cfg.debugStage != kDebugStageAlign;
    a.fy = cfg.fy;
    a.imgHeightPx = cfg.imgHeightPx;
    a.zoneDeg = kGaussZoneDeg;
    a.matchWindow = cfg.matchModelInputWH;
    a.cdInputW = cfg.cdInputW;
    a.cdInputH = cfg.cdInputH;
    a.minInliers = cfg.minInliers;
    a.needCheckHomography = cfg.needCheckHomography;
    a.zoomThreshold = cfg.zoomThreshold;
    a.shiftThreshold = cfg.shiftThreshold;
    a.skewThreshold = cfg.skewThreshold;
    return a;
}

DetectorParams MakeDetectorParams(const ChangeDetectConfig& cfg)
{
    DetectorParams d;
    d.modelPath = cfg.changeDetectModelPath;
    d.inputW = cfg.cdInputW;
    d.inputH = cfg.cdInputH;
    d.numClass = cfg.cdNumClass;
    return d;
}

ExportParams MakeExportParams(const ChangeDetectConfig& cfg, const WorkPaths& paths, FileSender* sharedSender)
{
    ExportParams e;
    e.outputDir = paths.outputDir;
    e.changeKindFile = cfg.changeKindFile;
    e.sendToGround = cfg.sendToGround;
    e.groundFilePort = cfg.groundFilePort;
    e.sharedSender = sharedSender;
    e.minAreaThreshold = cfg.minAreaThreshold;
    e.gaussZoneDeg = kGaussZoneDeg;
    e.numClass = cfg.cdNumClass;
    e.needSaveDebugInfo = cfg.needSaveDebugInfo;
    std::string ignore;   // 名字已在 LoadChangeDetectConfig 里校验过
    ExportFiles::Parse(cfg.saveFiles, e.save, ignore);
    ExportFiles::Parse(cfg.sendFiles, e.send, ignore);
    return e;
}

// 带黑边的文字，在亮暗背景上都看得清
void PutLabel(cv::Mat& img, const std::string& text, cv::Point org, double scale)
{
    cv::putText(img, text, org, cv::FONT_HERSHEY_SIMPLEX, scale, cv::Scalar(0, 0, 0), 3, cv::LINE_AA);
    cv::putText(img, text, org, cv::FONT_HERSHEY_SIMPLEX, scale, cv::Scalar(255, 255, 255), 1, cv::LINE_AA);
}

}  // namespace

ChangeDetectPipeline::ChangeDetectPipeline(const ChangeDetectConfig& cfg, const WorkPaths& paths, FileSender* sharedSender)
    : cfg_(cfg), paths_(paths), align_(MakeAlignParams(cfg, paths)), detector_(MakeDetectorParams(cfg)),
      export_(MakeExportParams(cfg, paths, sharedSender)), sharedSender_(sharedSender != nullptr) {}

// 内容原样来自原 Main 里的 RunSelfCheck
int ChangeDetectPipeline::Start()
{
    const ChangeDetectConfig& cfg = cfg_;
    const WorkPaths& paths = paths_;
    LogPrintf("== 配置 ==\n匹配模型      %s（窗口 %d）\n变化检测模型  %s（输入 %dx%d，%d 类）\n类别表        %s\n端口          下传 %d，文本 %d / %d\n焦距          %.2f（图高 %d）\n",
                cfg.splgModelPath.c_str(), cfg.matchModelInputWH, cfg.changeDetectModelPath.c_str(), cfg.cdInputW, cfg.cdInputH,
                cfg.cdNumClass, cfg.changeKindFile.c_str(), cfg.groundFilePort, cfg.textSendPort, cfg.textRecvPort, cfg.fy, cfg.imgHeightPx);
    int problems = 0;
    for (const std::string& s : CheckChangeDetectPaths(cfg)) { LogPrintf("[问题] %s\n", s.c_str()); ++problems; }

    LogPrintf("== T1 ==\n");
    TileDBContext db;
    std::string err;
    bool t1Opened = false;
    if (!TileDB_Open(paths.t1LmdbPath, db, &err)) {
        LogPrintf("[问题] 打开 T1 失败: %s\n", err.c_str());
        ++problems;
    } else {
        t1Opened = true;
        LogPrintf("带号 %d（中央子午线 %d°） 瓦片 %d 像素  像素大小 %.4f 米  网格 %dx%d\n", db.gauss_zone, db.gauss_zone * kGaussZoneDeg,
                    db.tile_size, db.pixel_size_x, db.num_rows, db.num_cols);
        if (db.gauss_zone <= 0) { LogPrintf("[问题] T1 没有记录带号（老库），无法确定中央子午线\n"); ++problems; }
        if (db.pixel_size_x > 0) {
            auto ratio = [&](double h) { return h / cfg.fy / db.pixel_size_x; };   // 实时图缩放到 T1 分辨率的倍数
            const double h0 = cfg.maxWorkHeight > cfg.minWorkHeight ? cfg.minWorkHeight : 100, h1 = cfg.maxWorkHeight > cfg.minWorkHeight ? cfg.maxWorkHeight : 100;
            LogPrintf("高度 %.0f~%.0f 米：缩放到 T1 分辨率需 ×%.2f ~ ×%.2f（明显偏离 1 说明焦距与相机不匹配，或 T1 分辨率与飞行高度不搭）\n", h0, h1, ratio(h0), ratio(h1));
        }
        TileDB_Close(db);   // 关掉再由 ChangeAlign 打开：同一个 LMDB 目录在一个进程里不能同时打开两次
    }

    LogPrintf("== 配准 ==\n");
    if (t1Opened) {
        if (MakeAlignParams(cfg, paths).loadMatcher)
            LogPrintf("加载匹配配准模型……（Jetson 上首次会编译 TensorRT engine，需要一两分钟，之后读缓存）\n");
        std::fflush(stdout);
        if (!align_.Init(err)) { LogPrintf("[问题] %s\n", err.c_str()); ++problems; }
        else {
            LogPrintf("T1 已打开；窗口 %d；基准图覆盖率下限 %.0f%%；内点数下限 %d；单应检查 %s\n", cfg.matchModelInputWH, 100 * MakeAlignParams(cfg, paths).minRefCover,
                        cfg.minInliers, cfg.needCheckHomography ? "开" : "关");
            if (cfg.debugStage == kDebugStageAlign) LogPrintf("DebugStage=align：只做几何（不加载匹配配准模型），并排图存到 <输出目录>/DebugAlign/\n");
            else if (cfg.debugStage == kDebugStageMatch) LogPrintf("DebugStage=match：做到匹配 + 校正，对比图存到 <输出目录>/DebugMatch/\n");
            else if (cfg.debugStage == kDebugStageDetect) LogPrintf("DebugStage=detect：做到变化检测（不矢量化、不下传），对比图存到 <输出目录>/DebugDetect/\n");
        }
    }

    LogPrintf("== 变化检测 ==\n");
    if (!DetectEnabled()) LogPrintf("DebugStage=%s：不加载变化检测模型\n", cfg.debugStage.c_str());
    else if (!fs::exists(cfg.changeDetectModelPath)) LogPrintf("模型文件不存在，跳过加载（问题见上）\n");
    else {
        LogPrintf("加载变化检测模型……（Jetson 上首次会编译 TensorRT engine，需要一两分钟，之后读缓存）\n");
        const auto t0 = std::chrono::steady_clock::now();
        if (!detector_.Init(err)) { LogPrintf("[问题] %s\n", err.c_str()); ++problems; }
        else LogPrintf("已加载：执行器 %s；输入 %dx%d，%d 类，置信度下限 %.2f；加载 + 预热 %.1f 秒\n", detector_.Providers().c_str(), cfg.cdInputW, cfg.cdInputH,
                         cfg.cdNumClass, MakeDetectorParams(cfg).confThreshold, std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count());
    }

    LogPrintf("== 导出 ==\n");
    if (!ExportEnabled()) LogPrintf("DebugStage=%s：不矢量化、不写文件、不下传\n", cfg.debugStage.c_str());
    else if (!fs::exists(cfg.changeKindFile)) LogPrintf("类别表不存在，跳过初始化（问题见上）\n");
    else if (!export_.Init(err)) { LogPrintf("[问题] %s\n", err.c_str()); ++problems; }
    else {
        std::string ids;
        for (const ChangeKindItem& k : export_.Kinds()) ids += (ids.empty() ? "" : "、") + std::to_string(k.id) + "=" + k.name;
        LogPrintf("类别表 %zu 项：%s；面积下限 %d px；输出 %s/%s/%s\n", export_.Kinds().size(), ids.c_str(), cfg.minAreaThreshold, paths.outputDir.c_str(), kGroundRootDir, kGroundSubChangeDetect);
        const ExportParams ep = MakeExportParams(cfg, paths, nullptr);
        LogPrintf("输出文件：写盘 %s；下传 %s（jgw 跟着各自的图走，jpg 这一对永远最后发）\n", ep.save.ToString().c_str(), ep.send.ToString().c_str());
        const std::vector<int> miss = export_.MissingKinds();
        if (!miss.empty()) {
            std::string m;
            for (int k : miss) m += (m.empty() ? "" : "、") + std::to_string(k);
            LogPrintf("[注意] 模型有 %d 类（类别号 0~%d），类别表里没有 %s：这些类别照常导出，名称写 Kind<号>、颜色灰色\n", cfg.cdNumClass, cfg.cdNumClass - 1, m.c_str());
        }
        if (sharedSender_) LogPrintf("下传：使用外部共用的下传通道，%s\n", export_.SenderReady() ? "已就绪" : "未就绪");
        else if (cfg.sendToGround) LogPrintf("下传：端口 %d，%s\n", cfg.groundFilePort, export_.SenderReady() ? "已绑定，等地面端连接（没有接收者时文件会被丢弃并在日志里报）" : "未就绪");
        else LogPrintf("下传：SendToGround=false，只写文件\n");
    }

    LogPrintf("== 图片 ==\n");
    if (paths.mode != RunMode::Disk) { LogPrintf("实时模式：没有图片目录要检查\n"); return problems; }
    std::vector<std::string> names;
    std::error_code ec;
    for (fs::directory_iterator it(paths.imageDir, ec), end; !ec && it != end; it.increment(ec)) {
        std::string e = it->path().extension().string();
        std::transform(e.begin(), e.end(), e.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        if (it->is_regular_file(ec) && (e == ".jpg" || e == ".jpeg")) names.push_back(it->path().filename().string());
    }
    std::sort(names.begin(), names.end());
    LogPrintf("共 %zu 张 jpg%s\n", names.size(), names.empty() ? "（目录为空：运行时会等待新图）" : "");
    const bool heightRange = cfg.maxWorkHeight > cfg.minWorkHeight;
    int bad = 0, outOfRange = 0;
    for (const std::string& n : names) {
        FramePos pos;
        if (!ParseFramePos(n, pos) || !std::isfinite(pos.relAlt)) { ++bad; LogPrintf("[问题] 文件名解析不出经纬度或缺 RelAlt: %s\n", n.c_str()); }
        else if (heightRange && (pos.relAlt < cfg.minWorkHeight || pos.relAlt > cfg.maxWorkHeight)) ++outOfRange;
    }
    if (heightRange) LogPrintf("高度在 [%.0f, %.0f] 米内 %zu 张，超范围（运行时跳过）%d 张\n", cfg.minWorkHeight, cfg.maxWorkHeight, names.size() - bad - outOfRange, outOfRange);
    return problems + bad;
}

FrameResult ChangeDetectPipeline::Process(const PoseFrame& frame, const std::string& id)
{
    FrameResult r;
    const int index = counters_.done + counters_.skipped + counters_.failed + 1;
    try {
        LogPrintf("[帧 %d] %s  %dx%d  lon %.6f lat %.6f relAlt %.2f roll %.2f pitch %.2f yaw %.2f\n", index, id.c_str(),
                    frame.ImageMat.cols, frame.ImageMat.rows, frame.Longitude, frame.Latitude, frame.RelativeHeight, frame.Roll, frame.Pitch, frame.Yaw);
        // 配准（ChangeAlign）。DebugStage=align 只做几何；其余做到匹配 + 校正
        AlignGeometry g0;
        AlignResult ar;
        std::string why;
        bool alignOk = false;
        if (cfg_.debugStage == kDebugStageAlign) {
            const auto t0 = std::chrono::steady_clock::now();
            alignOk = align_.Geometry(frame, g0, why);
            ar.msGeometry = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
            ar.geo = g0;
        } else {
            alignOk = align_.Run(frame, ar, why);
        }
        const AlignGeometry& g = ar.geo;
        if (!g.real.empty())
            LogPrintf("        几何：缩放 ×%.3f（GSD %.4f 米 / T1 %.4f 米）  格网航向 %.2f°（收敛角 %.3f°）  姿态偏移 E%+.1f N%+.1f 米  基准图覆盖 %.1f%%  实时窗口有效 %.1f%%\n",
                        g.scale, g.gsd, g.pixelSize, g.gridYawDeg, g.convergenceDeg, g.offsetE, g.offsetN, g.refCover * 100, g.realCover * 100);
        if (ar.fit.matches > 0) {
            const AlignFit& f = ar.fit;
            LogPrintf("        匹配：%d 对，内点 %d（%.0f%%）  单应：重投影误差 %.2f px，窗口中心移动 %.1f px，局部缩放 %.3f~%.3f  对照相似变换：内点 %d，误差 %.2f px，缩放 %.3f，旋转 %.2f°，中心移动 %.1f px\n",
                        f.matches, f.inliers, f.matches ? 100.0 * f.inliers / f.matches : 0.0, f.rmsePx, f.centerShiftPx, f.edgeScaleMin, f.edgeScaleMax,
                        f.simInliers, f.simRmsePx, f.simScale, f.simRotDeg, f.simCenterShiftPx);
            if (!f.H.empty())
                LogPrintf("        H：[%.4f %.4f %.2f | %.4f %.4f %.2f | %.2e %.2e]\n", f.H.at<double>(0, 0), f.H.at<double>(0, 1), f.H.at<double>(0, 2),
                            f.H.at<double>(1, 0), f.H.at<double>(1, 1), f.H.at<double>(1, 2), f.H.at<double>(2, 0), f.H.at<double>(2, 1));
        }
        if (cfg_.printTimeConsumption) {
            if (cfg_.debugStage == kDebugStageAlign) LogPrintf("        耗时：几何 %.1f ms\n", ar.msGeometry);
            else LogPrintf("        耗时：几何 %.1f ms  匹配 %.1f ms  拟合 %.1f ms  校正 %.1f ms\n", ar.msGeometry, ar.msMatch, ar.msFit, ar.msWarp);
        }
        if (alignOk && ar.cropValid > 0 && ar.cropValid < 0.99)
            LogPrintf("        [注意] 校正后中心 %dx%d 里只有 %.1f%% 来自实时图，其余是补的灰色\n", ar.crop.width, ar.crop.height, ar.cropValid * 100);
        if (cfg_.debugStage == kDebugStageAlign && !g.real.empty()) SaveAlignDebug(g, id);
        if (cfg_.debugStage == kDebugStageMatch && !g.real.empty()) SaveMatchDebug(ar, id);   // 匹配 / 拟合失败时也存：看得出为什么失败
        // 降级：匹配 / 拟合失败但几何成功 → 不跳过，用位姿几何结果（没有匹配校正，可能是错位的）继续检测、导出、下传（DebugStage 的 align / match 不检测，不降级）。
        // 几何阶段失败（没有基准图，如 T1NoTile、覆盖不足）没法检测，仍然跳过
        bool degraded = false;
        if (!alignOk && ar.geometryOk && DetectEnabled() && align_.FallbackFromGeometry(ar)) {
            LogPrintf("        [降级] 配准失败（%s），改用位姿几何结果继续检测：没有做匹配校正，结果精度只有位姿精度\n", why.c_str());
            alignOk = true;
            degraded = true;
        }
        if (!alignOk) {
            r.status = FrameStatus::Skipped; r.reason = why;
            ++counters_.skipped;
            LogPrintf("[帧 %d] 跳过：%s（%s）\n", index, id.c_str(), why.c_str());
            return r;
        }
        if (DetectEnabled()) {
            cv::Mat label;
            if (!detector_.Detect(ar.ref, ar.real, label, why)) throw std::runtime_error(why);   // 推理失败：记为"失败"，不影响后面的帧
            const DetectStats& s = detector_.LastStats();
            std::string kinds;
            int changed = 0;
            for (int k = 1; k <= cfg_.cdNumClass; ++k) {
                const int n = cv::countNonZero(label == k);
                if (n > 0) { kinds += "  类" + std::to_string(k - 1) + " " + std::to_string(n) + " px"; changed += n; }
            }
            LogPrintf("        检测：%d 个目标，变化像素 %d（%.2f%%）%s%s\n", s.detections, changed, 100.0 * changed / label.total(), kinds.c_str(), degraded ? "  [降级帧]" : "");
            if (cfg_.printTimeConsumption) LogPrintf("        耗时：检测预处理 %.1f ms  推理 %.1f ms  后处理 %.1f ms\n", s.msPre, s.msInfer, s.msPost);
            if (cfg_.debugStage == kDebugStageDetect) SaveDetectDebug(ar, label, id);

            // 矢量化 + 写文件 + 下传。文件写不出记为"失败"；下传失败（地面端没连上等）只在日志里报，不算失败
            if (ExportEnabled()) {
                ExportFrame ef;
                ef.id = id; ef.ref = ar.ref; ef.real = ar.real; ef.label = label;
                ef.refOriginE = ar.refOriginE; ef.refOriginN = ar.refOriginN; ef.pixelSize = ar.pixelSize;
                ef.degraded = degraded;
                if (cfg_.needSaveDebugInfo || degraded) {   // HTML 日志用：说明文字 + 匹配图。降级帧一定存（DebugInfo 里的 _Match 图能看出为什么没配上）
                    char b[512];
                    std::string note;
                    std::snprintf(b, sizeof(b), "几何  缩放 x%.3f（GSD %.4f 米 / T1 %.4f 米）  格网航向 %.2f°  姿态偏移 E%+.1f N%+.1f 米  基准图覆盖 %.1f%%\n", g.scale, g.gsd, g.pixelSize, g.gridYawDeg, g.offsetE, g.offsetN, g.refCover * 100);
                    note += b;
                    if (degraded) { note += "[降级] 配准失败，未做匹配校正，直接用位姿几何结果\n"; }
                    char validTxt[32] = "未校正";   // 降级帧没有做校正，不统计有效比例
                    if (!degraded) std::snprintf(validTxt, sizeof(validTxt), "%.1f%%", ar.cropValid * 100);
                    std::snprintf(b, sizeof(b), "匹配  %d 对，内点 %d（%.0f%%），重投影误差 %.2f px，窗口中心移动 %.1f px，局部缩放 %.3f~%.3f，校正后有效 %s\n", ar.fit.matches, ar.fit.inliers,
                                  ar.fit.matches ? 100.0 * ar.fit.inliers / ar.fit.matches : 0.0, ar.fit.rmsePx, ar.fit.centerShiftPx, ar.fit.edgeScaleMin, ar.fit.edgeScaleMax, validTxt);
                    note += b;
                    std::snprintf(b, sizeof(b), "检测  %d 个目标，变化像素 %d（%.2f%%）%s\n", s.detections, changed, 100.0 * changed / label.total(), kinds.c_str());
                    note += b;
                    std::snprintf(b, sizeof(b), "耗时  几何 %.1f  匹配 %.1f  拟合 %.1f  校正 %.1f  检测预处理 %.1f  推理 %.1f  后处理 %.1f ms", ar.msGeometry, ar.msMatch, ar.msFit, ar.msWarp, s.msPre, s.msInfer, s.msPost);
                    note += b;
                    ef.note = note;
                    ef.matchImage = BuildMatchCanvas(ar);
                }
                ExportResult er;
                if (!export_.Export(ef, er, why)) throw std::runtime_error(why);
                std::string kindsOut;
                for (const auto& kv : er.perKind) kindsOut += "  类" + std::to_string(kv.first) + " " + std::to_string(kv.second);
                LogPrintf("        导出：%s，图斑 %d%s", er.name.c_str(), er.polygons, kindsOut.c_str());
                if (er.filteredSmall) LogPrintf("（面积过小滤掉 %d）", er.filteredSmall);
                if (export_.SenderReady()) LogPrintf("；下传 %d 个，缺 %d，失败 %d", er.sent, er.missing, er.failed);
                LogPrintf("\n");
                if (cfg_.printTimeConsumption) LogPrintf("        耗时：矢量化 %.1f ms  写文件 %.1f ms  下传 %.1f ms\n", er.msVector, er.msWrite, er.msSend);
            }
        }
        ++counters_.done;
        if (degraded) ++counters_.degraded;
        if (degraded) r.reason = "降级：配准失败，用位姿几何结果";
    } catch (const std::exception& e) {
        r.status = FrameStatus::Failed; r.reason = e.what();
        ++counters_.failed;
        LogPrintf("[帧 %d] 处理失败：%s（%s）\n", index, id.c_str(), r.reason.c_str());
    } catch (...) {
        r.status = FrameStatus::Failed; r.reason = "未知异常";
        ++counters_.failed;
        LogPrintf("[帧 %d] 处理失败：%s（未知异常）\n", index, id.c_str());
    }
    return r;
}

// DebugStage=align：左 实时图、中 基准图、右 两者 50% 叠加，每格中心画黄色十字。保存到 <输出目录>/DebugAlign/<id>_align.jpg。
// 同一个 id 再次出现（同一秒的两张图）时在日志里报出来，文件名加 _dupN，不覆盖。保存失败只告警，不影响这一帧。
void ChangeDetectPipeline::SaveAlignDebug(const AlignGeometry& g, const std::string& id)
{
    const int W = g.real.cols, H = g.real.rows;
    cv::Mat blend;
    cv::addWeighted(g.real, 0.5, g.ref, 0.5, 0, blend);
    std::vector<cv::Mat> panels{g.real.clone(), g.ref.clone(), blend};
    const char* names[3] = {"REAL", "REF", "BLEND 50/50"};
    for (int k = 0; k < 3; ++k) {
        cv::line(panels[k], cv::Point(W / 2, 0), cv::Point(W / 2, H - 1), cv::Scalar(0, 255, 255), 1);
        cv::line(panels[k], cv::Point(0, H / 2), cv::Point(W - 1, H / 2), cv::Scalar(0, 255, 255), 1);
        PutLabel(panels[k], names[k], cv::Point(8, 24), 0.7);
    }
    char info[160];
    std::snprintf(info, sizeof(info), "scale x%.3f  gridYaw %.2f  offset E%+.1f N%+.1f m", g.scale, g.gridYawDeg, g.offsetE, g.offsetN);
    PutLabel(panels[0], info, cv::Point(8, H - 12), 0.5);
    cv::Mat canvas;
    cv::hconcat(panels, canvas);

    SaveDebugImage("DebugAlign", "_align", id, canvas);
}

// 匹配调试图 1344 × 672：实时图 | 基准图，叠加匹配连线（绿 = 内点，红 = 外点）
cv::Mat ChangeDetectPipeline::BuildMatchCanvas(const AlignResult& r)
{
    const cv::Mat& real = r.geo.real;
    const cv::Mat& ref = r.geo.ref;
    const int W = real.cols, H = real.rows;

    cv::Mat top;
    cv::hconcat(real, ref, top);
    // 外点全画；内点最多画 150 条（匹配点成百上千时连线会把图糊成一片），点都画
    const size_t nPts = std::min(r.p0.size(), r.p1.size());
    const size_t stride = std::max<size_t>(1, static_cast<size_t>(r.fit.inliers) / 150);
    size_t inlierSeen = 0;
    for (size_t i = 0; i < nPts; ++i) {
        const bool inlier = i < r.fit.inlierMask.size() && r.fit.inlierMask[i];
        const cv::Scalar col = inlier ? cv::Scalar(0, 255, 0) : cv::Scalar(0, 0, 255);
        const cv::Point a(cvRound(r.p0[i].x), cvRound(r.p0[i].y)), b(cvRound(r.p1[i].x) + W, cvRound(r.p1[i].y));
        if (!inlier || (inlierSeen++ % stride) == 0) cv::line(top, a, b, col, 1, cv::LINE_AA);
        cv::circle(top, a, 2, col, -1, cv::LINE_AA);
        cv::circle(top, b, 2, col, -1, cv::LINE_AA);
    }
    PutLabel(top, "REAL (scaled+rotated)", cv::Point(8, 24), 0.7);
    PutLabel(top, "REF (T1)", cv::Point(W + 8, 24), 0.7);
    char info[200];
    std::snprintf(info, sizeof(info), "matches %d  inliers %d  rmse %.2f px", r.fit.matches, r.fit.inliers, r.fit.rmsePx);
    PutLabel(top, info, cv::Point(8, H - 12), 0.6);
    return top;
}

void ChangeDetectPipeline::SaveMatchDebug(const AlignResult& r, const std::string& id)
{
    SaveDebugImage("DebugMatch", "_match", id, BuildMatchCanvas(r));
}

// DebugStage=detect：左 基准图、中 实时图、右 实时图 + 检测结果（半透明填充 + 轮廓，颜色按类别号固定）。保存到 <输出目录>/DebugDetect/<id>_detect.jpg
void ChangeDetectPipeline::SaveDetectDebug(const AlignResult& r, const cv::Mat& label, const std::string& id)
{
    static const cv::Scalar palette[] = {{0, 0, 255}, {0, 255, 0}, {255, 128, 0}, {0, 255, 255}, {255, 0, 255}, {255, 255, 0}, {0, 128, 255}, {128, 0, 255}, {128, 255, 0}};
    cv::Mat left = r.ref.clone(), mid = r.real.clone(), right = r.real.clone();
    int y = 48;
    for (int k = 1; k <= cfg_.cdNumClass; ++k) {
        const cv::Mat mask = label == k;
        if (cv::countNonZero(mask) == 0) continue;
        const cv::Scalar& col = palette[(k - 1) % 9];
        cv::Mat fill = right.clone();
        fill.setTo(col, mask);
        cv::addWeighted(fill, 0.5, right, 0.5, 0, right);
        std::vector<std::vector<cv::Point>> contours;
        cv::findContours(mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
        cv::drawContours(right, contours, -1, col, 1, cv::LINE_AA);
        PutLabel(right, "class " + std::to_string(k - 1), cv::Point(8, y), 0.6);
        y += 22;
    }
    PutLabel(left, "REF", cv::Point(8, 24), 0.7);
    PutLabel(mid, "REAL (aligned)", cv::Point(8, 24), 0.7);
    PutLabel(right, "DETECT", cv::Point(8, 24), 0.7);
    cv::Mat canvas;
    cv::hconcat(std::vector<cv::Mat>{left, mid, right}, canvas);
    SaveDebugImage("DebugDetect", "_detect", id, canvas);
}

// 保存到 <输出目录>/<subDir>/<id><suffix>.jpg。同一个 id 再次出现（同一秒的两张图）时在日志里报出来，文件名加 _dupN，不覆盖。保存失败只告警
void ChangeDetectPipeline::SaveDebugImage(const char* subDir, const char* suffix, const std::string& id, const cv::Mat& canvas)
{
    int& n = debugIds_[std::string(subDir) + "/" + id];
    ++n;
    std::string stem = id;
    if (n > 1) {
        stem += "_dup" + std::to_string(n);
        LogPrintf("[警告] id 重名（%s 第 %d 次出现），调试图另存为 %s%s.jpg\n", id.c_str(), n, stem.c_str(), suffix);
    }
    std::error_code ec;
    const fs::path dir = fs::path(paths_.outputDir) / subDir;
    fs::create_directories(dir, ec);
    const std::string path = (dir / (stem + suffix + ".jpg")).string();
    if (!cv::imwrite(path, canvas, {cv::IMWRITE_JPEG_QUALITY, 92})) LogPrintf("[警告] 调试图保存失败: %s\n", path.c_str());
}
