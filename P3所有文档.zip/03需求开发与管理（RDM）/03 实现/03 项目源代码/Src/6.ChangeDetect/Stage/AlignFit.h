﻿// AlignFit.h —— 配准的第二段：由匹配点对拟合单应矩阵（RANSAC），检查，并把实时图校正到基准图上。
//
// 纯 OpenCV，不依赖 Engine / T1 / 模型，所以可以单独测试。
// 坐标约定：p0 在实时图（real）像素系，p1 在基准图（ref）像素系，H 把 real 映射到 ref（p1 ≈ H * p0）。
// 因此 warpPerspective(real, H) 得到的图与 ref 逐像素对齐。
#pragma once

#include <string>
#include <vector>

#include <opencv2/core.hpp>

struct AlignFitParams
{
    double ransacThreshPx = 3.0;       // RANSAC 重投影误差阈值（像素）
    int    minInliers     = 15;        // 内点数下限
    bool   check          = false;     // 是否检查缩放 / 平移 / 偏斜（下面三个阈值）
    double zoomThreshold  = 0.3;       //   h00、h11 偏离 1 的最大值
    double shiftThreshold = 150;       //   h02、h12 的最大绝对值（像素）
    double skewThreshold  = 0.25;      //   h01、h10 的最大绝对值
    // 透视检查（始终生效，与 check 无关；单应的左上 2x2 看不出透视项，所以另查）：窗口中心和四边中点的局部缩放必须在这个范围内，
    // 且窗口四角的透视分母必须为正。斜视（横滚约 7.5°）的正常值约 0.93~1.07
    double edgeScaleMin   = 0.8, edgeScaleMax = 1.25;
};

struct AlignFit
{
    int matches = 0;                   // 匹配点对数
    int inliers = 0;                   // 单应矩阵内点数
    cv::Mat H;                         // 3x3 CV_64F，已除以 H(2,2)。拟合失败时为空
    std::vector<uchar> inlierMask;     // 与匹配点对一一对应，1 = 内点
    double rmsePx = 0;                 // 内点上的重投影均方根误差（像素）
    double centerShiftPx = 0;          // H 把窗口中心移动的距离（像素），直观看校正量
    double edgeScaleMin = 0, edgeScaleMax = 0;   // 窗口中心和四边中点的局部缩放（最小 / 最大），反映透视梯度；1 = 无缩放
    // 对照：同一批点拟合 4 自由度相似变换（旧程序的做法），用来在第一次跑时比较两种模型
    int    simInliers = 0;
    double simScale = 0, simRotDeg = 0, simRmsePx = 0, simCenterShiftPx = 0;
};

// 拟合并检查。windowSize 是 real / ref 的边长（用来算窗口中心的移动量）。
// 成功返回 true；失败返回 false，why 是原因（out 里已有的统计量仍然有效，供日志和调试图使用）。
bool FitHomography(const std::vector<cv::Point2f>& p0, const std::vector<cv::Point2f>& p1, int windowSize,
                   const AlignFitParams& prm, AlignFit& out, std::string& why);

// 居中裁剪框：从 full 的中心裁 w × h。w、h 不能大于 full
cv::Rect CenterRect(cv::Size full, int w, int h);

// 把 src 用 srcToRef（3x3，src 像素 → ref 窗口像素）一次变换到 outSize 的窗口，窗口外补灰 128；返回 crop 区域内来自 src 的像素比例（0~1）。
// 流水线里 src 是原始航拍图，srcToRef = H * (原图 → 窗口的缩放转正矩阵)：只插值一次，而且窗口边缘外的原图像素也能用上，不会因为先裁成窗口而露出灰条。
double WarpSourceToRef(const cv::Mat& src, const cv::Mat& srcToRef, cv::Size outSize, const cv::Rect& crop, cv::Mat& warped);
