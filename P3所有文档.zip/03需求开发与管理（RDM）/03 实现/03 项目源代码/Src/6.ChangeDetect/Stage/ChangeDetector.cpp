﻿#include "ChangeDetector.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <filesystem>
#include <vector>

#include <onnxruntime_cxx_api.h>
#include <opencv2/imgproc.hpp>

#include "3.Vision/OrtProviders.h"

namespace fs = std::filesystem;

namespace {

using Clock = std::chrono::steady_clock;

double MsSince(Clock::time_point t0) { return std::chrono::duration<double, std::milli>(Clock::now() - t0).count(); }

struct Det
{
    float x1, y1, x2, y2;              // 模型输入像素坐标
    int cls;
    const float* coef;                 // 掩码系数（指向输出张量，推理结果释放前有效）
};

// BGR uint8 → 3 个 float 平面（CHW），/255，不换通道顺序
void ToPlanes(const cv::Mat& bgr, float* dst)
{
    const int h = bgr.rows, w = bgr.cols;
    cv::Mat f;
    bgr.convertTo(f, CV_32FC3, 1.0 / 255.0);
    cv::Mat planes[3] = {cv::Mat(h, w, CV_32F, dst), cv::Mat(h, w, CV_32F, dst + h * w), cv::Mat(h, w, CV_32F, dst + 2 * h * w)};
    cv::split(f, planes);              // 目标尺寸 / 类型已对，split 直接写进 dst，不重新分配
}

// 端到端输出每行：x1 y1 x2 y2 conf cls coef[nm]，模型内部已去重，不再做 NMS
std::vector<Det> Decode(const float* out, int n, int stride, const DetectorParams& p)
{
    std::vector<Det> dets;
    for (int i = 0; i < n; ++i) {
        const float* row = out + static_cast<size_t>(i) * stride;
        if (row[4] <= p.confThreshold) continue;
        const int cls = static_cast<int>(std::lround(row[5]));
        if (cls < 0 || cls >= p.numClass || cls > 254) continue;   // 标签图是 uint8，k+1 要放得下
        dets.push_back({row[0], row[1], row[2], row[3], cls, row + 6});
    }
    return dets;
}

// 掩码 = sigmoid(系数 × 原型)，只在 bbox 范围内算（原型网格上），放大到输入尺寸后 > 0.5 的像素记为 cls+1。
// 取整和裁剪的方式与旧程序 process_mask / draw_mask_bbox 一致，便于和旧结果逐像素对比
cv::Mat BuildLabelMap(const std::vector<Det>& dets, const float* proto, int nm, int ph, int pw, int W, int H)
{
    cv::Mat label = cv::Mat::zeros(H, W, CV_8UC1);
    if (dets.empty()) return label;

    cv::Mat coef(static_cast<int>(dets.size()), nm, CV_32F);
    for (size_t i = 0; i < dets.size(); ++i) std::memcpy(coef.ptr<float>(static_cast<int>(i)), dets[i].coef, nm * sizeof(float));
    const cv::Mat protoMat(nm, ph * pw, CV_32F, const_cast<float*>(proto));
    const cv::Mat logits = coef * protoMat;                  // 每个目标一行，ph*pw 列

    const float sx = static_cast<float>(W) / pw, sy = static_cast<float>(H) / ph;
    cv::Mat small(ph, pw, CV_32F), full, e, hit;
    for (size_t i = 0; i < dets.size(); ++i) {
        const Det& d = dets[i];
        const float l = std::max(0.f, d.x1) / sx, t = std::max(0.f, d.y1) / sy;
        const float r = std::min(static_cast<float>(W), d.x2) / sx, b = std::min(static_cast<float>(H), d.y2) / sy;
        cv::Rect g(static_cast<int>(l), static_cast<int>(t), static_cast<int>(r - l), static_cast<int>(b - t));
        g &= cv::Rect(0, 0, pw, ph);
        if (g.width <= 1 || g.height <= 1) continue;

        small.setTo(0);
        logits.row(static_cast<int>(i)).reshape(1, ph)(g).convertTo(e, CV_32F, -1.0);
        cv::exp(e, e);
        e += 1.0;
        cv::divide(1.0, e, e);
        e.copyTo(small(g));
        cv::resize(small, full, cv::Size(W, H), 0, 0, cv::INTER_LINEAR);

        const float l2 = std::max(0.f, d.x1), t2 = std::max(0.f, d.y1);
        const int x = static_cast<int>(std::round(l2)), y = static_cast<int>(std::round(t2));
        const int w = std::max(0, std::min(static_cast<int>(std::round(d.x2 - l2)), W - x));
        const int h = std::max(0, std::min(static_cast<int>(std::round(d.y2 - t2)), H - y));
        if (w <= 0 || h <= 0) continue;
        const cv::Rect R(x, y, w, h);
        cv::compare(full(R), 0.5f, hit, cv::CMP_GT);
        label(R).setTo(d.cls + 1, hit);
    }
    return label;
}

}  // namespace

struct ChangeDetector::Impl
{
    Ort::Env env{ORT_LOGGING_LEVEL_WARNING, "ChangeDetect"};   // 先于 session 声明：最后析构
    std::unique_ptr<Ort::Session> session;
    std::string inName;
    std::vector<std::string> outNames;
    std::vector<float> input;          // 1 × 6 × H × W
};

ChangeDetector::ChangeDetector(DetectorParams params) : params_(std::move(params)) {}
ChangeDetector::~ChangeDetector() = default;

bool ChangeDetector::Init(std::string& err)
{
    impl_.reset();
    if (params_.inputW <= 0 || params_.inputH <= 0 || params_.numClass <= 0) { err = "变化检测输入尺寸 / 类别数无效"; return false; }
    std::error_code ec;
    if (!fs::is_regular_file(fs::path(params_.modelPath), ec)) { err = "变化检测模型不存在: " + params_.modelPath; return false; }
    try {
        auto impl = std::make_unique<Impl>();
        Ort::SessionOptions opts;
        opts.SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_ALL);
        providers_ = AppendOrtProviders(opts, params_.modelPath + "_cache");
        impl->session = std::make_unique<Ort::Session>(impl->env, fs::path(params_.modelPath).c_str(), opts);

        Ort::AllocatorWithDefaultOptions alloc;
        if (impl->session->GetInputCount() != 1 || impl->session->GetOutputCount() != 2) {
            err = "变化检测模型应为 1 个输入、2 个输出（检测 + 原型），实际 " + std::to_string(impl->session->GetInputCount()) + " 个输入、"
                  + std::to_string(impl->session->GetOutputCount()) + " 个输出";
            return false;
        }
        impl->inName = impl->session->GetInputNameAllocated(0, alloc).get();
        for (size_t i = 0; i < 2; ++i) impl->outNames.push_back(impl->session->GetOutputNameAllocated(i, alloc).get());
        const auto inShape = impl->session->GetInputTypeInfo(0).GetTensorTypeAndShapeInfo().GetShape();
        if (inShape.size() != 4 || inShape[1] != 6 || (inShape[2] > 0 && inShape[2] != params_.inputH) || (inShape[3] > 0 && inShape[3] != params_.inputW)) {
            err = "变化检测模型输入形状与文件名不符：模型 [" + std::to_string(inShape.empty() ? 0 : inShape[0]) + "," + std::to_string(inShape.size() > 1 ? inShape[1] : 0)
                  + "," + std::to_string(inShape.size() > 2 ? inShape[2] : 0) + "," + std::to_string(inShape.size() > 3 ? inShape[3] : 0)
                  + "]，期望 [1,6," + std::to_string(params_.inputH) + "," + std::to_string(params_.inputW) + "]";
            return false;
        }
        impl->input.assign(static_cast<size_t>(6) * params_.inputW * params_.inputH, 0.f);
        impl_ = std::move(impl);
    } catch (const std::exception& e) {
        err = std::string("加载变化检测模型失败: ") + e.what();
        impl_.reset();
        return false;
    }

    const cv::Mat zero = cv::Mat::zeros(params_.inputH, params_.inputW, CV_8UC3);
    cv::Mat label;
    std::string why;
    if (!Detect(zero, zero, label, why)) { err = "变化检测模型预热失败: " + why; impl_.reset(); return false; }
    stats_ = DetectStats{};
    return true;
}

bool ChangeDetector::Detect(const cv::Mat& ref, const cv::Mat& real, cv::Mat& labelMap, std::string& err)
{
    stats_ = DetectStats{};
    if (!impl_) { err = "变化检测模型未加载"; return false; }
    const int W = params_.inputW, H = params_.inputH;
    for (const cv::Mat* m : {&ref, &real})
        if (m->type() != CV_8UC3 || m->cols != W || m->rows != H) { err = "变化检测输入必须是 CV_8UC3 " + std::to_string(W) + "x" + std::to_string(H); return false; }
    try {
        auto t0 = Clock::now();
        float* in = impl_->input.data();
        ToPlanes(ref, in);                                       // 基准图在前
        ToPlanes(real, in + static_cast<size_t>(3) * W * H);     // 实时图在后
        stats_.msPre = MsSince(t0);

        t0 = Clock::now();
        const auto mem = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);
        const int64_t dims[4] = {1, 6, H, W};
        Ort::Value tensor = Ort::Value::CreateTensor<float>(mem, in, impl_->input.size(), dims, 4);
        const char* inNames[] = {impl_->inName.c_str()};
        const char* outNames[] = {impl_->outNames[0].c_str(), impl_->outNames[1].c_str()};
        std::vector<Ort::Value> outs = impl_->session->Run(Ort::RunOptions{nullptr}, inNames, &tensor, 1, outNames, 2);
        stats_.msInfer = MsSince(t0);

        t0 = Clock::now();
        // 两个输出按维数区分：3 维 = 检测 [1,N,6+nm]，4 维 = 原型 [1,nm,h,w]
        const Ort::Value *det = nullptr, *proto = nullptr;
        std::vector<int64_t> ds, ps;
        for (const Ort::Value& o : outs) {
            const auto info = o.GetTensorTypeAndShapeInfo();
            if (info.GetElementType() != ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT) { err = "变化检测模型输出不是 float32"; return false; }
            if (info.GetShape().size() == 3) { det = &o; ds = info.GetShape(); }
            else if (info.GetShape().size() == 4) { proto = &o; ps = info.GetShape(); }
        }
        if (!det || !proto) { err = "变化检测模型输出的维数不是 3 + 4（检测 + 原型）"; return false; }
        const int nm = static_cast<int>(ps[1]), ph = static_cast<int>(ps[2]), pw = static_cast<int>(ps[3]);
        if (ds[2] != 6 + nm) { err = "检测输出每行 " + std::to_string(ds[2]) + " 个值，应为 6 + 掩码系数 " + std::to_string(nm) + "（不是 YOLO26 端到端分割格式？）"; return false; }
        const std::vector<Det> dets = Decode(det->GetTensorData<float>(), static_cast<int>(ds[1]), static_cast<int>(ds[2]), params_);
        stats_.detections = static_cast<int>(dets.size());
        labelMap = BuildLabelMap(dets, proto->GetTensorData<float>(), nm, ph, pw, W, H);
        stats_.msPost = MsSince(t0);
    } catch (const std::exception& e) {
        err = std::string("变化检测推理失败: ") + e.what();
        return false;
    }
    return true;
}
