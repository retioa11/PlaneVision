﻿#include "ChangeExport.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <sstream>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include "1.Common/AtomicFile.h"     // WriteFileAtomic
#include "1.Common/FileSender.h"
#include "1.Common/GroundLayout.h"   // kGroundRootDir / kGroundSubChangeDetect
#include "1.Common/LogPrintf.h"      // LogPrintf
#include "1.Common/json.hpp"
#include "6.GIS/GISHelper.h"   // GaussToLonLat

namespace fs = std::filesystem;

namespace {

// 像素 (x, y) 是整数下标，对应像素的中心；ref 左上角坐标是像素 (0,0) 的左上角，所以中心要加 0.5。
// 旧程序没加（整体偏 0.5 像素，约 0.13~0.25 米）；和旧输出对比时这是已知差异
constexpr double kPixelCenter = 0.5;
constexpr int kFramesPerHtml = 100;   // HTML 日志每个文件放多少帧：第 1~100 帧进 ChangeDetectLog_00.html，第 101~200 帧进 _01，以此类推

std::string Fmt(const char* f, ...)
{
    char buf[512];
    va_list ap;
    va_start(ap, f);
    std::vsnprintf(buf, sizeof(buf), f, ap);
    va_end(ap);
    return buf;
}

// 多边形顶点（不闭合）的有向面积：> 0 逆时针（x 向东、y 向北）
double SignedArea(const std::vector<cv::Point2d>& r)
{
    double a = 0;
    for (size_t i = 0, n = r.size(); i < n; ++i) {
        const cv::Point2d& p = r[i];
        const cv::Point2d& q = r[(i + 1) % n];
        a += p.x * q.y - q.x * p.y;
    }
    return a / 2;
}

bool WriteTextFile(const fs::path& path, const std::string& text, std::string& err)
{
    return WriteFileAtomic(path, text, &err);   // 先写 .tmp 再 rename（引擎 1.Common/AtomicFile.h）
}

// 没配准的帧：在图左上角标出来，地面端和事后看图都能一眼分辨（只占一小条，不影响 jgw 叠放）
void DrawDegradedTag(cv::Mat& canvas)
{
    const char* tag = "NO REGISTRATION (pose only)";
    cv::putText(canvas, tag, cv::Point(8, 24), cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 0, 0), 3, cv::LINE_AA);
    cv::putText(canvas, tag, cv::Point(8, 24), cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 0, 255), 1, cv::LINE_AA);
}

std::string HtmlEscape(const std::string& s)
{
    std::string o;
    for (char c : s) {
        if (c == '&') o += "&amp;";
        else if (c == '<') o += "&lt;";
        else if (c == '>') o += "&gt;";
        else o += c;
    }
    return o;
}

}  // namespace

bool ExportFiles::Parse(const std::vector<std::string>& names, ExportFiles& out, std::string& err)
{
    ExportFiles r;
    r.jpg = r.outline = r.geojson = r.txt = false;
    for (std::string n : names) {
        std::transform(n.begin(), n.end(), n.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        if (n == "jpg") r.jpg = true;
        else if (n == "outline") r.outline = true;
        else if (n == "geojson") r.geojson = true;
        else if (n == "txt") r.txt = true;
        else { err = "未知的文件种类 \"" + n + "\"（只能是 jpg / outline / geojson / txt）"; return false; }
    }
    out = r;
    return true;
}

std::string ExportFiles::ToString() const
{
    std::string s;
    auto add = [&](bool on, const char* n) { if (on) s += (s.empty() ? "" : " ") + std::string(n); };
    add(jpg, "jpg"); add(outline, "outline"); add(geojson, "geojson"); add(txt, "txt");
    return s.empty() ? "（无）" : s;
}

ChangeExport::ChangeExport(ExportParams params) : params_(std::move(params)) {}
ChangeExport::~ChangeExport() = default;

bool ChangeExport::SenderReady() const { return sender_ && sender_->IsReady(); }

std::vector<int> ChangeExport::MissingKinds() const
{
    std::vector<int> miss;
    for (int k = 0; k < params_.numClass; ++k)
        if (!kindIndex_.count(k)) miss.push_back(k);
    return miss;
}

bool ChangeExport::Init(std::string& err)
{
    // ── 类别表：[{"Id":0,"Name":"...","Color":[r,g,b]}, ...]，UTF-8，允许 // 注释 ──
    kinds_.clear();
    kindIndex_.clear();
    {
        std::ifstream ifs(params_.changeKindFile, std::ios::binary);
        if (!ifs.is_open()) { err = "打不开类别表: " + params_.changeKindFile; return false; }
        std::string text((std::istreambuf_iterator<char>(ifs)), std::istreambuf_iterator<char>());
        if (text.compare(0, 3, "\xEF\xBB\xBF") == 0) text.erase(0, 3);
        try {
            const nlohmann::json root = nlohmann::json::parse(text, nullptr, true, true);
            if (!root.is_array()) { err = "类别表应是 JSON 数组: " + params_.changeKindFile; return false; }
            for (size_t i = 0; i < root.size(); ++i) {
                const nlohmann::json& it = root[i];
                if (!it.is_object() || !it.contains("Id") || !it.contains("Name") || !it.contains("Color")) {
                    err = Fmt("类别表第 %zu 项缺 Id / Name / Color", i + 1);
                    return false;
                }
                ChangeKindItem k;
                k.id = it["Id"].get<int>();
                k.name = it["Name"].get<std::string>();
                const nlohmann::json& col = it["Color"];
                if (!col.is_array() || col.size() != 3) { err = Fmt("类别表第 %zu 项的 Color 应是 [r,g,b]", i + 1); return false; }
                int rgb[3];
                for (int c = 0; c < 3; ++c) {
                    rgb[c] = col[c].get<int>();
                    if (rgb[c] < 0 || rgb[c] > 255) { err = Fmt("类别表第 %zu 项的 Color 超出 0~255", i + 1); return false; }
                }
                k.colorBgr = cv::Scalar(rgb[2], rgb[1], rgb[0]);
                if (k.id < 0) { err = Fmt("类别表第 %zu 项的 Id 为负: %d", i + 1, k.id); return false; }
                if (kindIndex_.count(k.id)) { err = Fmt("类别表里 Id %d 重复", k.id); return false; }
                kindIndex_[k.id] = kinds_.size();
                kinds_.push_back(std::move(k));
            }
        } catch (const nlohmann::json::exception& e) {
            err = std::string("解析类别表失败: ") + e.what();
            return false;
        }
        if (kinds_.empty()) { err = "类别表是空的: " + params_.changeKindFile; return false; }
    }

    // ── 文件种类 ──
    if (params_.send.jpg && !params_.save.jpg) { err = "SendFiles 含 jpg，但 SaveFiles 没有"; return false; }
    if (params_.send.outline && !params_.save.outline) { err = "SendFiles 含 outline，但 SaveFiles 没有"; return false; }
    if (params_.send.geojson && !params_.save.geojson) { err = "SendFiles 含 geojson，但 SaveFiles 没有"; return false; }
    if (params_.send.txt && !params_.save.txt) { err = "SendFiles 含 txt，但 SaveFiles 没有"; return false; }
    if (params_.send.Any() && !params_.send.jpg && !params_.send.outline) { err = "SendFiles 要下传时必须含 jpg 或 outline（地面端每帧都靠 图 + jgw 认一批，包括没有变化的帧）"; return false; }

    // ── 输出目录 ──
    std::error_code ec;
    const fs::path groundRoot = fs::path(params_.outputDir) / kGroundRootDir;
    fs::create_directories(groundRoot / kGroundSubChangeDetect, ec);
    if (ec) { err = "建不出输出目录 " + (groundRoot / kGroundSubChangeDetect).string() + ": " + ec.message(); return false; }
    if (params_.needSaveDebugInfo) fs::create_directories(fs::path(params_.outputDir) / "DebugInfo", ec);

    // ── 下传通道 ──
    ownedSender_.reset();
    sender_ = nullptr;
    if (params_.sharedSender) {
        sender_ = params_.sharedSender;   // 外部创建、外部管理；就绪与否用 SenderReady() 看
    } else if (params_.sendToGround) {
        ownedSender_ = std::make_unique<FileSender>();
        std::string e2;
        if (!ownedSender_->Init(params_.groundFilePort, groundRoot.string(), &e2)) { err = e2; ownedSender_.reset(); return false; }
        sender_ = ownedSender_.get();
    }
    return true;
}

const ChangeKindItem* ChangeExport::FindKind(int id)
{
    const auto it = kindIndex_.find(id);
    if (it != kindIndex_.end()) return &kinds_[it->second];
    if (warnedKinds_.insert(id).second)
        LogPrintf("[注意] 类别号 %d 不在类别表里，导出时名称用 Kind%d、颜色用灰色\n", id, id);
    return nullptr;
}

std::string ChangeExport::KindName(int id)
{
    const ChangeKindItem* k = FindKind(id);
    return k ? k->name : "Kind" + std::to_string(id);
}

cv::Scalar ChangeExport::KindColor(int id)
{
    const ChangeKindItem* k = FindKind(id);
    return k ? k->colorBgr : cv::Scalar(160, 160, 160);
}

// 每个类别单独提轮廓：重叠处不会因为"取轮廓第一个点的标签"而串类
void ChangeExport::Vectorize(const ExportFrame& in, std::vector<Polygon>& polys, ExportResult& out)
{
    const double px = in.pixelSize;
    for (int k = 1; k <= params_.numClass; ++k) {
        const cv::Mat mask = in.label == k;
        if (cv::countNonZero(mask) == 0) continue;
        std::vector<std::vector<cv::Point>> contours;
        cv::findContours(mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
        int kept = 0;
        for (const auto& c : contours) {
            std::vector<cv::Point> approx;
            cv::approxPolyDP(c, approx, 0.01 * cv::arcLength(c, true), true);   // 周长 1% 的简化误差，同旧程序
            if (approx.size() < 3) continue;                                     // 两个点的"面"
            if (cv::contourArea(approx) < params_.minAreaThreshold) { ++out.filteredSmall; continue; }
            Polygon p;
            p.kind = k - 1;
            p.px = std::move(approx);
            for (const cv::Point& v : p.px) {
                const double E = in.refOriginE + (v.x + kPixelCenter) * px;
                const double N = in.refOriginN - (v.y + kPixelCenter) * px;   // 行号增大 → 北坐标减小
                double lon = 0, lat = 0;
                GaussToLonLat(E, N, params_.gaussZoneDeg, lon, lat);
                p.lonlat.emplace_back(lon, lat);
            }
            polys.push_back(std::move(p));
            ++kept;
        }
        if (kept > 0) out.perKind.emplace_back(k - 1, kept);
    }
    out.polygons = static_cast<int>(polys.size());
}

// jpg 原子写（先写 .tmp 再改名）：下传时不会读到写了一半的图
bool ChangeExport::WriteJpg(const std::string& file, const cv::Mat& img, std::string& err)
{
    std::vector<unsigned char> buf;
    if (!cv::imencode(".jpg", img, buf, {cv::IMWRITE_JPEG_QUALITY, params_.jpegQuality})) { err = "编码 jpg 失败: " + file; return false; }
    return WriteFileAtomic(fs::path(file), buf, &err);
}

// jgw：经纬度的世界文件，写成 <stem>.jgw。jpg 传 "<名>"，outline 传 "<名>_outline"（两张图尺寸、范围完全一样，内容相同，各写一份）
bool ChangeExport::WriteWorldFile(const std::string& stem, const ExportFrame& in, std::string& err)
{
    const fs::path dir = fs::path(params_.outputDir) / kGroundRootDir / kGroundSubChangeDetect;
    // 世界文件：整幅图按两个对角（角点）的经纬度求一组仿射参数，旋转项写 0，同旧程序。
    // 近似：高斯格网相对经纬网转了一个子午线收敛角，这里没表达。离中央子午线越远误差越大：偏 0.1° 时角点约差 1 个像素，
    // 偏 0.75° 约 6 个，偏 1.4°（带边缘）约 11 个。只影响 jpg 在地图上的叠放；geojson 是逐点转换的，不受影响。
    // 文件里写的是左上像素的中心（世界文件的约定），旧程序写的是左上角点
    const double W = in.real.cols, H = in.real.rows, px = in.pixelSize;
    double lon0, lat0, lon1, lat1;
    GaussToLonLat(in.refOriginE, in.refOriginN, params_.gaussZoneDeg, lon0, lat0);
    GaussToLonLat(in.refOriginE + W * px, in.refOriginN - H * px, params_.gaussZoneDeg, lon1, lat1);
    const double rx = (lon1 - lon0) / W, ry = (lat1 - lat0) / H;
    // 分辨率约 2.5e-6 度，要写够有效数字（旧程序只写 8 位小数，只有 2~3 位有效数字，整幅图会累积出十几个像素的误差）
    const std::string world = Fmt("%.12f\n0\n0\n%.12f\n%.10f\n%.10f\n", rx, ry, lon0 + kPixelCenter * rx, lat0 + kPixelCenter * ry);
    return WriteTextFile(dir / (stem + ".jgw"), world, err);
}

// txt：每个图斑一行，"类别号 x y x y ..."（x y 是 ref / real 图上的像素坐标），同旧程序
bool ChangeExport::WriteTxt(const std::string& stem, const std::vector<Polygon>& polys, std::string& err)
{
    std::string t;
    for (const Polygon& p : polys) {
        t += std::to_string(p.kind);
        for (const cv::Point& v : p.px) t += " " + std::to_string(v.x) + " " + std::to_string(v.y);
        t += "\n";
    }
    return WriteTextFile(fs::path(params_.outputDir) / kGroundRootDir / kGroundSubChangeDetect / (stem + ".txt"), t, err);
}

// geojson：FeatureCollection，外环逆时针（RFC 7946），首尾闭合，坐标 7 位小数（约 1 厘米）
bool ChangeExport::WriteGeoJson(const std::string& stem, const std::vector<Polygon>& polys, std::string& err)
{
    auto r7 = [](double v) { return std::round(v * 1e7) / 1e7; };
    nlohmann::json features = nlohmann::json::array();
    for (size_t i = 0; i < polys.size(); ++i) {
        std::vector<cv::Point2d> ring = polys[i].lonlat;
        if (SignedArea(ring) < 0) std::reverse(ring.begin(), ring.end());
        ring.push_back(ring.front());
        nlohmann::json coords = nlohmann::json::array();
        for (const cv::Point2d& v : ring) coords.push_back(nlohmann::json::array({r7(v.x), r7(v.y)}));
        features.push_back({{"type", "Feature"},
                            {"geometry", {{"type", "Polygon"}, {"coordinates", nlohmann::json::array({coords})}}},
                            {"properties", {{"id", static_cast<int>(i)}, {"kindId", polys[i].kind}, {"kind", KindName(polys[i].kind)}}}});
    }
    const nlohmann::json root = {{"type", "FeatureCollection"}, {"features", features}};
    return WriteTextFile(fs::path(params_.outputDir) / kGroundRootDir / kGroundSubChangeDetect / (stem + ".geojson"),
                         root.dump(-1, ' ', false, nlohmann::json::error_handler_t::replace), err);
}

// DebugInfo：每帧三张图 + 每 100 帧一个 HTML。失败只告警
//   _Reference.jpg  基准图 + 检测结果（半透明填充 + 轮廓）    _Realtime.jpg  校正后实时图 + 检测结果    _Match.jpg  匹配连线 / 校正前后对比（有才存）
// HTML 每帧一个可折叠条目：标题 = 序号 + 完整文件名（含位姿）+ 图斑数；正文 = 说明文字 + 三张图并排（匹配图点击看原图）
void ChangeExport::WriteDebugInfo(const std::string& stem, const ExportFrame& in, const std::vector<Polygon>& polys, const ExportResult& r)
{
    const fs::path dir = fs::path(params_.outputDir);
    { std::error_code ec; fs::create_directories(dir, ec); }   // 降级帧在 needSaveDebugInfo = false 时也会写，目录按需建
    auto withDetect = [&](const cv::Mat& base) {
        cv::Mat o = base.clone();
        for (const Polygon& p : polys) cv::polylines(o, std::vector<std::vector<cv::Point>>{p.px}, true, KindColor(p.kind), 2);
        return o;
    };
    const struct { const char* suffix; cv::Mat img; } shots[] = {{"_Reference", withDetect(in.ref)}, {"_Realtime", withDetect(in.real)}, {"_Match", in.matchImage}};
    for (const auto& s : shots) {
        if (s.img.empty()) continue;
        const std::string path = (dir / (stem + s.suffix + ".jpg")).string();
        if (!cv::imwrite(path, s.img, {cv::IMWRITE_JPEG_QUALITY, 90})) { LogPrintf("[警告] 调试图保存失败: %s\n", path.c_str()); return; }
    }

    const fs::path html = dir / Fmt("ChangeDetectLog_%02d.html", (frameCount_ - 1) / kFramesPerHtml);   // 每 kFramesPerHtml 帧一个文件；frameCount_ 已含本帧
    const bool fresh = !fs::exists(html);
    std::ofstream ofs(html, std::ios::binary | std::ios::app);
    if (!ofs.is_open()) { LogPrintf("[警告] HTML 日志写不出: %s\n", html.string().c_str()); return; }
    std::ostringstream h;
    if (fresh) h << "<!DOCTYPE html>\n<meta charset=\"utf-8\">\n<title>变化检测日志</title>\n"
                    "<style>.r{display:flex;gap:4px;align-items:flex-start}.r img{display:block;flex:none}pre{margin:2px 6px;font-size:13px}</style>\n";
    std::string kinds;
    for (const auto& kv : r.perKind) kinds += "  " + HtmlEscape(KindName(kv.first)) + " " + std::to_string(kv.second);
    h << "<details open>\n<summary>" << frameCount_ << "_" << HtmlEscape(stem)
      << kinds << (r.filteredSmall ? "  （面积过小滤掉 " + std::to_string(r.filteredSmall) + "）" : std::string()) << "</summary>\n";
    if (!in.note.empty()) h << "<pre>" << HtmlEscape(in.note) << "</pre>\n";
    const int imgH = in.ref.rows;   // 基准图 / 实时图的实际高度，匹配图按它定高、宽度等比缩放
    h << "<div class=\"r\"><img src=\"" << stem << "_Reference.jpg\"><img src=\"" << stem << "_Realtime.jpg\">";
    if (!in.matchImage.empty()) h << "<a href=\"" << stem << "_Match.jpg\"><img style=\"height:" << imgH << "px;width:auto\" src=\"" << stem << "_Match.jpg\"></a>";
    h << "</div>\n</details>\n";
    ofs << h.str();
}

bool ChangeExport::Export(const ExportFrame& in, ExportResult& out, std::string& err)
{
    out = ExportResult();
    if (kinds_.empty()) { err = "ChangeExport 还没有 Init"; return false; }
    if (in.real.empty() || in.real.type() != CV_8UC3 || in.ref.size() != in.real.size() || in.ref.type() != CV_8UC3 ||
        in.label.size() != in.real.size() || in.label.type() != CV_8UC1) { err = "输入图为空或类型 / 尺寸不一致"; return false; }
    if (!(in.pixelSize > 0)) { err = "像素大小无效"; return false; }

    const auto t0 = std::chrono::steady_clock::now();
    auto ms = [](std::chrono::steady_clock::time_point a) { return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - a).count(); };
    std::vector<Polygon> polys;
    Vectorize(in, polys, out);
    out.msVector = ms(t0);

    // 文件名：<id>_Count<图斑数>（图斑数要先矢量化才知道）；重名加 _dupN
    const std::string base = in.id + "_Count" + std::to_string(polys.size());
    const int n = ++nameCount_[base];
    std::string stem = base;
    if (n > 1) {
        stem += "_dup" + std::to_string(n);
        LogPrintf("[警告] 文件名重名（%s 第 %d 次出现），导出为 %s\n", base.c_str(), n, stem.c_str());
    }
    out.name = stem;
    ++frameCount_;

    const auto t1 = std::chrono::steady_clock::now();
    const ExportFiles& sv = params_.save;
    const fs::path dir = fs::path(params_.outputDir) / kGroundRootDir / kGroundSubChangeDetect;
    bool wroteJpg = false, wroteOutline = false, wroteGeo = false, wroteTxt = false;

    // 矢量文件先写，图片后写，jgw 最后（地面端以 <名>.jgw 为"一批到齐"的标志，下传顺序也是这样）
    if (!polys.empty()) {
        if (sv.geojson) { if (!WriteGeoJson(stem, polys, err)) return false; wroteGeo = true; }
        if (sv.txt)     { if (!WriteTxt(stem, polys, err))     return false; wroteTxt = true; }
    }
    if (sv.jpg) {
        cv::Mat plain = in.real;   // 不带轮廓；只有降级帧要加红字，才复制
        if (in.degraded) { plain = in.real.clone(); DrawDegradedTag(plain); }
        if (!WriteJpg((dir / (stem + ".jpg")).string(), plain, err)) return false;
        wroteJpg = true;
    }
    // 无图斑时 outline 和 jpg 完全一样，不重复写、不重复传；例外：只下传 outline（SendFiles 没有 jpg）时，无图斑的帧也要写，
    // 否则地面端收不到这一帧（它每帧靠 图 + jgw 认一批）
    const bool outlineIsOnlyImageSent = params_.send.outline && !params_.send.jpg;
    if (sv.outline && (!polys.empty() || outlineIsOnlyImageSent)) {
        cv::Mat canvas = in.real.clone();
        for (const Polygon& p : polys) cv::polylines(canvas, std::vector<std::vector<cv::Point>>{p.px}, true, KindColor(p.kind), 2);
        if (in.degraded) DrawDegradedTag(canvas);
        if (!WriteJpg((dir / (stem + "_outline.jpg")).string(), canvas, err)) return false;
        wroteOutline = true;
    }
    // 每张图一个同名 jgw：<名>.jpg → <名>.jgw；<名>_outline.jpg → <名>_outline.jgw（两张图范围完全一样，内容相同，但各自独立成对）
    if (wroteOutline) { if (!WriteWorldFile(stem + "_outline", in, err)) return false; }
    if (wroteJpg)     { if (!WriteWorldFile(stem, in, err))             return false; }
    if (params_.needSaveDebugInfo || in.degraded) WriteDebugInfo(stem, in, polys, out);
    out.msWrite = ms(t1);

    if (sender_) {
        const auto t2 = std::chrono::steady_clock::now();
        const ExportFiles& sd = params_.send;
        std::vector<std::string> files;   // 只发这一帧实际写出、且配置要传的；顺序 = 矢量 → 图 → jgw
        auto add = [&](const std::string& name) { files.push_back(GroundRelPath(kGroundSubChangeDetect, name)); };
        if (wroteGeo && sd.geojson) add(stem + ".geojson");
        if (wroteTxt && sd.txt) add(stem + ".txt");
        if (wroteOutline && sd.outline) { add(stem + "_outline.jpg"); add(stem + "_outline.jgw"); }   // outline 图 + 它的 jgw；有 jpg 时先于 jpg 对，只传 outline 时它就是最后一对
        if (wroteJpg && sd.jpg) { add(stem + ".jpg"); add(stem + ".jgw"); }   // jpg 对永远最后（地面端以 <名>.jgw 到达作为一批到齐的标志）
        const FileSender::Result r = sender_->SendFiles(files);
        out.sent = r.sent; out.missing = r.missing; out.failed = r.failed;
        out.msSend = ms(t2);
    }
    return true;
}
