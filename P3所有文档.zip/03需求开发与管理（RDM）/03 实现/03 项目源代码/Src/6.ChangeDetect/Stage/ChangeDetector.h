﻿// ChangeDetector.h —— 阶段 2：变化检测。输入一对对齐好的图（基准图在前、实时图在后，BGR），输出标签图。
//
// 模型：YOLO26 端到端分割（NMS-free）。输入 images [1,6,H,W]（基准图 3 通道在前，实时图 3 通道在后，各 /255，不换通道顺序），
// 输出 [1,N,6+32]（x1 y1 x2 y2 conf cls + 32 个掩码系数）和原型 [1,32,H/4,W/4]。
// 执行器：Jetson = TensorRT(FP16)→CUDA→CPU，其他平台 CPU（见 3.Vision/OrtProviders.h）。预处理、解码、掩码都在 CPU 上做。
// 不依赖 ChangeDetectConfig：参数由流水线填进 DetectorParams。onnxruntime 头文件不外露（Impl 在 .cpp 里）。
// 线程：只能由一个线程调用。
#pragma once

#include <memory>
#include <string>

#include <opencv2/core.hpp>

struct DetectorParams
{
    std::string modelPath;             // 变化检测 onnx
    int   inputW = 640, inputH = 640;  // 模型输入尺寸（从模型文件名解析）
    int   numClass = 2;                // 类别数；类别号 >= numClass 的目标忽略
    float confThreshold = 0.25f;       // 置信度下限
};

// 最近一次 Detect 的统计
struct DetectStats
{
    int    detections = 0;             // 过置信度门限的目标个数
    double msPre = 0, msInfer = 0, msPost = 0;
};

class ChangeDetector
{
public:
    explicit ChangeDetector(DetectorParams params);
    ~ChangeDetector();                 // 在 .cpp 里定义：Impl 在此处是不完整类型
    ChangeDetector(const ChangeDetector&)            = delete;
    ChangeDetector& operator=(const ChangeDetector&) = delete;

    // 加载模型并用全零图预热一次（Jetson 上首次会编译 TensorRT engine，一两分钟，之后读缓存；预热把这段时间放在启动阶段）。
    // 失败返回 false，err 是原因
    bool Init(std::string& err);

    // 实际挂上的执行器，如 "TensorRT(FP16) → CUDA → CPU"；Init 成功后有效
    const std::string& Providers() const { return providers_; }

    // ref / real：CV_8UC3，inputH × inputW。labelMap：CV_8UC1，同尺寸，0 = 背景，k+1 = 类别 k；多个目标重叠时后出现的覆盖先出现的。
    // 返回 false = 推理失败（err 是原因）；没有目标返回 true、labelMap 全 0
    bool Detect(const cv::Mat& ref, const cv::Mat& real, cv::Mat& labelMap, std::string& err);

    const DetectStats& LastStats() const { return stats_; }

private:
    struct Impl;
    DetectorParams params_;
    std::unique_ptr<Impl> impl_;
    std::string providers_;
    DetectStats stats_;
};
