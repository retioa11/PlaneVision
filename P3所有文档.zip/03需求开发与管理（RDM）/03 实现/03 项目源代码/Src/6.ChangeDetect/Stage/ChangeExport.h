﻿// ChangeExport.h —— 阶段 3：矢量化与下传。把标签图转成多边形，写文件，发给地面端。
//
// 流程：每个类别单独 findContours(RETR_EXTERNAL) + approxPolyDP(周长 1%)，按面积过滤；
// 像素 → 高斯坐标（ref 左上角 + 像素 × 像素大小）→ 经纬度（3° 带）；
// 写文件，再用 FileSender（ZMQ）下传。写哪些、传哪些由 ExportFiles 决定（配置 SaveFiles / SendFiles）：
//   jpg      <名>.jpg           校正后的实时图，不带轮廓
//   outline  <名>_outline.jpg   同一张图 + 各图斑轮廓。无图斑的帧不写（内容与 jpg 完全相同）；例外：下传只含 outline、不含 jpg 时，无图斑的帧也写（保证每帧都有图下传）
//   geojson  <名>.geojson       图斑多边形（WGS84，FeatureCollection）。无图斑的帧不写
//   txt      <名>.txt           图斑的像素坐标（每个图斑一行）。无图斑的帧不写
//   jgw      <名>.jgw / <名>_outline.jgw   世界文件，不单独配置：每张图一个同名 jgw（jpg → <名>.jgw，outline → <名>_outline.jgw），
//                               写了哪张图就写哪个，下传时紧跟各自的图。下传顺序：矢量 → outline + outline.jgw → jpg + jpg.jgw。
//                               地面端以"<名>.jgw 和 <名>.jpg 都在"作为一批到齐的标志，所以 jpg 这一对必须最后发。
// （已删除 shp / dbf / shx / prj / cpg：多边形统一用 geojson。）
// needSaveDebugInfo 时另写 DebugInfo/：每帧 基准图+检测、实时图+检测、匹配连线图，和每 100 帧一个的 HTML 日志（完整文件名、说明文字、三张图）。
//
// 坐标：AlignResult 的 refOriginE/N 已经是"送去检测的 ref 左上角"（裁中心时的偏移在 ChangeAlign 里算好了），
//       所以这里不再加 (matchWindow - cdInput) / 2 的 padding；加了就重复了。
// 文件名：<id>_Count<图斑数>（id 通常是 hhmmss_RtkLon…_Yaw…，带位姿；图斑数 = 过了面积门限的个数）；本次运行里重名时加 _dupN 并报日志，不静默覆盖。
// 无变化（没有图斑过面积门限）：只出 jpg / jpg 的 jgw，不写 outline（含它的 jgw）/ geojson / txt；下传只发这一帧实际写出的文件。
// 不依赖 ChangeDetectConfig：参数由流水线填进 ExportParams。
// 线程：只能由一个线程调用。
#pragma once

#include <map>
#include <memory>
#include <set>
#include <string>
#include <utility>
#include <vector>

#include <opencv2/core.hpp>

class FileSender;   // 1.Common/FileSender.h

// 要写 / 要传的文件种类（见文件开头的说明）。jgw 不在其中：有图就有 jgw
struct ExportFiles
{
    bool jpg = true, outline = true, geojson = true, txt = false;

    bool Any() const { return jpg || outline || geojson || txt; }

    // 从配置里的名字列表解析（"jpg" "outline" "geojson" "txt"，不区分大小写）。未知名字返回 false，err 写原因；空列表 = 全不要
    static bool Parse(const std::vector<std::string>& names, ExportFiles& out, std::string& err);
    std::string ToString() const;   // 日志用，如 "jpg outline geojson"
};

struct ExportParams
{
    std::string outputDir;             // 输出目录；矢量结果写到 <outputDir>/GroundEnd/ChangeDetect，下传以 <outputDir>/GroundEnd 为根
    std::string changeKindFile;        // 类别表（Id / Name / Color）的完整路径
    bool sendToGround = true;          // false = 只写文件不下传（不绑定端口；Windows 上没有地面端时用）
    int  groundFilePort = 4444;        // 下传端口
    FileSender* sharedSender = nullptr;   // 非空 = 用外部创建的下传通道（根目录须是 <outputDir>/GroundEnd；生命周期由外部负责），此时 sendToGround / groundFilePort 被忽略；
                                          // 空 = 按 sendToGround / groundFilePort 自己创建（单独运行的变化检测程序用这种）
    int  minAreaThreshold = 22;        // 图斑最小像素面积（按简化后的多边形算）
    int  gaussZoneDeg = 3;             // 高斯带宽；带号取自 refOriginE 的百万位
    int  numClass = 0;                 // 模型类别数；类别号 0 .. numClass-1，对应标签图 1 .. numClass
    int  jpegQuality = 90;
    ExportFiles save;                  // 写盘的文件种类
    ExportFiles send;                  // 下传的文件种类，须是 save 的子集；有下传时必须含 jpg 或 outline（地面端每帧靠 图 + jgw 认一批）
    bool needSaveDebugInfo = true;     // 写 <outputDir>/DebugInfo/ 下的图片和 HTML 日志
};

// 类别表的一项
struct ChangeKindItem
{
    int         id = 0;
    std::string name;                  // UTF-8
    cv::Scalar  colorBgr;              // 文件里是 [r,g,b]，这里已换成 BGR，直接给 OpenCV 用
};

// 一帧的输入
struct ExportFrame
{
    std::string id;                    // 不含扩展名的文件名
    cv::Mat ref, real;                 // CV_8UC3，cdInputH × cdInputW；real 是校正后的实时图
    cv::Mat label;                     // CV_8UC1，同尺寸；0 = 背景，k+1 = 类别 k
    double refOriginE = 0, refOriginN = 0;   // ref 左上角的高斯坐标（米，E 含带号）
    double pixelSize = 0;              // 米 / 像素
    std::string note;                  // 多行说明（'\n' 分隔），原样进 HTML 日志：位姿、匹配、几何、检测、耗时等，可空
    cv::Mat matchImage;                // 匹配连线 / 校正前后对比图（BGR），进 HTML 日志，可空
    bool degraded = false;             // true = 配准失败、real 没有做匹配校正（位姿几何结果，可能错位）。导出的 jpg 左上角会写红字标出，并且不管 needSaveDebugInfo 都写这一帧的 DebugInfo
};

// 一帧的输出（日志用）
struct ExportResult
{
    std::string name;                  // 实际使用的文件名（不含扩展名），下传给地面端的名字
    int polygons = 0;                  // 写出的图斑个数
    std::vector<std::pair<int, int>> perKind;   // (类别号, 图斑数)，只含 > 0 的
    int filteredSmall = 0;             // 被面积门限滤掉的个数
    int sent = 0, missing = 0, failed = 0;      // 下传统计（FileSender::Result）
    double msVector = 0, msWrite = 0, msSend = 0;
};

class ChangeExport
{
public:
    explicit ChangeExport(ExportParams params);
    ~ChangeExport();   // 在 .cpp 里定义：FileSender 在此处是不完整类型
    ChangeExport(const ChangeExport&)            = delete;
    ChangeExport& operator=(const ChangeExport&) = delete;

    // 读类别表、建输出目录、（sendToGround 时）绑定下传端口。失败返回 false，err 是原因
    bool Init(std::string& err);

    // 类别表里缺哪些模型类别号（0 .. numClass-1）。导出时缺的类别用 "Kind<号>" 和灰色，并在第一次遇到时报一次
    std::vector<int> MissingKinds() const;
    const std::vector<ChangeKindItem>& Kinds() const { return kinds_; }
    bool SenderReady() const;

    // 导出一帧。文件写不出（jpg / jgw）返回 false，err 是原因；下传失败只记在 out 里，不算失败（地面端没连上很常见）
    bool Export(const ExportFrame& in, ExportResult& out, std::string& err);

private:
    struct Polygon { int kind = 0; std::vector<cv::Point> px; std::vector<cv::Point2d> lonlat; };

    ExportParams params_;
    std::vector<ChangeKindItem> kinds_;
    std::map<int, size_t> kindIndex_;
    std::set<int> warnedKinds_;
    std::map<std::string, int> nameCount_;     // 本次运行用过的文件名及次数
    int frameCount_ = 0;                       // HTML 分页用
    std::unique_ptr<FileSender> ownedSender_;   // 自己创建的下传通道（sharedSender 为空且 sendToGround 时才有）
    FileSender* sender_ = nullptr;              // 实际使用的：ownedSender_.get() 或 params_.sharedSender；空 = 不下传

    const ChangeKindItem* FindKind(int id);    // 缺失时返回 nullptr，并报一次
    std::string KindName(int id);
    cv::Scalar KindColor(int id);
    void Vectorize(const ExportFrame& in, std::vector<Polygon>& polys, ExportResult& out);
    bool WriteJpg(const std::string& file, const cv::Mat& img, std::string& err);
    bool WriteWorldFile(const std::string& stem, const ExportFrame& in, std::string& err);
    bool WriteTxt(const std::string& stem, const std::vector<Polygon>& polys, std::string& err);
    bool WriteGeoJson(const std::string& stem, const std::vector<Polygon>& polys, std::string& err);
    void WriteDebugInfo(const std::string& stem, const ExportFrame& in, const std::vector<Polygon>& polys, const ExportResult& r);
};
