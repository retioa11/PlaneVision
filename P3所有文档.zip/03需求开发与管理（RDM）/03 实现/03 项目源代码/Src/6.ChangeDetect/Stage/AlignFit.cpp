﻿#include "AlignFit.h"

#include <cmath>
#include <cstdarg>
#include <cstdio>

#include <opencv2/calib3d.hpp>
#include <opencv2/imgproc.hpp>

namespace {

std::string Fmt(const char* f, ...)
{
    char buf[256];
    va_list ap;
    va_start(ap, f);
    std::vsnprintf(buf, sizeof(buf), f, ap);
    va_end(ap);
    return buf;
}

// 退化保护（始终检查，与 check 开关无关）：行列式必须在这个范围内。几何阶段已经缩放到 T1 像素大小，正常值接近 1
constexpr double kMinDet = 0.2, kMaxDet = 5.0;

// 单应在 p 处的局部缩放 = 雅可比行列式的平方根。分母 <= 0 返回 NaN
double LocalScale(const cv::Mat& H, cv::Point2d p)
{
    const double h00 = H.at<double>(0, 0), h01 = H.at<double>(0, 1), h02 = H.at<double>(0, 2);
    const double h10 = H.at<double>(1, 0), h11 = H.at<double>(1, 1), h12 = H.at<double>(1, 2);
    const double h20 = H.at<double>(2, 0), h21 = H.at<double>(2, 1), h22 = H.at<double>(2, 2);
    const double w = h20 * p.x + h21 * p.y + h22;
    if (!(w > 1e-9)) return std::nan("");
    const double qx = (h00 * p.x + h01 * p.y + h02) / w, qy = (h10 * p.x + h11 * p.y + h12) / w;
    const double j00 = (h00 - qx * h20) / w, j01 = (h01 - qx * h21) / w;
    const double j10 = (h10 - qy * h20) / w, j11 = (h11 - qy * h21) / w;
    return std::sqrt(std::fabs(j00 * j11 - j01 * j10));
}

cv::Point2d ApplyH(const cv::Mat& H, cv::Point2d p)
{
    const double w = H.at<double>(2, 0) * p.x + H.at<double>(2, 1) * p.y + H.at<double>(2, 2);
    return {(H.at<double>(0, 0) * p.x + H.at<double>(0, 1) * p.y + H.at<double>(0, 2)) / w,
            (H.at<double>(1, 0) * p.x + H.at<double>(1, 1) * p.y + H.at<double>(1, 2)) / w};
}

}  // namespace

bool FitHomography(const std::vector<cv::Point2f>& p0, const std::vector<cv::Point2f>& p1, int windowSize,
                   const AlignFitParams& prm, AlignFit& out, std::string& why)
{
    out = AlignFit();
    out.matches = static_cast<int>(p0.size());
    if (p0.size() != p1.size()) { why = "匹配点对数量不一致"; return false; }
    if (out.matches < 4 || out.matches < prm.minInliers) {
        why = Fmt("匹配点太少：%d（至少需要 %d）", out.matches, std::max(4, prm.minInliers));
        return false;
    }

    const cv::Point2d center(windowSize / 2.0, windowSize / 2.0);

    // 单应矩阵（主模型）
    cv::Mat mask;
    cv::Mat H = cv::findHomography(p0, p1, cv::RANSAC, prm.ransacThreshPx, mask, 2000, 0.995);

    // 相似变换（只做对照，不参与判断）
    {
        cv::Mat m2;
        const cv::Mat A = cv::estimateAffinePartial2D(p0, p1, m2, cv::RANSAC, prm.ransacThreshPx, 2000, 0.99, 10);
        if (!A.empty() && !m2.empty()) {
            double se = 0;
            for (int i = 0; i < out.matches; ++i) {
                if (!m2.at<uchar>(i)) continue;
                ++out.simInliers;
                const double x = A.at<double>(0, 0) * p0[i].x + A.at<double>(0, 1) * p0[i].y + A.at<double>(0, 2);
                const double y = A.at<double>(1, 0) * p0[i].x + A.at<double>(1, 1) * p0[i].y + A.at<double>(1, 2);
                se += (x - p1[i].x) * (x - p1[i].x) + (y - p1[i].y) * (y - p1[i].y);
            }
            if (out.simInliers > 0) out.simRmsePx = std::sqrt(se / out.simInliers);
            out.simScale = std::hypot(A.at<double>(0, 0), A.at<double>(1, 0));
            out.simRotDeg = std::atan2(A.at<double>(1, 0), A.at<double>(0, 0)) * 180.0 / CV_PI;
            const double cx = A.at<double>(0, 0) * center.x + A.at<double>(0, 1) * center.y + A.at<double>(0, 2);
            const double cy = A.at<double>(1, 0) * center.x + A.at<double>(1, 1) * center.y + A.at<double>(1, 2);
            out.simCenterShiftPx = std::hypot(cx - center.x, cy - center.y);
        }
    }

    if (H.empty() || mask.empty() || H.rows != 3 || H.cols != 3) { why = "RANSAC 没有求出单应矩阵"; return false; }
    H.convertTo(H, CV_64F);
    out.inlierMask.assign(mask.begin<uchar>(), mask.end<uchar>());
    out.inliers = cv::countNonZero(mask);

    const double h22 = H.at<double>(2, 2);
    if (!std::isfinite(h22) || std::fabs(h22) < 1e-12) { why = "单应矩阵无效（H22 为 0 或非有限值）"; return false; }
    H /= h22;
    for (int r = 0; r < 3; ++r)
        for (int c = 0; c < 3; ++c)
            if (!std::isfinite(H.at<double>(r, c))) { why = "单应矩阵含非有限值"; return false; }

    // 内点重投影误差
    double se = 0;
    for (int i = 0; i < out.matches; ++i) {
        if (!out.inlierMask[i]) continue;
        const cv::Point2d q = ApplyH(H, p0[i]);
        se += (q.x - p1[i].x) * (q.x - p1[i].x) + (q.y - p1[i].y) * (q.y - p1[i].y);
    }
    if (out.inliers > 0) out.rmsePx = std::sqrt(se / out.inliers);
    const cv::Point2d cq = ApplyH(H, center);
    out.centerShiftPx = std::hypot(cq.x - center.x, cq.y - center.y);
    out.H = H;

    // 透视梯度：中心和四边中点的局部缩放；四角的分母
    const double S = windowSize;
    bool denomOk = true;
    for (const cv::Point2d c : {cv::Point2d(0, 0), cv::Point2d(S, 0), cv::Point2d(0, S), cv::Point2d(S, S)})
        if (!(H.at<double>(2, 0) * c.x + H.at<double>(2, 1) * c.y + H.at<double>(2, 2) > 0.3)) denomOk = false;
    double sLo = 1e9, sHi = 0;
    for (const cv::Point2d c : {center, cv::Point2d(S / 2, 0), cv::Point2d(S / 2, S), cv::Point2d(0, S / 2), cv::Point2d(S, S / 2)}) {
        const double sc = LocalScale(H, c);
        if (!std::isfinite(sc)) { denomOk = false; continue; }
        sLo = std::min(sLo, sc);
        sHi = std::max(sHi, sc);
    }
    if (sHi > 0) { out.edgeScaleMin = sLo; out.edgeScaleMax = sHi; }

    if (out.inliers < prm.minInliers) {
        why = Fmt("内点太少：%d / %d（至少需要 %d）", out.inliers, out.matches, prm.minInliers);
        return false;
    }

    const double det = H.at<double>(0, 0) * H.at<double>(1, 1) - H.at<double>(0, 1) * H.at<double>(1, 0);
    if (!(det > kMinDet && det < kMaxDet)) {
        why = Fmt("单应矩阵退化：左上 2x2 行列式 %.3f 不在 %.1f~%.1f 内", det, kMinDet, kMaxDet);
        return false;
    }

    if (!denomOk) { why = "单应的透视分母过小（窗口四角有点被映射到无穷远附近）"; return false; }
    if (!(out.edgeScaleMin >= prm.edgeScaleMin && out.edgeScaleMax <= prm.edgeScaleMax)) {
        why = Fmt("透视过强：窗口中心和四边的局部缩放 %.2f~%.2f 超出 %.2f~%.2f", out.edgeScaleMin, out.edgeScaleMax, prm.edgeScaleMin, prm.edgeScaleMax);
        return false;
    }

    if (prm.check) {
        const double h00 = H.at<double>(0, 0), h11 = H.at<double>(1, 1), h01 = H.at<double>(0, 1), h10 = H.at<double>(1, 0);
        const double h02 = H.at<double>(0, 2), h12 = H.at<double>(1, 2);
        if (std::fabs(h00 - 1) > prm.zoomThreshold || std::fabs(h11 - 1) > prm.zoomThreshold) {
            why = Fmt("缩放超限：h00=%.3f h11=%.3f（偏离 1 超过 %.2f）", h00, h11, prm.zoomThreshold);
            return false;
        }
        if (std::fabs(h02) > prm.shiftThreshold || std::fabs(h12) > prm.shiftThreshold) {
            why = Fmt("平移超限：h02=%.1f h12=%.1f（超过 %.0f 像素）", h02, h12, prm.shiftThreshold);
            return false;
        }
        if (std::fabs(h01) > prm.skewThreshold || std::fabs(h10) > prm.skewThreshold) {
            why = Fmt("偏斜超限：h01=%.3f h10=%.3f（超过 %.2f）", h01, h10, prm.skewThreshold);
            return false;
        }
    }
    return true;
}

cv::Rect CenterRect(cv::Size full, int w, int h)
{
    return cv::Rect((full.width - w) / 2, (full.height - h) / 2, w, h);
}

double WarpSourceToRef(const cv::Mat& src, const cv::Mat& srcToRef, cv::Size outSize, const cv::Rect& crop, cv::Mat& warped)
{
    cv::warpPerspective(src, warped, srcToRef, outSize, cv::INTER_LINEAR, cv::BORDER_CONSTANT, cv::Scalar(128, 128, 128));
    cv::Mat ones(src.size(), CV_8UC1, cv::Scalar(255)), valid;
    cv::warpPerspective(ones, valid, srcToRef, outSize, cv::INTER_NEAREST, cv::BORDER_CONSTANT, cv::Scalar(0));
    const cv::Rect r = crop & cv::Rect(0, 0, outSize.width, outSize.height);
    if (r.area() <= 0) return 0;
    return static_cast<double>(cv::countNonZero(valid(r))) / crop.area();
}
