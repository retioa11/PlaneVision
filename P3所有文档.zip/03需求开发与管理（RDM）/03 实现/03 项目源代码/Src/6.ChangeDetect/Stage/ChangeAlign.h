﻿// ChangeAlign.h —— 阶段 1：配准。把一帧实时图和 T1 基准图对齐，输出一对同尺寸的图。
//
// 分两段：
//   Geometry（第 4 步，已实现）：GSD → 缩放到 T1 像素大小 → 按格网航向转正（WarpCenteredRotate）
//       → 以飞机位置减姿态偏移（CalcGroundToAir）为中心，在 T1 像素格网上取 matchWindow 见方的窗口（CropT1）
//       输出 matchWindow 见方的 real / ref，两者同尺寸、同像素大小、正北（格网北）向上，只差匹配校正。
//   Run（第 5 步，已实现）：Geometry → SplgOrt 匹配（阈值固定 0.1，在 SplgOrt 里）→ findHomography（RANSAC，内点数下限；
//       NeedCheckHomography 打开时再查缩放 / 平移 / 偏斜）→ warpPerspective 校正 → 裁中心 CD 输入大小。
//       校正不是对 real 再 warp 一次，而是把单应乘在 srcToWindow 后面、从原图一次变换到窗口（少一次插值，窗口边缘不露灰条）。
//       拟合与校正的数学在 AlignFit.h（纯 OpenCV，可单独测试）。
// 任何一步失败，这一帧跳过并说明原因，不抛异常给流水线（出错才抛）。
// 不依赖 ChangeDetectConfig：参数由流水线从配置里填进 AlignParams。
// 线程：只能由一个线程调用（T1 的 TileDBContext 带缓存，不是线程安全的）。
#pragma once

#include <memory>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

#include "AlignFit.h"
#include "CaptureTypes.h"   // PoseFrame

struct TileDBContext;   // 6.GIS/TileDB.h
class SplgOrt;          // 3.Vision/ImageMatcher.h（头文件带 onnxruntime，这里不包含）

struct AlignParams
{
    std::string t1LmdbPath;            // T1 库（tiles.lmdb）
    std::string splgModelPath;         // SuperPoint+LightGlue 匹配模型
    bool   loadMatcher = true;         // false = Init 不加载匹配配准模型（DebugStage=align 只做几何，省掉 Jetson 上编译 TensorRT engine 的等待）
    double fy = 0;                     // 垂直像素焦距，GSD = 离地高度 / fy
    int    imgHeightPx = 1080;         // fy 按这个图高标定；图高不同时按比例换算
    int    zoneDeg = 3;                // 高斯带宽；中央子午线取自 T1 的带号（zone * zoneDeg）
    int    matchWindow = 672;          // 匹配窗口边长（实时图 / 基准图）
    int    cdInputW = 640, cdInputH = 640;   // 输出图尺寸（变化检测输入），从匹配窗口中心裁出（第 5 步用）
    double minRefCover = 0.95;         // 基准图被 T1 覆盖的比例下限，低于它跳过这一帧
    int    minInliers = 15;            // 单应矩阵内点数下限
    double ransacThreshPx = 3.0;       // 单应 RANSAC 的重投影误差阈值（像素），暂不进 json
    bool   needCheckHomography = false;
    double zoomThreshold = 0.3, shiftThreshold = 150, skewThreshold = 0.25;
};

// Geometry 的输出
struct AlignGeometry
{
    cv::Mat srcToWindow;               // 3x3 CV_64F：原图像素 → real 窗口像素（缩放 + 转正，与 WarpCenteredRotate 同一个矩阵）。Run 把单应乘在它后面，一次变换
    cv::Mat real, ref;                 // 各 matchWindow 见方，BGR。real：缩放转正后的实时图，图外补灰 128；ref：T1 基准图，T1 外为黑
    double refOriginE = 0, refOriginN = 0;   // ref 左上角的高斯坐标（米，E 含带号）。与 T1 像素格网对齐，所以 ref 是 T1 像素的原样拷贝
    double pixelSize = 0;              // ref / real 的像素大小（米）= T1 像素大小
    double gsd = 0;                    // 实时图原始 GSD（米/像素）= 相对高度 / fy
    double scale = 0;                  // 实时图缩放倍数 = gsd / pixelSize
    double convergenceDeg = 0;         // 子午线收敛角
    double gridYawDeg = 0;             // 转正用的格网航向 = 真航向 - 收敛角
    double droneE = 0, droneN = 0;     // 飞机位置的高斯坐标
    double offsetE = 0, offsetN = 0;   // CalcGroundToAir 姿态偏移（米）；窗口中心 = 飞机位置 - 偏移
    double centerE = 0, centerN = 0;   // 窗口中心的高斯坐标（取格网前）
    double refCover = 0;               // ref 被 T1 覆盖的比例 0~1
    double realCover = 0;              // real 里来自实时图（非补灰）的比例 0~1，只供观察，不参与判断
};

// Run 的输出。失败时已经算出的部分仍然保留（geo / 匹配点 / fit），供日志和调试图使用；ref / real 只在成功时有值
struct AlignResult
{
    // 成功时的产物
    cv::Mat ref, real;                 // 各 cdInputH × cdInputW，BGR；ref = T1 基准图（窗口中心裁出），real = 校正后的实时图
    double refOriginE = 0, refOriginN = 0;   // ref 左上角的高斯坐标（米，E 含带号），导出阶段用它把像素转成经纬度
    double pixelSize = 0;              // ref / real 的像素大小（米）= T1 像素大小
    double scale = 0;                  // 实时图缩放倍数（GSD / T1 像素大小）
    int    matchCount = 0, inliers = 0;

    // 中间量（调试 / 日志）
    AlignGeometry geo;                 // 几何阶段输出（matchWindow 见方）；Geometry 失败时 geo.real 为空
    bool geometryOk = false;           // Geometry 成功（geo.real / geo.ref 都可用）。匹配 / 拟合失败时它仍为 true，供流水线降级使用
    bool degraded = false;             // true = 没有做匹配校正，ref / real 直接来自位姿几何结果（FallbackFromGeometry 设置）
    std::vector<cv::Point2f> p0, p1;   // 匹配点：p0 在 geo.real 像素系，p1 在 geo.ref 像素系
    AlignFit fit;                      // 单应拟合结果（含 H、内点掩码、与相似变换的对照）
    cv::Mat warped;                    // 原图经 H * srcToWindow 一次变换到窗口（matchWindow 见方），与 geo.ref 对齐；窗口外的原图像素也参与
    cv::Rect crop;                     // 从 matchWindow 里裁出 cdInputW × cdInputH 的框
    double cropValid = 0;              // 校正后 crop 区域里来自实时图的像素比例（0~1），只供观察
    double msGeometry = 0, msMatch = 0, msFit = 0, msWarp = 0;   // 各步耗时（毫秒）
};

class ChangeAlign
{
public:
    explicit ChangeAlign(AlignParams params);
    ~ChangeAlign();   // 在 .cpp 里定义：TileDBContext 在此处是不完整类型
    ChangeAlign(const ChangeAlign&)            = delete;   // 持有 T1 句柄，禁止拷贝
    ChangeAlign& operator=(const ChangeAlign&) = delete;

    // 打开 T1，并（loadMatcher 时）加载匹配配准模型。失败返回 false，err 是原因。
    // Jetson 上首次加载会编译 TensorRT engine（一两分钟），之后读缓存
    bool Init(std::string& err);

    // 几何对齐一帧（缩放转正 + 取基准图窗口）。成功返回 true；跳过返回 false，skipReason 写明原因（如位姿无效、T1 覆盖不足）
    bool Geometry(const PoseFrame& frame, AlignGeometry& out, std::string& skipReason);

    // 对齐一帧：Geometry → 匹配 → 单应拟合 → 校正 → 裁中心。成功返回 true；跳过返回 false，skipReason 写明原因。
    // 匹配模型推理出错（onnxruntime 异常）直接抛出，由流水线记为"失败"。
    bool Run(const PoseFrame& frame, AlignResult& out, std::string& skipReason);

    // 降级：Run 在匹配 / 拟合阶段失败（out.geometryOk 为 true）后调用，用位姿几何结果充当配准结果——
    // 不做单应校正（等价于 H = 单位阵），从 geo.real / geo.ref 的中心裁 cdInput 大小，填好 out.ref / real / 原点 / 像素大小。
    // 精度只有位姿精度（姿态 / 航向 / 位置误差都会直接变成错位），只用于流程验证或配准反复失败时的兜底。几何没成功时返回 false。
    bool FallbackFromGeometry(AlignResult& out) const;

private:
    AlignParams params_;
    std::unique_ptr<TileDBContext> db_;   // Init 成功后非空，析构时关闭
    std::unique_ptr<SplgOrt> matcher_;    // loadMatcher 且 Init 成功后非空
};
