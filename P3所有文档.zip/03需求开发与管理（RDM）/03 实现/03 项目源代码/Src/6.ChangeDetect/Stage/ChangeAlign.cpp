﻿#include "ChangeAlign.h"

#include <cmath>
#include <cstdarg>
#include <chrono>
#include <cstdio>
#include <exception>
#include <vector>

#include <opencv2/imgproc.hpp>

#include "1.Common/EngineFunction.h"   // GroundResolution
#include "3.Vision/ImageMatcher.h"      // SplgOrt
#include "3.Vision/OpenCVHelper.h"     // WarpCenteredRotate
#include "6.GIS/GISHelper.h"           // LonLatToGauss / MeridianConvergence / CalcGroundToAir
#include "6.GIS/T1Reference.h"         // CropT1
#include "6.GIS/TileDB.h"              // TileDB_Open / TileDB_Close

namespace {

std::string Fmt(const char* f, ...)
{
    char buf[256];
    va_list ap;
    va_start(ap, f);
    std::vsnprintf(buf, sizeof(buf), f, ap);
    va_end(ap);
    return buf;
}

double MsSince(std::chrono::steady_clock::time_point t0)
{
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
}

constexpr double kMinScale = 0.05, kMaxScale = 20.0;   // 缩放倍数的合理范围，超出说明焦距或高度明显不对

}  // namespace

ChangeAlign::ChangeAlign(AlignParams params) : params_(std::move(params)) {}

ChangeAlign::~ChangeAlign()
{
    if (db_) TileDB_Close(*db_);
}

bool ChangeAlign::Init(std::string& err)
{
    if (db_) return true;
    if (!(params_.fy > 0) || params_.imgHeightPx <= 0 || params_.matchWindow <= 0) { err = "AlignParams 的 fy / imgHeightPx / matchWindow 必须 > 0"; return false; }
    auto db = std::make_unique<TileDBContext>();
    std::string e;
    if (!TileDB_Open(params_.t1LmdbPath, *db, &e)) { err = "打开 T1 失败: " + e; return false; }
    if (db->gauss_zone <= 0 || !(db->pixel_size_x > 0) || !(db->pixel_size_y < 0) || db->tile_size <= 0) {
        TileDB_Close(*db);
        err = Fmt("T1 元数据无效：带号 %d、像素大小 %.6f / %.6f、瓦片 %d", db->gauss_zone, db->pixel_size_x, db->pixel_size_y, db->tile_size);
        return false;
    }
    db_ = std::move(db);

    if (params_.loadMatcher) {
        if (params_.splgModelPath.empty()) { err = "匹配模型路径为空"; return false; }
        try {
            auto m = std::make_unique<SplgOrt>();
            m->Init(params_.splgModelPath, params_.matchWindow);   // 模型固定输入 = 匹配窗口，Extract 不再缩放，匹配点坐标直接是窗口像素
            matcher_ = std::move(m);
        } catch (const std::exception& e) {
            err = std::string("加载匹配配准模型失败: ") + e.what();
            return false;
        }
    }
    return true;
}

// 做法：
//   1. 位置转高斯坐标，中央子午线取自 T1 的带号（与 T1 同一套坐标）
//   2. real：WarpCenteredRotate(整幅图, 格网航向, 缩放 = GSD / T1 像素大小, matchWindow 见方)，一次插值；
//      原图中心落在窗口中心，原图外补灰 128
//   3. ref：窗口中心 = 飞机高斯坐标 - CalcGroundToAir 偏移；取到 T1 像素格网上（窗口左上角 = 中心所在像素 - 窗口边长/2），
//      这样 CropT1 的重采样系数为 1、平移为整数，ref 就是 T1 像素的原样拷贝。
bool ChangeAlign::Geometry(const PoseFrame& f, AlignGeometry& g, std::string& why)
{
    g = AlignGeometry();
    if (!db_) { why = "T1 未打开（Init 没有调用或失败）"; return false; }
    const cv::Mat& img = f.ImageMat;
    if (img.empty() || img.type() != CV_8UC3) { why = "图像为空或不是 8 位 3 通道"; return false; }
    if (!std::isfinite(f.Longitude) || !std::isfinite(f.Latitude) || !std::isfinite(f.RelativeHeight) ||
        !std::isfinite(f.Yaw) || !std::isfinite(f.Pitch) || !std::isfinite(f.Roll) || !(f.RelativeHeight > 0)) {
        why = "位姿无效（经纬度 / 姿态不是有限值，或相对高度 <= 0）";
        return false;
    }

    const int    W  = params_.matchWindow;
    const double px = db_->pixel_size_x, py = db_->pixel_size_y;   // py < 0
    const double cm = db_->gauss_zone * static_cast<double>(params_.zoneDeg);

    // 焦距按图高换算：图高与标定高度一致时 fyEff = fy
    const double fyEff = params_.fy * img.rows / params_.imgHeightPx;
    g.gsd   = GroundResolution(f.RelativeHeight, fyEff);
    g.scale = g.gsd / px;
    if (!(g.scale > kMinScale && g.scale < kMaxScale)) {
        why = Fmt("缩放倍数 ×%.3f 超出 %.2f~%.0f（相对高度 %.1f 米、焦距 %.1f，与 T1 像素大小 %.4f 米不搭）", g.scale, kMinScale, kMaxScale, f.RelativeHeight, fyEff, px);
        return false;
    }

    // 坐标、航向、姿态偏移
    LonLatToGauss(f.Longitude, f.Latitude, cm, params_.zoneDeg, g.droneE, g.droneN);
    g.convergenceDeg = MeridianConvergence(f.Longitude, f.Latitude, cm);
    g.gridYawDeg     = f.Yaw - g.convergenceDeg;
    const cv::Point2d off = CalcGroundToAir(f.RelativeHeight, cv::Point3d(f.Roll, f.Pitch, f.Yaw));   // 依次：横滚 俯仰 偏航
    g.offsetE = off.x;
    g.offsetN = off.y;
    g.centerE = g.droneE - g.offsetE;
    g.centerN = g.droneN - g.offsetN;

    // 原图 → 窗口的矩阵：与 WarpCenteredRotate（OpenCVHelper.cpp）同一个公式。Run 要把单应乘在它后面，所以这里单独留一份；
    // 两处必须一致（单元测试里有比对）
    {
        const cv::Point2f srcC((img.cols - 1) * 0.5f, (img.rows - 1) * 0.5f);
        cv::Mat M = cv::getRotationMatrix2D(srcC, -g.gridYawDeg, g.scale);
        M.at<double>(0, 2) += (W - 1) * 0.5 - srcC.x;
        M.at<double>(1, 2) += (W - 1) * 0.5 - srcC.y;
        g.srcToWindow = cv::Mat::eye(3, 3, CV_64F);
        M.copyTo(g.srcToWindow(cv::Rect(0, 0, 3, 2)));
    }

    // 实时图：缩放 + 转正，一次 warpAffine。多出的 alpha 通道只用来统计图内像素比例
    const cv::Mat bgra = WarpCenteredRotate(img, g.gridYawDeg, g.scale, cv::Size(W, W), cv::Scalar(128, 128, 128), true);
    if (bgra.empty()) { why = "WarpCenteredRotate 失败"; return false; }
    std::vector<cv::Mat> ch;
    cv::split(bgra, ch);
    g.realCover = static_cast<double>(cv::countNonZero(ch[3] >= 128)) / (static_cast<double>(W) * W);
    ch.pop_back();
    cv::merge(ch, g.real);

    // 基准图：窗口左上角取在 T1 像素格网上
    const double colD = std::floor((g.centerE - db_->geo_origin_x) / px);
    const double rowD = std::floor((g.centerN - db_->geo_origin_y) / py);
    if (!(std::fabs(colD) < 1e7) || !(std::fabs(rowD) < 1e7)) { why = "窗口中心离 T1 原点太远"; return false; }
    g.refOriginE = db_->geo_origin_x + (colD - W / 2) * px;
    g.refOriginN = db_->geo_origin_y + (rowD - W / 2) * py;
    g.pixelSize  = px;

    std::string cropWhy;
    if (!CropT1(*db_, g.refOriginE, g.refOriginN, px, cv::Size(W, W), params_.zoneDeg, g.ref, g.refCover, cropWhy)) {
        why = "基准图失败: " + cropWhy;
        return false;
    }
    if (g.refCover < params_.minRefCover) {
        why = Fmt("基准图 T1 覆盖率 %.1f%% < %.0f%%（飞出 T1 范围，或姿态偏移 %.0f 米太大）", g.refCover * 100, params_.minRefCover * 100, std::hypot(g.offsetE, g.offsetN));
        return false;
    }
    return true;
}

// 第 5 步：Geometry → 匹配 → 单应拟合 → 校正 → 裁中心
//   匹配：Extract(real, ref)，p0 在 real、p1 在 ref，二者同尺寸（matchWindow）、同像素大小，所以点坐标不用换算
//   H：real → ref。校正用 H * srcToWindow 从原图一次变换到窗口，与 ref 逐像素对齐，再从中心裁 cdInput 大小。
//   ref 的裁剪只是整数平移，所以裁出的 ref 左上角高斯坐标 = refOrigin + (x0, y0) 像素 * 像素大小（行号增大 → 北坐标减小）
bool ChangeAlign::Run(const PoseFrame& frame, AlignResult& out, std::string& why)
{
    out = AlignResult();
    if (!matcher_) { why = "本次运行没有加载匹配配准模型（Init 没有调用、失败，或 loadMatcher = false）"; return false; }

    auto t = std::chrono::steady_clock::now();
    if (!Geometry(frame, out.geo, why)) { out.msGeometry = MsSince(t); return false; }
    out.msGeometry = MsSince(t);
    out.geometryOk = true;
    const AlignGeometry& g = out.geo;
    const int W = params_.matchWindow;

    // 匹配（阈值固定在 SplgOrt 里，0.1）
    t = std::chrono::steady_clock::now();
    const SplgOrtFeatures feats = matcher_->Extract(g.real, g.ref);
    auto pr = matcher_->Match(feats);
    out.p0 = std::move(pr.first);
    out.p1 = std::move(pr.second);
    out.msMatch = MsSince(t);
    out.matchCount = static_cast<int>(out.p0.size());

    // 单应拟合与检查
    t = std::chrono::steady_clock::now();
    AlignFitParams fp;
    fp.ransacThreshPx = params_.ransacThreshPx;
    fp.minInliers = params_.minInliers;
    fp.check = params_.needCheckHomography;
    fp.zoomThreshold = params_.zoomThreshold;
    fp.shiftThreshold = params_.shiftThreshold;
    fp.skewThreshold = params_.skewThreshold;
    const bool fitOk = FitHomography(out.p0, out.p1, W, fp, out.fit, why);
    out.msFit = MsSince(t);
    out.inliers = out.fit.inliers;
    if (!fitOk) return false;

    // 校正 + 裁中心：原图 →（缩放转正）→ 窗口 →（单应）→ 对齐到 ref 的窗口，合成一个矩阵一次变换
    t = std::chrono::steady_clock::now();
    out.crop = CenterRect(cv::Size(W, W), params_.cdInputW, params_.cdInputH);
    const cv::Mat total = out.fit.H * g.srcToWindow;
    out.cropValid = WarpSourceToRef(frame.ImageMat, total, cv::Size(W, W), out.crop, out.warped);
    out.real = out.warped(out.crop).clone();
    out.ref = g.ref(out.crop).clone();
    out.pixelSize = g.pixelSize;
    out.refOriginE = g.refOriginE + out.crop.x * g.pixelSize;
    out.refOriginN = g.refOriginN - out.crop.y * g.pixelSize;
    out.scale = g.scale;
    out.msWarp = MsSince(t);
    return true;
}

// 降级：不做匹配校正，直接用位姿几何的 real / ref 中心裁剪（见头文件说明）
bool ChangeAlign::FallbackFromGeometry(AlignResult& out) const
{
    const AlignGeometry& g = out.geo;
    if (!out.geometryOk || g.real.empty() || g.ref.empty() || g.real.size() != g.ref.size()) return false;
    const int W = g.real.cols;
    if (W < params_.cdInputW || g.real.rows < params_.cdInputH) return false;
    out.crop = CenterRect(cv::Size(W, g.real.rows), params_.cdInputW, params_.cdInputH);
    out.real = g.real(out.crop).clone();
    out.ref = g.ref(out.crop).clone();
    out.pixelSize = g.pixelSize;
    out.refOriginE = g.refOriginE + out.crop.x * g.pixelSize;
    out.refOriginN = g.refOriginN - out.crop.y * g.pixelSize;
    out.scale = g.scale;
    out.cropValid = 0;     // 降级时不统计（real 里的灰边靠 geo.realCover 看）
    out.degraded = true;
    return true;
}
