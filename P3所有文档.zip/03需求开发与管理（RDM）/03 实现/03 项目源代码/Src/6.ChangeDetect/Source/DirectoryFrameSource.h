﻿// DirectoryFrameSource.h —— 磁盘图片数据源（Disk 回放模式）
//
// 轮询一个目录，按文件名排序，每次交出一张"还没处理过的新图"（PoseFrame）。行为对齐旧程序 ExecuteDebuggingCD：
//   - 目录里新增一张就处理一张；已有的图也按文件名顺序逐张处理；
//   - 限速：从上一帧处理完起算，不足 invokeIntervalMs 就补睡（目录一直没新图时不会额外再睡）；
//   - 目录里没有新图时等待，每 idleLogMs 打印一次提示；收到停止信号立即返回。
// 与旧程序不同（都是旧程序的隐患）：
//   - 只扫描新增的文件名，不再每轮对全部文件排序；
//   - 先确认文件大小和修改时间稳定一小段时间、且 jpg 有结束标记（FFD9）再读，防止读到写了一半的图（libjpeg 对截断文件只警告，imread 仍会返回半张图）；
//     没有结束标记的按"还没写完"继续等，直到 stableTimeoutMs 超时放弃；解码失败最多重试 maxReadRetries 次，之后放弃这一张；
//   - 文件名解析不出经纬度 / 缺 RelAlt / 缺 Yaw / 高度超范围的帧：打日志后跳过（不占限速间隔）；
//   - 目录不存在不会崩溃，按"没有新图"处理。
//
// 流水线只依赖 PoseFrame。以后换成视频抽帧或相机数据源，只需要另写一个提供 Next() 的类。
// 线程：Next() 只能由一个线程调用。
#pragma once

#include <chrono>
#include <functional>
#include <map>
#include <set>
#include <string>

#include "CaptureTypes.h"   // PoseFrame

struct DirectorySourceOptions
{
    std::string imageDir;               // 图片目录（本地编码）
    int    invokeIntervalMs = 5000;     // 两帧之间的最小处理间隔，0 = 不限速
    double minWorkHeight = 0;           // 相对高度范围（米）；仅当 max > min 时启用，范围外的帧跳过
    double maxWorkHeight = 0;
    int    pollMs = 200;                // 轮询周期
    int    stableMs = 500;              // 文件大小 / 修改时间连续这么久没变，才认为写完了
    int    stableTimeoutMs = 30000;     // 一直不稳定超过这么久，放弃这一张
    int    maxReadRetries = 3;          // 解码失败的重试次数（用满后放弃这一张）
    int    idleLogMs = 10000;           // 目录没有新图时，提示信息的打印周期

    std::function<bool()> shouldStop;                 // 返回 true = 停止（Next 随即返回 false）；可为空
    std::function<void(const std::string&)> log;      // 日志输出；为空则走 OutputLog（控制台 + 地面端）
};

struct DirectorySourceCounters
{
    int delivered = 0;       // 已交出的帧
    int skippedBadName = 0;  // 文件名解析不出经纬度
    int skippedNoPose = 0;   // 缺 RelAlt 或 Yaw
    int skippedHeight = 0;   // 高度超范围
    int skippedUnreadable = 0;   // 一直不稳定 / 解码失败 / 文件消失
};

class DirectoryFrameSource
{
public:
    explicit DirectoryFrameSource(DirectorySourceOptions opt);

    // 阻塞到取得下一张可处理的帧，返回 true；收到停止信号返回 false。
    // frame.ImageMat 是 BGR（cv::imread 的结果，未做任何颜色转换）；frame.TimeStamp 取自文件名前缀 hhmmss（补 000），没有前缀时用当前时间；
    // id 是不含扩展名的文件名，输出文件按它命名。
    // 约定：调用方处理完上一帧后才再次调用 Next，限速间隔就从这次调用开始算。
    bool Next(PoseFrame& frame, std::string& id);

    const DirectorySourceCounters& Counters() const { return counters_; }

private:
    struct Pending
    {
        bool   inited = false;
        long long size = -1;
        long long mtime = 0;
        std::chrono::steady_clock::time_point firstSeen;
        std::chrono::steady_clock::time_point changedAt;
        int    retries = 0;
        bool   warnedIncomplete = false;   // 已提示过"jpg 还没写完"，避免刷屏
    };

    void Log(const std::string& s) const;
    bool Stopped() const { return opt_.shouldStop && opt_.shouldStop(); }
    bool SleepMs(int ms) const;                // 切成小段睡，期间收到停止信号返回 false
    void ScanNewFiles();                       // 只登记新出现的文件名
    void Drop(const std::string& name, int DirectorySourceCounters::* counter);

    DirectorySourceOptions opt_;
    DirectorySourceCounters counters_;
    std::set<std::string> seen_;               // 见过的全部文件名（含已处理 / 已放弃的）
    std::map<std::string, Pending> pending_;   // 待处理，按文件名排序；每次只看最前面那张，保证顺序
    bool dirErrLogged_ = false;
};