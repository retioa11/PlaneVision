﻿#include "DirectoryFrameSource.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <thread>

#include <opencv2/imgcodecs.hpp>

#include "1.Common/EngineFunction.h"   // ParseFramePos / FramePos

namespace fs = std::filesystem;
using Clock = std::chrono::steady_clock;

namespace {

bool IsJpg(const fs::path& p)
{
    std::string e = p.extension().string();
    std::transform(e.begin(), e.end(), e.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return e == ".jpg" || e == ".jpeg";
}

// jpg 是否完整：以 FFD8 开头、以 FFD9 结尾（允许末尾有 0 填充）。截断的文件没有结束标记
bool JpegComplete(const fs::path& p)
{
    std::ifstream f(p, std::ios::binary | std::ios::ate);
    if (!f) return false;
    const std::streamoff n = f.tellg();
    if (n < 4) return false;
    unsigned char head[2] = {0, 0};
    f.seekg(0);
    f.read(reinterpret_cast<char*>(head), 2);
    if (head[0] != 0xFF || head[1] != 0xD8) return false;
    const std::streamoff take = std::min<std::streamoff>(n, 64);
    std::string tail(static_cast<size_t>(take), '\0');
    f.seekg(n - take);
    f.read(&tail[0], take);
    size_t end = tail.size();
    while (end > 0 && tail[end - 1] == '\0') --end;
    return end >= 2 && static_cast<unsigned char>(tail[end - 2]) == 0xFF && static_cast<unsigned char>(tail[end - 1]) == 0xD9;
}

std::string Fmt(const char* f, ...)
{
    char buf[512];
    va_list ap;
    va_start(ap, f);
    std::vsnprintf(buf, sizeof(buf), f, ap);
    va_end(ap);
    return buf;
}

}  // namespace

DirectoryFrameSource::DirectoryFrameSource(DirectorySourceOptions opt) : opt_(std::move(opt))
{
    opt_.pollMs = std::max(opt_.pollMs, 10);
    opt_.stableMs = std::max(opt_.stableMs, 0);
    opt_.maxReadRetries = std::max(opt_.maxReadRetries, 1);
}

void DirectoryFrameSource::Log(const std::string& s) const
{
    if (opt_.log) opt_.log(s);
    else OutputLog(s);   // 控制台回显 + 发地面端（OutputLog 自动补换行）
}

bool DirectoryFrameSource::SleepMs(int ms) const
{
    const auto until = Clock::now() + std::chrono::milliseconds(std::max(ms, 0));
    while (true) {
        if (Stopped()) return false;
        const auto left = until - Clock::now();
        if (left <= Clock::duration::zero()) return true;
        std::this_thread::sleep_for(std::min<Clock::duration>(left, std::chrono::milliseconds(100)));
    }
}

void DirectoryFrameSource::ScanNewFiles()
{
    std::error_code ec;
    fs::directory_iterator it(opt_.imageDir, ec), end;
    if (ec) {
        if (!dirErrLogged_) { Log("[数据源] 无法打开图片目录 " + opt_.imageDir + "：" + ec.message() + "，按没有新图处理，继续等待"); dirErrLogged_ = true; }
        return;
    }
    dirErrLogged_ = false;
    for (; !ec && it != end; it.increment(ec)) {
        if (!IsJpg(it->path())) continue;
        const std::string name = it->path().filename().string();
        if (seen_.count(name)) continue;
        if (!it->is_regular_file(ec)) { ec.clear(); continue; }   // 不登记：等它变成普通文件再说
        seen_.insert(name);
        pending_.emplace(name, Pending{});
    }
}

void DirectoryFrameSource::Drop(const std::string& name, int DirectorySourceCounters::* counter)
{
    ++(counters_.*counter);
    pending_.erase(name);
}

bool DirectoryFrameSource::Next(PoseFrame& frame, std::string& id)
{
    const auto callTime = Clock::now();   // 调用方此刻刚处理完上一帧，限速从这里开始算
    auto lastIdleLog = callTime;
    bool hadIdleLog = false;

    while (!Stopped()) {
        ScanNewFiles();

        if (pending_.empty()) {
            const auto now = Clock::now();
            if (!hadIdleLog ? now - callTime >= std::chrono::milliseconds(opt_.idleLogMs)
                            : now - lastIdleLog >= std::chrono::milliseconds(opt_.idleLogMs)) {
                Log("[数据源] 目录 " + opt_.imageDir + " 没有新的 jpg，等待中……");
                lastIdleLog = now;
                hadIdleLog = true;
            }
            if (!SleepMs(opt_.pollMs)) return false;
            continue;
        }

        // 只看文件名最靠前的那张，保证按文件名顺序处理
        const std::string name = pending_.begin()->first;
        Pending& p = pending_.begin()->second;
        const fs::path path = fs::path(opt_.imageDir) / name;

        // ① 文件是否写完：大小和修改时间连续 stableMs 没变，且非空
        std::error_code ec;
        const auto sz = fs::file_size(path, ec);
        const auto mt = ec ? fs::file_time_type() : fs::last_write_time(path, ec);
        if (ec) { Log("[数据源] 文件已消失或无法访问，放弃：" + name + "（" + ec.message() + "）"); Drop(name, &DirectorySourceCounters::skippedUnreadable); continue; }
        const long long size = static_cast<long long>(sz);
        const long long mtime = static_cast<long long>(mt.time_since_epoch().count());
        const auto now = Clock::now();
        if (!p.inited) { p.inited = true; p.firstSeen = now; p.changedAt = now; p.size = size; p.mtime = mtime; }
        else if (size != p.size || mtime != p.mtime) { p.size = size; p.mtime = mtime; p.changedAt = now; }

        const bool stable = size > 0 && now - p.changedAt >= std::chrono::milliseconds(opt_.stableMs);
        if (!stable) {
            if (now - p.firstSeen >= std::chrono::milliseconds(opt_.stableTimeoutMs)) {
                Log(Fmt("[数据源] 文件 %.0f 秒内一直没写完（大小 %lld 字节），放弃：%s", opt_.stableTimeoutMs / 1000.0, size, name.c_str()));
                Drop(name, &DirectorySourceCounters::skippedUnreadable);
                continue;
            }
            if (!SleepMs(std::min(opt_.pollMs, 100))) return false;
            continue;
        }

        // ② 位姿（来自文件名）与过滤。被跳过的帧不占限速间隔
        FramePos pos;
        if (!ParseFramePos(name, pos)) { Log("[数据源] 跳过：文件名解析不出经纬度：" + name); Drop(name, &DirectorySourceCounters::skippedBadName); continue; }
        if (!std::isfinite(pos.relAlt) || !std::isfinite(pos.yaw)) {
            Log(std::string("[数据源] 跳过：文件名缺少 ") + (!std::isfinite(pos.relAlt) ? "RelAlt" : "Yaw") + "：" + name);
            Drop(name, &DirectorySourceCounters::skippedNoPose);
            continue;
        }
        if (opt_.maxWorkHeight > opt_.minWorkHeight && (pos.relAlt < opt_.minWorkHeight || pos.relAlt > opt_.maxWorkHeight)) {
            Log(Fmt("[数据源] 跳过：相对高度 %.2f 米不在 [%.0f, %.0f] 范围内：%s", pos.relAlt, opt_.minWorkHeight, opt_.maxWorkHeight, name.c_str()));
            Drop(name, &DirectorySourceCounters::skippedHeight);
            continue;
        }

        // ③ 限速：这一张之前至少空出 invokeIntervalMs（从调用 Next 起算）
        if (opt_.invokeIntervalMs > 0 && counters_.delivered > 0) {
            const auto wait = callTime + std::chrono::milliseconds(opt_.invokeIntervalMs) - Clock::now();
            if (wait > Clock::duration::zero()
                && !SleepMs(static_cast<int>(std::chrono::duration_cast<std::chrono::milliseconds>(wait).count()))) return false;
        }

        // ④ 读图。先确认 jpg 有结束标记：没有 = 还没写完（写入方可能中途停顿），继续等，不占重试次数，超时由 ① 的 stableTimeoutMs 处理
        if (!JpegComplete(path)) {
            if (!p.warnedIncomplete) { Log("[数据源] jpg 还没写完（缺结束标记），继续等待：" + name); p.warnedIncomplete = true; }
            p.changedAt = Clock::now();
            if (!SleepMs(opt_.pollMs)) return false;
            continue;
        }
        // 读失败不能让进程崩：重试几次，再不行就放弃这一张
        cv::Mat img;
        try { img = cv::imread(path.string(), cv::IMREAD_COLOR); }
        catch (const cv::Exception& e) { Log(std::string("[数据源] imread 异常：") + e.what()); }
        if (img.empty()) {
            if (++p.retries >= opt_.maxReadRetries) {
                Log(Fmt("[数据源] 读取失败 %d 次，放弃：%s", p.retries, name.c_str()));
                Drop(name, &DirectorySourceCounters::skippedUnreadable);
            } else {
                Log(Fmt("[数据源] 读取失败（第 %d 次），稍后重试：%s", p.retries, name.c_str()));
                p.changedAt = Clock::now();   // 重新要求稳定一段时间
                if (!SleepMs(opt_.pollMs)) return false;
            }
            continue;
        }

        // ⑤ 交出
        frame = PoseFrame();
        frame.ImageMat = std::move(img);
        if (pos.tsec >= 0) frame.TimeStamp = Fmt("%02d%02d%02d000", pos.tsec / 3600, pos.tsec / 60 % 60, pos.tsec % 60);
        else               frame.TimeStamp = NowTimeString();
        frame.Longitude = pos.lon;
        frame.Latitude = pos.lat;
        frame.RelativeHeight = pos.relAlt;
        frame.Yaw = pos.yaw;
        frame.Pitch = pos.pitch;
        frame.Roll = pos.roll;
        id = path.stem().string();

        ++counters_.delivered;
        pending_.erase(name);
        return true;
    }
    return false;
}