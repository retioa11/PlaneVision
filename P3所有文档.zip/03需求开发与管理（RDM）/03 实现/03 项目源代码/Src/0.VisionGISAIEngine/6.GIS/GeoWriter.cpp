// 见 GeoWriter.h
#include "GeoWriter.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <memory>
#include <mutex>

#include <cpl_string.h>
#include <gdal_priv.h>
#include <ogrsf_frmts.h>

#include "../1.Common/EngineFunction.h"
#include "GISHelper.h"

namespace fs = std::filesystem;

void EnsureGdalInit()
{
    static std::once_flag once;
    std::call_once(once, [] { GDALAllRegister(); });
}

namespace
{

// 以 cm 为中央子午线的高斯-克吕格 SRS（CGCS2000 椭球，东偏 = 带号*1e6+500000）
OGRSpatialReference MakeGaussSRS(double cm, int zoneDeg)
{
    OGRSpatialReference srs;
    srs.SetGeogCS("CGCS2000", "China_2000", "CGCS2000", 6378137.0, 298.257222101,
                  "Greenwich", 0.0, "Degree", 0.0174532925199433);
    srs.SetTM(0.0, cm, 1.0, GaussFalseEasting(cm, zoneDeg), 0.0);
    srs.SetAxisMappingStrategy(OAMS_TRADITIONAL_GIS_ORDER);
    return srs;
}

OGRSpatialReference MakeWgs84SRS()
{
    OGRSpatialReference srs;
    srs.SetWellKnownGeogCS("WGS84");
    srs.SetAxisMappingStrategy(OAMS_TRADITIONAL_GIS_ORDER);
    return srs;
}

OGRSpatialReference MakeSRS(const GeoSrs& s)
{
    return s.gauss ? MakeGaussSRS(s.cm, s.zoneDeg) : MakeWgs84SRS();
}

// 写每帧 GeoTIFF 时 cm 基本不变，缓存最近一次的 WKT，避免每帧重建 SRS 并导出
const std::string& CachedGaussWkt(double cm, int zoneDeg)
{
    thread_local double      lastCm   = std::nan("");
    thread_local int         lastZone = 0;
    thread_local std::string wkt;
    if (!(lastCm == cm && lastZone == zoneDeg))
    {
        char* w = nullptr;
        MakeGaussSRS(cm, zoneDeg).exportToWkt(&w);
        wkt      = w ? w : "";
        CPLFree(w);
        lastCm   = cm;
        lastZone = zoneDeg;
    }
    return wkt;
}

// 传给 GDAL 的文件名：Windows 下要 UTF-8，本地编码需转换（其他平台原样）
std::string GdalPath(const std::string& localPath) { return LocalToUtf8(localPath); }

}  // namespace

// ═════════════════════════════════════════════════════════════════════════════
// GeoTIFF
// ═════════════════════════════════════════════════════════════════════════════

bool WriteGeoTiff(const std::string& path, const cv::Mat& img,
                  double originE, double originN, double gsd, double cm, int jpegQuality, int zoneDeg)
{
    GeoTiffOptions opt;
    opt.jpegQuality = jpegQuality;
    opt.zoneDeg     = zoneDeg;
    return WriteGeoTiff(path, img, originE, originN, gsd, cm, opt);
}

bool WriteGeoTiff(const std::string& path, const cv::Mat& img,
                  double originE, double originN, double gsd, double cm, const GeoTiffOptions& opt)
{
    const int nb = img.channels();
    if (img.empty() || img.depth() != CV_8U || (nb != 3 && nb != 4))
    {
        std::printf("WriteGeoTiff: 需要 8 位 3/4 通道图像\n");
        return false;
    }
    for (const auto& kv : opt.metadata)
    {
        const bool badKey = kv.first.empty() ||
            kv.first.find_first_of("= \t\r\n") != std::string::npos;
        if (badKey)
        {
            std::printf("WriteGeoTiff: 元数据键不合法（不能为空或含 '=' / 空白）: \"%s\"\n", kv.first.c_str());
            return false;
        }
    }
    EnsureGdalInit();
    GDALDriver* drv = GetGDALDriverManager()->GetDriverByName("GTiff");
    if (!drv) { std::printf("找不到 GTiff 驱动\n"); return false; }

    char** opts = nullptr;
    if (opt.lossless)
    {
        opts = CSLSetNameValue(opts, "COMPRESS",  "DEFLATE");
        opts = CSLSetNameValue(opts, "PREDICTOR", "2");
        if (nb == 4) opts = CSLSetNameValue(opts, "ALPHA", "YES");
    }
    else if (nb == 3)
    {
        char q[8];
        std::snprintf(q, sizeof(q), "%d", std::min(100, std::max(1, opt.jpegQuality)));
        opts = CSLSetNameValue(opts, "COMPRESS",     "JPEG");
        opts = CSLSetNameValue(opts, "JPEG_QUALITY", q);
        opts = CSLSetNameValue(opts, "PHOTOMETRIC",  "YCBCR");
    }
    else
    {
        opts = CSLSetNameValue(opts, "COMPRESS", "LZW");
        opts = CSLSetNameValue(opts, "ALPHA",    "YES");
    }
    const int w = img.cols, h = img.rows;
    GDALDataset* ds = drv->Create(GdalPath(path).c_str(), w, h, nb, GDT_Byte, opts);
    CSLDestroy(opts);
    if (!ds) { std::printf("创建 GeoTIFF 失败: %s\n", path.c_str()); return false; }

    double gt[6] = { originE, gsd, 0.0, originN, 0.0, -gsd };
    ds->SetGeoTransform(gt);
    ds->SetProjection(CachedGaussWkt(cm, opt.zoneDeg).c_str());
    for (const auto& kv : opt.metadata)
        ds->SetMetadataItem(kv.first.c_str(), LocalToUtf8(kv.second).c_str());

    // 一次性交错写入：缓冲区是 BGR(A) 交错排列，波段映射 B→3、G→2、R→1、A→4，无需 cv::split
    const cv::Mat buf = img.isContinuous() ? img : img.clone();
    int bandMap[4] = { 3, 2, 1, 4 };
    const bool ok = ds->RasterIO(GF_Write, 0, 0, w, h, const_cast<uchar*>(buf.data), w, h, GDT_Byte,
                                 nb, bandMap,
                                 /*nPixelSpace*/ nb, /*nLineSpace*/ static_cast<GSpacing>(w) * nb, /*nBandSpace*/ 1) == CE_None;
    if (nb == 4) ds->GetRasterBand(4)->SetColorInterpretation(GCI_AlphaBand);
    GDALClose(ds);
    if (!ok) std::printf("写波段失败: %s\n", path.c_str());
    return ok;
}

// ── 读 GeoTIFF ────────────────────────────────────────────────────────────────

namespace
{
struct DatasetCloser
{
    void operator()(GDALDataset* d) const { if (d) GDALClose(d); }
};
}  // namespace

bool ReadGeoTiff(const std::string& path, cv::Mat& bgr, GeoTiffInfo& info)
{
    EnsureGdalInit();
    std::unique_ptr<GDALDataset, DatasetCloser> ds(static_cast<GDALDataset*>(
        GDALOpenEx(GdalPath(path).c_str(), GDAL_OF_RASTER | GDAL_OF_READONLY, nullptr, nullptr, nullptr)));
    if (!ds) { std::printf("ReadGeoTiff: 打不开 %s\n", path.c_str()); return false; }

    const int w = ds->GetRasterXSize(), h = ds->GetRasterYSize(), nb = ds->GetRasterCount();
    if (w <= 0 || h <= 0 || (nb != 3 && nb != 4))
    {
        std::printf("ReadGeoTiff: 需要 3/4 个波段，实际 %d 个: %s\n", nb, path.c_str());
        return false;
    }
    for (int b = 1; b <= nb; ++b)
        if (ds->GetRasterBand(b)->GetRasterDataType() != GDT_Byte)
        {
            std::printf("ReadGeoTiff: 只支持 8 位波段: %s\n", path.c_str());
            return false;
        }

    // 地理变换：北向上、无旋转、正方形像素
    double gt[6];
    if (ds->GetGeoTransform(gt) != CE_None)
    {
        std::printf("ReadGeoTiff: 没有地理变换: %s\n", path.c_str());
        return false;
    }
    if (gt[2] != 0.0 || gt[4] != 0.0 || !(gt[1] > 0.0) || !(gt[5] < 0.0) ||
        std::fabs(gt[1] + gt[5]) > 1e-6 * gt[1])
    {
        std::printf("ReadGeoTiff: 需要北向上、无旋转的正方形像素: %s\n", path.c_str());
        return false;
    }

    // 坐标系：横轴墨卡托，取中央子午线；带宽由东偏的带号反推
    const OGRSpatialReference* srs = ds->GetSpatialRef();
    const char* proj = srs ? srs->GetAttrValue("PROJECTION") : nullptr;
    if (!proj || !EQUAL(proj, SRS_PT_TRANSVERSE_MERCATOR))
    {
        std::printf("ReadGeoTiff: 不是高斯-克吕格（横轴墨卡托）投影: %s\n", path.c_str());
        return false;
    }
    OGRErr e1 = OGRERR_NONE, e2 = OGRERR_NONE;
    const double cm = srs->GetNormProjParm(SRS_PP_CENTRAL_MERIDIAN, 0.0, &e1);
    const double fe = srs->GetNormProjParm(SRS_PP_FALSE_EASTING,     0.0, &e2);
    if (e1 != OGRERR_NONE || e2 != OGRERR_NONE)
    {
        std::printf("ReadGeoTiff: 读不到中央子午线 / 东偏: %s\n", path.c_str());
        return false;
    }
    const int zone    = static_cast<int>(std::floor(fe / 1e6));   // 东偏 = 带号*1e6 + 500000
    int       zoneDeg = 3;
    if (std::fabs(cm - 3.0 * zone) < 1e-6)            zoneDeg = 3;
    else if (std::fabs(cm - (6.0 * zone - 3.0)) < 1e-6) zoneDeg = 6;

    // 像素：一次性交错读出，波段映射与写出一致（B→3、G→2、R→1、A→4）
    cv::Mat img(h, w, nb == 3 ? CV_8UC3 : CV_8UC4);
    int bandMap[4] = { 3, 2, 1, 4 };
    if (ds->RasterIO(GF_Read, 0, 0, w, h, img.data, w, h, GDT_Byte, nb, bandMap,
                     /*nPixelSpace*/ nb, /*nLineSpace*/ static_cast<GSpacing>(w) * nb, /*nBandSpace*/ 1) != CE_None)
    {
        std::printf("ReadGeoTiff: 读波段失败: %s\n", path.c_str());
        return false;
    }

    info = GeoTiffInfo();
    info.originE = gt[0];
    info.originN = gt[3];
    info.gsd     = gt[1];
    info.cm      = cm;
    info.zoneDeg = zoneDeg;
    info.width   = w;
    info.height  = h;
    if (CSLConstList md = ds->GetMetadata())   // 新版 GDAL 返回 const 列表，旧版是 char**，都能赋给 CSLConstList
        for (int i = 0; md[i]; ++i)
        {
            char* key = nullptr;
            const char* val = CPLParseNameValue(md[i], &key);
            if (key && val && std::strcmp(key, "AREA_OR_POINT") != 0)   // 后者是 GDAL 自动加的
                info.metadata[key] = Utf8ToLocal(val);
            CPLFree(key);
        }
    bgr = std::move(img);
    return true;
}

// ═════════════════════════════════════════════════════════════════════════════
// GpkgWriter
// ═════════════════════════════════════════════════════════════════════════════

struct GpkgWriter::Impl
{
    struct Layer
    {
        OGRLayer*                  layer = nullptr;
        GpkgGeom                   geom  = GpkgGeom::Point;
        std::vector<GpkgFieldType> fieldTypes;
    };
    GDALDataset*       ds = nullptr;
    std::vector<Layer> layers;
};

namespace
{

// 把 attrs 按位置写入要素字段；个数或类型与图层字段不一致返回 false。字符串是本地编码，GPKG 内部存 UTF-8。
bool FillAttrs(OGRFeature* feat, const std::vector<GpkgFieldType>& types, const std::vector<GpkgValue>& attrs)
{
    if (attrs.size() != types.size()) return false;
    for (size_t i = 0; i < attrs.size(); ++i)
    {
        const int idx = static_cast<int>(i);
        switch (types[i])
        {
            case GpkgFieldType::Int:
                if (!std::holds_alternative<int>(attrs[i])) return false;
                feat->SetField(idx, std::get<int>(attrs[i]));
                break;
            case GpkgFieldType::Real:
                if (!std::holds_alternative<double>(attrs[i])) return false;
                feat->SetField(idx, std::get<double>(attrs[i]));
                break;
            case GpkgFieldType::String:
                if (!std::holds_alternative<std::string>(attrs[i])) return false;
                feat->SetField(idx, LocalToUtf8(std::get<std::string>(attrs[i])).c_str());
                break;
        }
    }
    return true;
}

}  // namespace

GpkgWriter::GpkgWriter() : m_impl(new Impl) {}

GpkgWriter::~GpkgWriter()
{
    Close();
    delete m_impl;
}

bool GpkgWriter::IsOpen() const { return m_impl->ds != nullptr; }

bool GpkgWriter::Open(const std::string& path)
{
    Close();
    EnsureGdalInit();
    GDALDriver* drv = GetGDALDriverManager()->GetDriverByName("GPKG");
    if (!drv) { std::printf("找不到 GPKG 驱动\n"); return false; }

    std::error_code ec;
    fs::remove(fs::path(path), ec);   // 覆盖旧文件
    m_impl->ds = drv->Create(GdalPath(path).c_str(), 0, 0, 0, GDT_Unknown, nullptr);
    if (!m_impl->ds) { std::printf("创建 gpkg 失败: %s\n", path.c_str()); return false; }
    return true;
}

int GpkgWriter::AddLayer(const std::string& name, GpkgGeom geom, const GeoSrs& srs, const std::vector<GpkgField>& fields)
{
    if (!m_impl->ds) return -1;

    OGRSpatialReference ogrSrs = MakeSRS(srs);
    OGRLayer* layer = m_impl->ds->CreateLayer(name.c_str(), &ogrSrs,
                                              geom == GpkgGeom::Point ? wkbPoint : wkbPolygon, nullptr);
    if (!layer) { std::printf("创建 gpkg 图层失败: %s\n", name.c_str()); return -1; }

    Impl::Layer info;
    info.layer = layer;
    info.geom  = geom;
    for (const GpkgField& f : fields)
    {
        const OGRFieldType t = f.type == GpkgFieldType::Int  ? OFTInteger
                             : f.type == GpkgFieldType::Real ? OFTReal : OFTString;
        OGRFieldDefn def(f.name.c_str(), t);
        if (layer->CreateField(&def) != OGRERR_NONE)
        {
            std::printf("创建 gpkg 字段失败: %s.%s\n", name.c_str(), f.name.c_str());
            return -1;
        }
        info.fieldTypes.push_back(f.type);
    }
    m_impl->layers.push_back(std::move(info));
    return static_cast<int>(m_impl->layers.size()) - 1;
}

bool GpkgWriter::Begin()
{
    return m_impl->ds && m_impl->ds->StartTransaction() == OGRERR_NONE;
}

bool GpkgWriter::Commit()
{
    return m_impl->ds && m_impl->ds->CommitTransaction() == OGRERR_NONE;
}

void GpkgWriter::Rollback()
{
    if (m_impl->ds) m_impl->ds->RollbackTransaction();
}

bool GpkgWriter::AddPoint(int layer, double x, double y, const std::vector<GpkgValue>& attrs)
{
    if (!m_impl->ds || layer < 0 || layer >= static_cast<int>(m_impl->layers.size())) return false;
    const Impl::Layer& L = m_impl->layers[static_cast<size_t>(layer)];
    if (L.geom != GpkgGeom::Point) return false;

    OGRFeature* feat = OGRFeature::CreateFeature(L.layer->GetLayerDefn());
    bool ok = FillAttrs(feat, L.fieldTypes, attrs);
    if (ok)
    {
        OGRPoint pt(x, y);
        feat->SetGeometry(&pt);
        ok = L.layer->CreateFeature(feat) == OGRERR_NONE;
    }
    OGRFeature::DestroyFeature(feat);
    return ok;
}

bool GpkgWriter::AddPolygon(int layer, const std::vector<cv::Point2d>& ring, const std::vector<GpkgValue>& attrs)
{
    if (!m_impl->ds || layer < 0 || layer >= static_cast<int>(m_impl->layers.size()) || ring.size() < 3) return false;
    const Impl::Layer& L = m_impl->layers[static_cast<size_t>(layer)];
    if (L.geom != GpkgGeom::Polygon) return false;

    OGRFeature* feat = OGRFeature::CreateFeature(L.layer->GetLayerDefn());
    bool ok = FillAttrs(feat, L.fieldTypes, attrs);
    if (ok)
    {
        OGRLinearRing lr;
        for (const cv::Point2d& p : ring) lr.addPoint(p.x, p.y);
        lr.closeRings();
        OGRPolygon poly;
        poly.addRing(&lr);
        feat->SetGeometry(&poly);
        ok = L.layer->CreateFeature(feat) == OGRERR_NONE;
    }
    OGRFeature::DestroyFeature(feat);
    return ok;
}

void GpkgWriter::Close()
{
    if (m_impl->ds) { GDALClose(m_impl->ds); m_impl->ds = nullptr; }
    m_impl->layers.clear();
}