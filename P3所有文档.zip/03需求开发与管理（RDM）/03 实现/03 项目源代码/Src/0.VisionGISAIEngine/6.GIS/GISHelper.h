#pragma once
#include <opencv2/opencv.hpp>
#include <QtCore/qpoint.h>
#include <QtCore/QString>
#include <gdal_pam.h>
#include <QtCore/qpair.h>

#include "../1.Common/MacroEnumStruct.h"

// ── 前向声明（避免此头文件直接引入 ImageMatcher.h）──────────────────────────
struct KeypointFeatures;
struct TileFeature;
struct TileConfig;

// ─────────────────────────────────────────────────────────────────────────────
// 原有 GIS 工具函数（保持不变）
// ─────────────────────────────────────────────────────────────────────────────

VGA_API cv::Point2d CalcGroundToAir(double ground_height, cv::Point3d attitude);

VGA_API void PixelToGeography(int pixel_col, int pixel_row,
                               double& geography_x, double& geography_y,
                               double geo_transform[6]);

VGA_API void GeographyToPixel(double geography_x, double geography_y,
                               int& pixel_col, int& pixel_row,
                               double geo_transform[6]);

// ── 高斯-克吕格投影（3° / 6° 带通用；CGCS2000 椭球；东偏含带号 = 带号*1e6 + 500000）────
// zoneDeg：带宽，3 或 6。

// 经度所在带的中央子午线（度）。整个任务需要固定带时，取首个点算一次，之后一直传同一个 cm。
VGA_API double GaussCentralMeridian(double lonDeg, int zoneDeg = 3);

// 子午线收敛角（度）：格网北相对真北的偏角，可逐点现算。格网航向 = 真航向 - 收敛角。
VGA_API double MeridianConvergence(double lonDeg, double latDeg, double cm);

// 带号与含带号东偏：3° 带 cm = 3*zone；6° 带 cm = 6*zone - 3。东偏 = 带号*1e6 + 500000。
VGA_API int    GaussZone(double cm, int zoneDeg = 3);
VGA_API double GaussFalseEasting(double cm, int zoneDeg = 3);

// 经纬度(度) → 高斯坐标(米)。E 为含带号东偏，N 为北坐标。
//   带 cm 版本：投影到指定中央子午线（跨带飞行时保证坐标连续）；不带 cm 版本：自动取所在带。
VGA_API void LonLatToGauss(double lon, double lat, double cm, int zoneDeg, double& E, double& N);
VGA_API void LonLatToGauss(double lon, double lat, int zoneDeg, double& E, double& N);

// 高斯坐标(米) → 经纬度(度)。带号取自 E 的百万位，其余部分按 zoneDeg 还原中央子午线。
VGA_API void GaussToLonLat(double E, double N, int zoneDeg, double& lon, double& lat);

VGA_API double GetElevation(double longitude, double latitude,
                             cv::Mat& dem_mat, double geo_transform[6]);

VGA_API void SavePositioningPoint(QString shape_file_path,
                                   QList<QMap<QString, QString>> point_list);

VGA_API void ConvertGSDToDegrees(double gsd, double latitude,
                                  double& gsdLongitude, double& gsdLatitude);

VGA_API bool IsYawWithinAxesRange(double yaw, double yaw_tolerance);

VGA_API void PointListToShp(QList<QPair<QString, QPointF>> point_list,
                             QString& shp_file_path);

VGA_API void ConvertFileNameToShp(QString& dir_path, QString& file_suffix,
                                   QString& shp_file_path);

VGA_API bool IsGaussKruger3Degree(GDALDataset* dataset);

VGA_API bool IsWGS84(GDALDataset* dataset);

VGA_API double ManhattanDistance(double lon1, double lat1,
                                  double lon2, double lat2);

VGA_API void GenerateResultRaster(std::string& image_path,
                                   cv::Mat& realtime_mat,
                                   int clip_left, int clip_top,
                                   double geo_transform[6],
                                   QString& content);

VGA_API void GenerateShpFile(std::string& file_path,
                               std::vector<std::vector<double>>& polygon_x_list,
                               std::vector<std::vector<double>>& polygon_y_list,
                               std::vector<int>& kind_id_list);


