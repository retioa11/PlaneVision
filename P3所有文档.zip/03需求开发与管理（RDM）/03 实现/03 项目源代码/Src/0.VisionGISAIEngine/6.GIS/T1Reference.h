﻿#pragma once
// T1 基准图裁剪：从 T1 瓦片库（TileDB）里裁出一张与目标网格对齐的参考图。
//
// 目标网格 = 一张"高斯坐标、正北向上"的图：左上角地面位置 (originE, originN)、像素大小 gsd（米/像素）、尺寸 size。
// 因为两边都是高斯坐标、都是北向上，只需要重采样，不需要旋转。
// 用途：配准（Register：与 NormalizedTile 同原点、同 GSD、同尺寸）；
//       变化检测（6.ChangeDetect：以 T1 自己的像素大小裁，此时重采样系数为 1）。
//
// 线程：TileDBContext 带滑动窗口缓存，不是线程安全的；同一个 db 同一时刻只能被一个线程调用。
#include <string>

#include <opencv2/core.hpp>

#include "../1.Common/MacroEnumStruct.h"

struct TileDBContext;

// 从 T1 的 3×3 瓦片拼出一张画布，再一次 warpAffine 重采样到目标网格。覆盖不到的地方为黑色。
//   db       已经 TileDB_Open 成功的 T1 库
//   originE/N 目标网格左上角（像素 (0,0) 的左上角）的高斯坐标，E 含带号
//   gsd      目标网格的像素大小（米/像素）
//   size     目标网格尺寸
//   zoneDeg  带宽（3 或 6），用来把网格中心反算成经纬度去查瓦片；带号取自 originE 的百万位
//   ref      输出：BGR 8 位，尺寸 = size
//   cover    输出：有效（被 T1 覆盖）像素占比 0~1
//   why      失败原因：T1NoTile（查不到瓦片 / 瓦片全部解码失败 / 库的像素大小无效）、BadArgument（gsd 或 size 无效）
// 返回 false 时 ref / cover 不保证有效。
VGA_API bool CropT1(TileDBContext& db, double originE, double originN, double gsd, cv::Size size,
                    int zoneDeg, cv::Mat& ref, double& cover, std::string& why);
