﻿# pragma execution_character_set("utf-8")

#include <shapefil.h>
#include "GISHelper.h"

#include <fstream>

#include "../1.Common/EngineFunction.h"
#include <QtCore/QDir>

#include "TileDB.h"

// 根据飞行的相对地面高度和姿态，计算匹配点地面经纬度和无人机经纬度的位置偏移， pos_attitude 的各元素依次为：横滚俯仰偏航
cv::Point2d CalcGroundToAir(double ground_height, cv::Point3d attitude)
{
    auto roll_angle = attitude.x * CV_PI / 180; // 横滚角
    auto pitch_angle = attitude.y * CV_PI / 180; // 俯仰角
    auto yaw_angle = attitude.z * CV_PI / 180; // 偏航角
    auto roll_offset = ground_height * tan(roll_angle); // 以匹配点为原点的X轴分量
    auto pitch_offset = -ground_height * tan(pitch_angle); // 以匹配点为原点的Y轴分量
    auto x_offset = roll_offset * cos(yaw_angle) + pitch_offset * sin(yaw_angle);
    auto y_offset = pitch_offset * cos(yaw_angle) - roll_offset * sin(yaw_angle);
    return {x_offset, y_offset};
}

void PixelToGeography(int pixel_col, int pixel_row, double& geography_x, double& geography_y, double geo_transform[6])
{
    geography_x = geo_transform[0] + pixel_col * geo_transform[1];
    geography_y = geo_transform[3] + pixel_row * geo_transform[5];
}

void GeographyToPixel(double geography_x, double geography_y, int& pixel_col, int& pixel_row, double geo_transform[6])
{
    pixel_col = (geography_x - geo_transform[0]) / geo_transform[1];
    pixel_row = (geography_y - geo_transform[3]) / geo_transform[5];
}

// ─────────────────────────────────────────────────────────────────────────────
// 高斯-克吕格投影（3° / 6° 带共用一套实现）
// 椭球：CGCS2000（与 WGS84 的差异在本用途下 < 0.1 mm）。展开：Krüger n 级数（4 阶），全带内精度 < 1 mm。
// ─────────────────────────────────────────────────────────────────────────────
namespace
{
constexpr double kEllA = 6378137.0;
constexpr double kEllF = 1.0 / 298.257222101;

struct KrugerSeries { double n, A, alpha[4], beta[4], delta[4]; };

const KrugerSeries& Series()
{
    static const KrugerSeries s = [] {
        KrugerSeries k;
        const double n = kEllF / (2.0 - kEllF), n2 = n * n, n3 = n2 * n, n4 = n3 * n;
        k.n = n;
        k.A = kEllA / (1 + n) * (1 + n2 / 4 + n4 / 64);
        k.alpha[0] = n / 2 - 2 * n2 / 3 + 5 * n3 / 16 + 41 * n4 / 180;
        k.alpha[1] = 13 * n2 / 48 - 3 * n3 / 5 + 557 * n4 / 1440;
        k.alpha[2] = 61 * n3 / 240 - 103 * n4 / 140;
        k.alpha[3] = 49561 * n4 / 161280;
        k.beta[0] = n / 2 - 2 * n2 / 3 + 37 * n3 / 96 - n4 / 360;
        k.beta[1] = n2 / 48 + n3 / 15 - 437 * n4 / 1440;
        k.beta[2] = 17 * n3 / 480 - 37 * n4 / 840;
        k.beta[3] = 4397 * n4 / 161280;
        k.delta[0] = 2 * n - 2 * n2 / 3 - 2 * n3 + 116 * n4 / 45;
        k.delta[1] = 7 * n2 / 3 - 8 * n3 / 5 - 227 * n4 / 45;
        k.delta[2] = 56 * n3 / 15 - 136 * n4 / 35;
        k.delta[3] = 4279 * n4 / 630;
        return k;
    }();
    return s;
}

double WrapLon180(double lon) { return lon - 360.0 * std::floor((lon + 180.0) / 360.0); }   // → [-180, 180)

// 带号 ↔ 中央子午线：3° 带 cm = 3*zone；6° 带 cm = 6*zone - 3
int    ZoneOfCm(double cm, int zoneDeg) { return static_cast<int>(std::lround(zoneDeg == 6 ? (cm + 3.0) / 6.0 : cm / 3.0)); }
double CmOfZone(int zone, int zoneDeg)  { return zoneDeg == 6 ? zone * 6.0 - 3.0 : zone * 3.0; }
}  // namespace

int GaussZone(double cm, int zoneDeg) { return ZoneOfCm(cm, zoneDeg); }

double GaussFalseEasting(double cm, int zoneDeg) { return ZoneOfCm(cm, zoneDeg) * 1000000.0 + 500000.0; }

double GaussCentralMeridian(double lonDeg, int zoneDeg)
{
    const double l = lonDeg - 360.0 * std::floor(lonDeg / 360.0);   // [0, 360)
    return zoneDeg == 6 ? (static_cast<int>(l / 6.0) + 1) * 6.0 - 3.0
                        : 3.0 * std::floor(l / 3.0 + 0.5);
}

double MeridianConvergence(double lonDeg, double latDeg, double cm)
{
    const double dl = WrapLon180(lonDeg - cm) * CV_PI / 180.0;
    return std::atan(std::tan(dl) * std::sin(latDeg * CV_PI / 180.0)) * 180.0 / CV_PI;
}

void LonLatToGauss(double lon, double lat, double cm, int zoneDeg, double& E, double& N)
{
    const KrugerSeries& s = Series();
    const double lam = WrapLon180(lon - cm) * CV_PI / 180.0;
    const double sp  = std::sin(lat * CV_PI / 180.0);
    const double q   = 2.0 * std::sqrt(s.n) / (1.0 + s.n);
    const double t   = std::sinh(std::atanh(sp) - q * std::atanh(q * sp));
    const double xi0 = std::atan2(t, std::cos(lam));
    const double eta0 = std::atanh(std::sin(lam) / std::sqrt(1.0 + t * t));

    double xi = xi0, eta = eta0;
    for (int j = 1; j <= 4; ++j) {
        xi  += s.alpha[j - 1] * std::sin(2 * j * xi0) * std::cosh(2 * j * eta0);
        eta += s.alpha[j - 1] * std::cos(2 * j * xi0) * std::sinh(2 * j * eta0);
    }
    E = s.A * eta + ZoneOfCm(cm, zoneDeg) * 1000000.0 + 500000.0;   // 含带号东偏
    N = s.A * xi;
}

void LonLatToGauss(double lon, double lat, int zoneDeg, double& E, double& N)
{
    LonLatToGauss(lon, lat, GaussCentralMeridian(lon, zoneDeg), zoneDeg, E, N);
}

void GaussToLonLat(double E, double N, int zoneDeg, double& lon, double& lat)
{
    const KrugerSeries& s = Series();
    const int    zone = static_cast<int>(E / 1000000.0);
    const double cm   = CmOfZone(zone, zoneDeg);
    const double eta  = (E - zone * 1000000.0 - 500000.0) / s.A;
    const double xi   = N / s.A;

    double xi0 = xi, eta0 = eta;
    for (int j = 1; j <= 4; ++j) {
        xi0  -= s.beta[j - 1] * std::sin(2 * j * xi) * std::cosh(2 * j * eta);
        eta0 -= s.beta[j - 1] * std::cos(2 * j * xi) * std::sinh(2 * j * eta);
    }
    const double chi = std::asin(std::sin(xi0) / std::cosh(eta0));
    double phi = chi;
    for (int j = 1; j <= 4; ++j) phi += s.delta[j - 1] * std::sin(2 * j * chi);

    lat = phi * 180.0 / CV_PI;
    lon = WrapLon180(cm + std::atan2(std::sinh(eta0), std::cos(xi0)) * 180.0 / CV_PI);
}

double GetElevation(double longitude, double latitude, cv::Mat& dem_mat, double geo_transform[6])
{
    int pixel_col = (longitude - geo_transform[0]) / geo_transform[1];
    int pixel_row = (latitude - geo_transform[3]) / geo_transform[5];
    if (pixel_col < 0 || pixel_col >= dem_mat.cols || pixel_row < 0 || pixel_row >= dem_mat.rows)
        return 0.0;
    return dem_mat.at<float>(pixel_row, pixel_col);
}

void SavePositioningPoint(QString shape_file_path, QList<QMap<QString, QString>> point_list)
{
    SHPHandle outShp = SHPCreate(shape_file_path.toLocal8Bit().constData(), SHPT_POINT);
    DBFHandle dbf_h = DBFCreate(shape_file_path.toLocal8Bit().constData());
    DBFAddField(dbf_h, "Id", FTString, 11, 0);
    DBFAddField(dbf_h, "Longitude", FTDouble, 11, 6);
    DBFAddField(dbf_h, "Latitude", FTDouble, 11, 6);
    for (int ir = 0; ir < point_list.size(); ir++)
    {
        auto* xCoords = new double[1];
        auto* yCoords = new double[1];
        xCoords[0] = point_list[ir]["Longitude"].toDouble();
        yCoords[0] = point_list[ir]["Latitude"].toDouble();
        auto psShape = SHPCreateObject(SHPT_POINT, -1, 0, NULL, NULL, 1, xCoords, yCoords, NULL, NULL);
        int id = SHPWriteObject(outShp, -1, psShape);
        DBFWriteStringAttribute(dbf_h, id, 0, point_list[ir]["Code"].toLocal8Bit().constData());
        DBFWriteDoubleAttribute(dbf_h, id, 1, xCoords[0]);
        DBFWriteDoubleAttribute(dbf_h, id, 2, yCoords[0]);
        SHPDestroyObject(psShape);
        delete[] xCoords;
        delete[] yCoords;
    }
    SHPClose(outShp);
    DBFClose(dbf_h);
}

void ConvertGSDToDegrees(double gsd, double latitude, double& gsdLongitude, double& gsdLatitude)
{
    const double earthRadius = 6378137.0;
    gsdLatitude  = gsd / earthRadius * 180.0 / CV_PI;
    gsdLongitude = gsd / (earthRadius * cos(latitude * CV_PI / 180.0)) * 180.0 / CV_PI;
}

bool IsYawWithinAxesRange(double yaw, double yaw_tolerance)
{
    while (yaw >  180.0) yaw -= 360.0;
    while (yaw < -180.0) yaw += 360.0;
    return std::abs(yaw) <= yaw_tolerance || std::abs(std::abs(yaw) - 90.0) <= yaw_tolerance
        || std::abs(std::abs(yaw) - 180.0) <= yaw_tolerance;
}

void PointListToShp(QList<QPair<QString, QPointF>> point_list, QString& shp_file_path)
{
    QFile temp(shp_file_path);
    if (temp.exists())
    {
        qDebug() << "File is not existed:" + shp_file_path << __LINE__ << "@" << __FILENAME__;
    }
    SHPHandle outShp = SHPCreate(shp_file_path.toLocal8Bit().constData(), SHPT_POINT);
    DBFHandle dbf_h = DBFCreate(shp_file_path.toLocal8Bit().constData());
    DBFAddField(dbf_h, "SysTime", FTString, 22, 0);
    DBFAddField(dbf_h, "Longitude", FTDouble, 11, 6);
    DBFAddField(dbf_h, "Latitude", FTDouble, 11, 6);
    for (auto& item : point_list)
    {
        auto id = item.first;
        auto longitude = item.second.x();
        auto latitude = item.second.y();
        auto object = SHPCreateObject(SHPT_POINT, -1, 0, NULL, NULL, 1, &longitude, &latitude, NULL, NULL);
        int result = SHPWriteObject(outShp, -1, object);
        DBFWriteStringAttribute(dbf_h, result, 0, id.toLocal8Bit().constData());
        DBFWriteDoubleAttribute(dbf_h, result, 1, longitude);
        DBFWriteDoubleAttribute(dbf_h, result, 2, latitude);
        SHPDestroyObject(object);
    }
    SHPClose(outShp);
    DBFClose(dbf_h);
}

void ConvertFileNameToShp(QString& dir_path, QString& file_suffix, QString& shp_file_path)
{
    QList<QPair<QString, QPointF>> point_list;
    QDir directory(dir_path);
    auto file_name_list = directory.entryList({file_suffix}, QDir::Files);
    for (int index = 0; index < file_name_list.size(); ++index)
    {
        auto file_name = file_name_list[index];
        FramePos pos;
        if (!ParseFramePos(file_name.toStdString(), pos)) continue;   // 文件名无法解析出经纬度：跳过
        point_list.append(QPair<QString, QPointF>(file_name, QPointF(pos.lon, pos.lat)));
    }
    PointListToShp(point_list, shp_file_path);
}

bool IsGaussKruger3Degree(GDALDataset* dataset)
{
    if (!dataset) return false;
    const char* proj = dataset->GetProjectionRef();
    if (!proj) return false;
    const std::string s(proj);
    return s.find("Gauss_Kruger") != std::string::npos
        || s.find("Transverse_Mercator") != std::string::npos;
}

bool IsWGS84(GDALDataset* dataset)
{
    if (!dataset) return false;
    const char* proj = dataset->GetProjectionRef();
    if (!proj) return false;
    const std::string s(proj);
    return s.find("WGS_1984") != std::string::npos || s.find("WGS84") != std::string::npos;
}

double ManhattanDistance(double lon1, double lat1, double lon2, double lat2)
{
    return std::abs(lon1 - lon2) + std::abs(lat1 - lat2);
}

void GenerateResultRaster(string& image_path,Mat& realtime_mat, int clip_left, int clip_top, double geo_transform[6],QString& content)
{
    cv::imwrite(image_path, realtime_mat);
    // 计算Gauss坐标转换到Wgs84坐标后的六参数
    double geography_x1, geography_y1, longitude1, latitude1;
    PixelToGeography(clip_left, clip_top, geography_x1, geography_y1, geo_transform);
    GaussToLonLat(geography_x1, geography_y1, 3, longitude1, latitude1);
    double geography_x2, geography_y2, longitude2, latitude2;
    PixelToGeography(clip_left + realtime_mat.cols, clip_top + realtime_mat.rows, geography_x2, geography_y2, geo_transform);
    GaussToLonLat(geography_x2, geography_y2, 3, longitude2, latitude2);
    auto resolution_x = (longitude2 - longitude1) / realtime_mat.cols;
    auto resolution_y = (latitude2 - latitude1) / realtime_mat.rows;
    content = QString::number(resolution_x, 10, 8) + "\n0\n0\n" + QString::number(resolution_y, 10, 8);
    content += "\n" + QString::number(longitude1, 10, 8) + "\n" + QString::number(latitude1, 10, 8);
    auto path = QString::fromLocal8Bit(image_path);
    path = path.replace(".jpg", ".jgw");
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly))
    {
        qDebug() << "Open file failed: " + path + " " << QString::number(__LINE__) + "@" + __FILENAME__;
        return;
    }
    QTextStream out(&file);
    out << content;
    file.close();
}

void GenerateShpFile(std::string& file_path,
                      std::vector<std::vector<double>>& polygon_x_list,
                      std::vector<std::vector<double>>& polygon_y_list,
                      std::vector<int>& kind_id_list)
{
    if (polygon_x_list.empty()) return;

    std::string prefix = file_path.substr(0, file_path.rfind('.'));
    SHPHandle hSHP = SHPCreate(prefix.c_str(), SHPT_POLYGON);
    DBFHandle hDBF = DBFCreate(prefix.c_str());
    if (!hSHP || !hDBF) return;

    int id_index   = DBFAddField(hDBF, "ID",   FTInteger, 10, 0);
    int kind_index = DBFAddField(hDBF, "Kind",  FTString,  32, 0);

    for (int i = 0; i < static_cast<int>(polygon_x_list.size()); ++i)
    {
        const auto& xPoints = polygon_x_list[i];
        const auto& yPoints = polygon_y_list[i];
        const int numPoints = static_cast<int>(xPoints.size());
        if (numPoints < 3) continue;

        int nParts = 1;
        int* panPartStart = new int[nParts];
        panPartStart[0] = 0;
        int* panPartTypes = new int[nParts];
        panPartTypes[0] = 1;
        double* adfX = new double[numPoints];
        double* adfY = new double[numPoints];
        for (int j = 0; j < numPoints; j++) { adfX[j] = xPoints[j]; adfY[j] = yPoints[j]; }

        SHPObject* psObject = SHPCreateObject(SHPT_POLYGON, 0, nParts, panPartStart, panPartTypes,
                                               numPoints, adfX, adfY, nullptr, nullptr);
        int iShapeIndex = SHPWriteObject(hSHP, -1, psObject);
        if (iShapeIndex >= 0)
        {
            DBFWriteIntegerAttribute(hDBF, iShapeIndex, id_index, i);
            DBFWriteStringAttribute(hDBF, iShapeIndex, kind_index, std::to_string(kind_id_list[i]).c_str());
        }
        SHPDestroyObject(psObject);
        delete[] panPartStart;
        delete[] panPartTypes;
        delete[] adfX;
        delete[] adfY;
    }
    SHPClose(hSHP);
    DBFClose(hDBF);

    FILE* cpgFile = fopen((prefix + ".cpg").c_str(), "w");
    if (cpgFile) { fprintf(cpgFile, "UTF-8"); fclose(cpgFile); }
}
