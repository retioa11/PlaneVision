/**
 * tile_db.h —— 瓦片库只读查询接口（声明）
 *
 * 依赖：lmdb，链接时加 -llmdb；经纬度→高斯坐标用 GISHelper.h 的 LonLatToGauss。
 */

#pragma once

#include <string>
#include <vector>
#include <unordered_map>
#include <climits>
#include "../1.Common/MacroEnumStruct.h"
#include "lmdb.h"

// ============================================================
// 数据结构
// ============================================================

struct Keypoint {
    float x, y;
};

struct TileData {
    int row, col;

    // 图像（jpg 编码字节流，可直接 imdecode）
    std::vector<uint8_t> image_bytes;

    // XFeat 特征
    int                  n_kpts;
    std::vector<Keypoint> keypoints;    // n_kpts 个
    std::vector<float>    descriptors; // n_kpts × 64
    std::vector<float>    scores;      // n_kpts 个

    // 瓦片地理元数据
    double geo_x;   // 瓦片左上角投影 X（米）
    double geo_y;   // 瓦片左上角投影 Y（米）
    double px_x;    // 米/像素，正值
    double px_y;    // 米/像素，负值
    int    width;
    int    height;
};

struct TileDBContext {
    MDB_env* env      = nullptr;
    MDB_dbi  dbi_images   = 0;
    MDB_dbi  dbi_features = 0;
    MDB_dbi  dbi_meta     = 0;

    // 全局元数据（Open 时读一次）
    double geo_origin_x = 0.0;
    double geo_origin_y = 0.0;
    double pixel_size_x = 1.0;
    double pixel_size_y = -1.0;
    int    tile_size    = 256;
    int    gauss_zone   = 0;
    // v2+ 字段：网格行列数（旧库读不到时为 -1）
    int    num_rows     = -1;
    int    num_cols     = -1;
    // v3+ 字段：WGS84 经纬度四至（旧库读不到时为 0.0）
    double lon_min      = 0.0;
    double lat_min      = 0.0;
    double lon_max      = 0.0;
    double lat_max      = 0.0;
    // v4+ 字段：WGS84 像素分辨率（度/像素，旧库读不到时为 0.0）
    double resolution_x = 0.0;
    double resolution_y = 0.0;

    // 滑动窗口缓存，最多 9 条
    std::unordered_map<uint64_t, TileData> cache;
    int last_center_row = INT_MIN;
    int last_center_col = INT_MIN;

    // 调试开关：true 时 QueryNeighborhood / ReadOneTile 会向 stderr 打印详细诊断信息
    bool debug_log = false;
};

// ============================================================
// 公开接口
// ============================================================

/** 打开 LMDB 库，读取全局元数据。程序启动时调一次。*/
VGA_API bool TileDB_Open(const std::string& lmdb_path,
                 TileDBContext& ctx,
                 std::string* error_msg = nullptr);

/**
 * 根据经纬度查询中心瓦片及其 8 邻域（共最多 9 个）。
 * 内置滑动窗口缓存，连续调用时自动复用未变化的瓦片。
 */
VGA_API bool TileDB_QueryNeighborhood(TileDBContext& ctx,
                              double lon, double lat,
                              std::vector<TileData>& results);

/** 关闭 LMDB，释放资源。程序退出时调一次。*/
VGA_API void TileDB_Close(TileDBContext& ctx);

/**
 * 【调试用】扫描 tile_meta 子库里所有的瓦片 key，打印：
 *   - 实际存在的 row / col 取值范围
 *   - 瓦片总数
 *   - 全局 meta（geo_origin_x/y, pixel_size_x/y, tile_size, gauss_zone）
 * 用于排查"查不到瓦片"时，先确认目标点的 row/col 是否落在库的覆盖范围内。
 * 可以在 TileDB_Open 成功之后随时调用。
 */
VGA_API void TileDB_DumpKeyRange(TileDBContext& ctx);