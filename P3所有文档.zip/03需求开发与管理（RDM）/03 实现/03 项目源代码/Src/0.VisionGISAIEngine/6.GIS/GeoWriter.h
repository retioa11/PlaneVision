// 地理数据写出：GeoTIFF（BGR / BGRA 图像 + 高斯坐标）与通用 GeoPackage 矢量写入。
//
// 约定：
//   - 所有 std::string 路径 / 字符串均为"本地编码"（见 EngineFunction.h 的"路径编码"）。
//     GDAL 在 Windows 下要求 UTF-8 文件名，本文件内部已经做了转换，调用方不用管。
//   - 本头文件不包含任何 GDAL 头文件，调用方无需 GDAL include 路径。
//   - 线程：单个 GpkgWriter 对象不是线程安全的；WriteGeoTiff 可以在不同线程并发调用。
#pragma once

#include <map>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include <opencv2/core.hpp>

#include "../1.Common/MacroEnumStruct.h"

// 确保 GDAL 驱动已注册（线程安全，可重复调用）。本文件的其他函数内部会自动调用。
VGA_API void EnsureGdalInit();

// ── 坐标系 ────────────────────────────────────────────────────────────────────
// WGS84 经纬度，或高斯-克吕格（CGCS2000 椭球，中央子午线 cm，东偏 = 带号*1e6 + 500000）。
struct GeoSrs
{
    bool   gauss   = false;   // false = WGS84；true = 高斯-克吕格
    double cm      = 0.0;     // 中央子午线（度），仅 gauss 时有效
    int    zoneDeg = 3;       // 带宽（3 或 6），仅 gauss 时有效

    static GeoSrs Wgs84() { return GeoSrs(); }
    static GeoSrs Gauss(double cm, int zoneDeg = 3)
    {
        GeoSrs s;
        s.gauss = true; s.cm = cm; s.zoneDeg = zoneDeg;
        return s;
    }
};

// ── GeoTIFF ───────────────────────────────────────────────────────────────────
// img 为 8 位 BGR（3 通道）或 BGRA（4 通道）；originE / originN 为图像左上角的高斯坐标（米），
// gsd 为米/像素（正值，北向上）；cm / zoneDeg 指定高斯坐标系。
//   3 通道：JPEG 压缩（质量 jpegQuality，YCbCr）
//   4 通道：LZW 压缩，第 4 波段为 Alpha
// 失败返回 false 并向 stdout 打印原因。
VGA_API bool WriteGeoTiff(const std::string& path, const cv::Mat& img,
                          double originE, double originN, double gsd, double cm,
                          int jpegQuality = 90, int zoneDeg = 3);

// 带选项的写出：可选无损压缩，并可写入自定义元数据（GDAL 默认元数据域，键值均为字符串）。
//   lossless = false：与上面的重载完全一致（3 通道 JPEG / 4 通道 LZW）
//   lossless = true ：无论 3 / 4 通道都用 DEFLATE（PREDICTOR=2），不做有损压缩；jpegQuality 被忽略
//   metadata：值是本地编码字符串（内部转 UTF-8 存入）；键须是 ASCII 且不含 '=' 和空白
struct GeoTiffOptions
{
    int  jpegQuality = 90;
    int  zoneDeg     = 3;
    bool lossless    = false;
    std::vector<std::pair<std::string, std::string>> metadata;
};

VGA_API bool WriteGeoTiff(const std::string& path, const cv::Mat& img,
                          double originE, double originN, double gsd, double cm,
                          const GeoTiffOptions& opt);

// ── 读 GeoTIFF ────────────────────────────────────────────────────────────────
// 只支持本模块写出的形态：8 位 3 / 4 通道、北向上无旋转、正方形像素、高斯-克吕格（横轴墨卡托）投影。
// 不满足时返回 false 并向 stdout 打印原因（文件打不开 / 波段数不对 / 像素非正方形或带旋转 / 非高斯投影）。
struct GeoTiffInfo
{
    double originE = 0, originN = 0;   // 左上角高斯坐标（米，东偏含带号）
    double gsd     = 0;                // 米/像素（正值）
    double cm      = 0;                // 中央子午线（度）
    int    zoneDeg = 3;                // 带宽（由中央子午线与东偏推出）
    int    width = 0, height = 0;
    std::map<std::string, std::string> metadata;   // 默认元数据域；值转成本地编码
};

// bgr 输出为 8 位 3 通道 BGR（源是 4 通道时为 BGRA，第 4 通道为 Alpha）。
VGA_API bool ReadGeoTiff(const std::string& path, cv::Mat& bgr, GeoTiffInfo& info);

// ── GeoPackage（矢量）─────────────────────────────────────────────────────────
// 通用的"多图层、逐要素追加、可分批提交"的写入器。用法：
//   GpkgWriter w;  w.Open(path);
//   int pts = w.AddLayer("frames", GpkgGeom::Point, GeoSrs::Wgs84(),
//                        {{"name", GpkgFieldType::String}, {"alt", GpkgFieldType::Real}});
//   w.Begin();  w.AddPoint(pts, lon, lat, {std::string("a.jpg"), 12.3});  w.Commit();
//   w.Close();     // 或析构时自动关闭
// 每次 Begin/Commit 之间是一个事务，中途崩溃不会损坏已提交的数据。
enum class GpkgGeom      { Point, Polygon };
enum class GpkgFieldType { Int, Real, String };

struct GpkgField
{
    std::string   name;
    GpkgFieldType type;
};

// 属性值：类型须与图层字段类型一一对应（Int→int，Real→double，String→std::string）
using GpkgValue = std::variant<int, double, std::string>;

class VGA_API GpkgWriter
{
public:
    GpkgWriter();
    ~GpkgWriter();
    GpkgWriter(const GpkgWriter&)            = delete;
    GpkgWriter& operator=(const GpkgWriter&) = delete;

    // 创建 gpkg 文件（已存在的同名文件会被覆盖）。失败返回 false。
    bool Open(const std::string& path);

    // 添加图层，返回图层编号（≥0）；失败返回 -1。
    int AddLayer(const std::string& name, GpkgGeom geom, const GeoSrs& srs,
                 const std::vector<GpkgField>& fields);

    // 事务。Begin 失败（驱动不支持等）时仍可继续写，只是没有事务保护。
    bool Begin();
    bool Commit();
    void Rollback();

    // 追加要素。attrs 的个数与类型须与图层字段一致，否则返回 false。
    bool AddPoint(int layer, double x, double y, const std::vector<GpkgValue>& attrs);
    // ring 为外环顶点（无需首尾重合，内部自动闭合）。
    bool AddPolygon(int layer, const std::vector<cv::Point2d>& ring, const std::vector<GpkgValue>& attrs);

    bool IsOpen() const;
    void Close();   // 幂等

private:
    struct Impl;
    Impl* m_impl;
};