﻿#include "T1Reference.h"

#include <algorithm>
#include <cmath>
#include <vector>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include "GISHelper.h"   // GaussToLonLat
#include "TileDB.h"

// 做法与原 Registrar::Impl::CropT1 完全一致（只是把 info.originE/N、info.gsd、n3.size() 拆成参数，
// kGaussZoneDeg 改成参数 zoneDeg），Register 的输出不变。
bool CropT1(TileDBContext& db, double originE, double originN, double gsd, cv::Size size,
            int zoneDeg, cv::Mat& ref, double& cover, std::string& why)
{
    cover = 0;
    if (!(gsd > 0) || size.width <= 0 || size.height <= 0) { why = "BadArgument"; return false; }

    const double ec = originE + 0.5 * size.width  * gsd;
    const double nc = originN - 0.5 * size.height * gsd;
    double lon = 0, lat = 0;
    GaussToLonLat(ec, nc, zoneDeg, lon, lat);   // 带号取自 E 的百万位；TileDB 内部再按 T1 的带号投回高斯

    std::vector<TileData> tiles;
    if (!TileDB_QueryNeighborhood(db, lon, lat, tiles) || tiles.empty()) { why = "T1NoTile"; return false; }

    const double pxx = db.pixel_size_x, pyy = std::fabs(db.pixel_size_y);
    if (!(pxx > 0) || !(pyy > 0)) { why = "T1NoTile"; return false; }

    double minX = tiles[0].geo_x, maxY = tiles[0].geo_y;
    for (const TileData& t : tiles) { minX = std::min(minX, t.geo_x); maxY = std::max(maxY, t.geo_y); }

    struct Placed { cv::Mat img; int ox, oy; };
    std::vector<Placed> placed;
    int cw = 0, ch = 0;
    for (const TileData& t : tiles) {
        if (t.image_bytes.empty()) continue;
        cv::Mat img = cv::imdecode(t.image_bytes, cv::IMREAD_COLOR);
        if (img.empty()) continue;
        const int ox = static_cast<int>(std::lround((t.geo_x - minX) / pxx));
        const int oy = static_cast<int>(std::lround((maxY - t.geo_y) / pyy));
        cw = std::max(cw, ox + img.cols);
        ch = std::max(ch, oy + img.rows);
        placed.push_back({img, ox, oy});
    }
    if (placed.empty() || cw <= 0 || ch <= 0) { why = "T1NoTile"; return false; }

    cv::Mat canvas = cv::Mat::zeros(ch, cw, CV_8UC3);
    cv::Mat mask   = cv::Mat::zeros(ch, cw, CV_8UC1);
    for (const Placed& p : placed) {
        p.img.copyTo(canvas(cv::Rect(p.ox, p.oy, p.img.cols, p.img.rows)));
        mask(cv::Rect(p.ox, p.oy, p.img.cols, p.img.rows)).setTo(255);
    }

    // 目标像素 (x,y) 的中心地面位置 = origin + (x+0.5)·gsd；源画布索引 u = (地面 - 画布原点)/像素大小 - 0.5（OpenCV 像素中心约定）
    const double a  = gsd / pxx, d = gsd / pyy;
    const double bx = (originE - minX + 0.5 * gsd) / pxx - 0.5;
    const double by = (maxY - originN + 0.5 * gsd) / pyy - 0.5;
    const cv::Matx23d M(a, 0, bx, 0, d, by);   // dst → src

    if (std::max(a, d) > 1.5)   // T1 比目标网格更细：先低通，避免降采样混叠
        cv::GaussianBlur(canvas, canvas, cv::Size(0, 0), 0.5 * std::max(a, d));

    cv::warpAffine(canvas, ref, M, size, cv::INTER_LINEAR | cv::WARP_INVERSE_MAP, cv::BORDER_CONSTANT, cv::Scalar());
    cv::Mat vmask;
    cv::warpAffine(mask, vmask, M, size, cv::INTER_NEAREST | cv::WARP_INVERSE_MAP, cv::BORDER_CONSTANT, cv::Scalar());
    cover = static_cast<double>(cv::countNonZero(vmask)) / (static_cast<double>(size.width) * size.height);
    return !ref.empty();
}
