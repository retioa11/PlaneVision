/**
 * tile_db.cpp —— 瓦片库只读查询实现（带调试打印版）
 *
 * LMDB key/value 格式（对应 Python tile_lmdb.py v3）：
 *   瓦片 key  = pack("<ii", row, col)                 8字节 little-endian int32×2
 *   全局 meta  key = b"__global__"，存在 tile_meta 子库
 *   特征 blob = [n int32][kpts n*2 f32][desc n*64 f32][scores n f32]
 *   瓦片 meta  = [geo_x geo_y px_x px_y 4×double][width height row col 4×int32]
 *   全局 meta v1(40B) = [4×double geo_origin/pixel_size][2×int32 tile_size/zone]
 *   全局 meta v2(48B) = v1 + [2×int32 num_rows/num_cols]
 *   全局 meta v3(80B) = v2 + [4×double lon_min/lat_min/lon_max/lat_max]
 *   全局 meta v4(96B) = v3 + [2×double resolution_x/resolution_y]
 */

#include "TileDB.h"

#include <cmath>
#include <cstdio>
#include <algorithm>

#include "GISHelper.h"

// ============================================================
// 内部辅助
// ============================================================

static void PackTileKey(int row, int col, uint8_t key_buf[8])
{
    int32_t r = static_cast<int32_t>(row);
    int32_t c = static_cast<int32_t>(col);
    memcpy(key_buf,     &r, 4);
    memcpy(key_buf + 4, &c, 4);
}

static uint64_t MakeCacheKey(int row, int col)
{
    return (static_cast<uint64_t>(static_cast<uint32_t>(row)) << 32)
         |  static_cast<uint32_t>(col);
}

static bool ReadOneTile(MDB_txn* txn,
                        MDB_dbi dbi_images,
                        MDB_dbi dbi_features,
                        MDB_dbi dbi_meta,
                        int row, int col,
                        TileData& out,
                        bool debug_log)
{
    uint8_t key_buf[8];
    PackTileKey(row, col, key_buf);
    MDB_val mdb_key { 8, key_buf };
    MDB_val mdb_val {};

    int rc;

    // 图像
    rc = mdb_get(txn, dbi_images, &mdb_key, &mdb_val);
    if (rc != 0) {
        if (debug_log) {
            fprintf(stderr, "[tile_db] ReadOneTile(r=%d,c=%d) miss in tile_images: rc=%d (%s)\n",
                    row, col, rc, mdb_strerror(rc));
        }
        return false;
    }
    out.image_bytes.assign(
        static_cast<uint8_t*>(mdb_val.mv_data),
        static_cast<uint8_t*>(mdb_val.mv_data) + mdb_val.mv_size);

    // 特征：[n int32][kpts n*2 f32][desc n*64 f32][scores n f32]
    rc = mdb_get(txn, dbi_features, &mdb_key, &mdb_val);
    if (rc != 0) {
        if (debug_log) {
            fprintf(stderr, "[tile_db] ReadOneTile(r=%d,c=%d) miss in tile_features: rc=%d (%s) "
                    "[注意：tile_images 命中了，但 tile_features 没有，三个子库的 key 集合不一致]\n",
                    row, col, rc, mdb_strerror(rc));
        }
        return false;
    }
    {
        const uint8_t* p = static_cast<uint8_t*>(mdb_val.mv_data);
        int32_t n = 0;
        memcpy(&n, p, 4);  p += 4;

        // 简单校验一下 blob 长度，避免 n 异常（脏数据/格式不对）时直接读飞内存
        size_t expect = 4 + (size_t)n * 2 * sizeof(float)
                           + (size_t)n * 64 * sizeof(float)
                           + (size_t)n * sizeof(float);
        if (n < 0 || expect != mdb_val.mv_size) {
            if (debug_log) {
                fprintf(stderr, "[tile_db] ReadOneTile(r=%d,c=%d) features blob 长度不匹配: "
                        "n=%d expect_size=%zu actual_size=%zu\n",
                        row, col, n, expect, (size_t)mdb_val.mv_size);
            }
            return false;
        }

        out.n_kpts = n;
        out.keypoints.resize(n);
        memcpy(out.keypoints.data(), p, n * 2 * sizeof(float));
        p += n * 2 * sizeof(float);

        out.descriptors.resize(n * 64);
        memcpy(out.descriptors.data(), p, n * 64 * sizeof(float));
        p += n * 64 * sizeof(float);

        out.scores.resize(n);
        memcpy(out.scores.data(), p, n * sizeof(float));
    }

    // 瓦片 meta：[4×double][4×int32]
    rc = mdb_get(txn, dbi_meta, &mdb_key, &mdb_val);
    if (rc != 0) {
        if (debug_log) {
            fprintf(stderr, "[tile_db] ReadOneTile(r=%d,c=%d) miss in tile_meta: rc=%d (%s)\n",
                    row, col, rc, mdb_strerror(rc));
        }
        return false;
    }
    {
        const uint8_t* p = static_cast<uint8_t*>(mdb_val.mv_data);
        double d[4];
        memcpy(d, p, 4 * sizeof(double));  p += 4 * sizeof(double);
        out.geo_x = d[0];
        out.geo_y = d[1];
        out.px_x  = d[2];
        out.px_y  = d[3];
        int32_t iv[4];
        memcpy(iv, p, 4 * sizeof(int32_t));
        out.width  = iv[0];
        out.height = iv[1];
    }

    out.row = row;
    out.col = col;

    if (debug_log) {
        fprintf(stderr, "[tile_db] ReadOneTile(r=%d,c=%d) OK: kpts=%d img=%zuB geo=(%.3f,%.3f) px=(%.6f,%.6f)\n",
                row, col, out.n_kpts, out.image_bytes.size(), out.geo_x, out.geo_y, out.px_x, out.px_y);
    }
    return true;
}

// ============================================================
// 公开接口实现
// ============================================================

bool TileDB_Open(const std::string& lmdb_path,
                 TileDBContext& ctx,
                 std::string* error_msg)
{
    auto fail = [&](const std::string& msg) -> bool {
        if (error_msg) *error_msg = msg;
        if (ctx.debug_log) fprintf(stderr, "[tile_db] Open failed: %s\n", msg.c_str());
        return false;
    };

    int rc = mdb_env_create(&ctx.env);
    if (rc) return fail("mdb_env_create failed: " + std::to_string(rc) + " (" + mdb_strerror(rc) + ")");

    mdb_env_set_maxdbs(ctx.env, 3);
    mdb_env_set_mapsize(ctx.env, (size_t)32 * 1024 * 1024 * 1024);

    rc = mdb_env_open(ctx.env, lmdb_path.c_str(), MDB_RDONLY | MDB_NOLOCK, 0664);
    if (rc) {
        std::string msg = "mdb_env_open failed (" + lmdb_path + "): " + std::to_string(rc) + " (" + mdb_strerror(rc) + ")";
        mdb_env_close(ctx.env);
        ctx.env = nullptr;
        return fail(msg);
    }

    MDB_txn* txn = nullptr;
    rc = mdb_txn_begin(ctx.env, nullptr, MDB_RDONLY, &txn);
    if (rc) {
        std::string msg = "mdb_txn_begin failed: " + std::to_string(rc) + " (" + mdb_strerror(rc) + ")";
        mdb_env_close(ctx.env);
        ctx.env = nullptr;
        return fail(msg);
    }

    int rc_img  = mdb_dbi_open(txn, "tile_images",   0, &ctx.dbi_images);
    int rc_feat = mdb_dbi_open(txn, "tile_features", 0, &ctx.dbi_features);
    int rc_meta = mdb_dbi_open(txn, "tile_meta",     0, &ctx.dbi_meta);
    if (rc_img || rc_feat || rc_meta) {
        std::string msg = "mdb_dbi_open failed: tile_images=" + std::to_string(rc_img)
                         + " tile_features=" + std::to_string(rc_feat)
                         + " tile_meta=" + std::to_string(rc_meta)
                         + " (子库名是否匹配？大小写、下划线是否一致？)";
        mdb_txn_abort(txn);
        mdb_env_close(ctx.env);
        ctx.env = nullptr;
        return fail(msg);
    }

    // 读全局 meta
    static const char GLOBAL_KEY[] = "__global__";
    MDB_val mdb_key { strlen(GLOBAL_KEY), const_cast<char*>(GLOBAL_KEY) };
    MDB_val mdb_val {};
    rc = mdb_get(txn, ctx.dbi_meta, &mdb_key, &mdb_val);
    if (rc != 0) {
        std::string msg = "global meta(__global__) not found in tile_meta: rc=" + std::to_string(rc) + " (" + mdb_strerror(rc) + ")";
        mdb_txn_abort(txn);
        mdb_env_close(ctx.env);
        ctx.env = nullptr;
        return fail(msg);
    }

    // 全局 meta 格式（向后兼容四个版本）：
    //   v1  40B：4×double(geo_origin_x/y, pixel_size_x/y) + 2×int32(tile_size, gauss_zone)
    //   v2  48B：v1 + 2×int32(num_rows, num_cols)
    //   v3  80B：v2 + 4×double(lon_min, lat_min, lon_max, lat_max)
    //   v4  96B：v3 + 2×double(resolution_x, resolution_y)
    static const size_t V1_SIZE = 4 * sizeof(double) + 2 * sizeof(int32_t);  // 40B
    static const size_t V2_SIZE = 4 * sizeof(double) + 4 * sizeof(int32_t);  // 48B
    static const size_t V3_SIZE = 8 * sizeof(double) + 4 * sizeof(int32_t);  // 80B
    static const size_t V4_SIZE = 10 * sizeof(double) + 4 * sizeof(int32_t); // 96B

    if (mdb_val.mv_size < V1_SIZE) {
        std::string msg = "global meta 长度不足: min_expect=" + std::to_string(V1_SIZE)
                         + " actual=" + std::to_string(mdb_val.mv_size);
        mdb_txn_abort(txn);
        mdb_env_close(ctx.env);
        ctx.env = nullptr;
        return fail(msg);
    }

    const uint8_t* p = static_cast<uint8_t*>(mdb_val.mv_data);

    // 所有版本均有：4×double
    double d4[4];
    memcpy(d4, p, 4 * sizeof(double));  p += 4 * sizeof(double);
    ctx.geo_origin_x = d4[0];
    ctx.geo_origin_y = d4[1];
    ctx.pixel_size_x = d4[2];
    ctx.pixel_size_y = d4[3];

    // 所有版本均有：2×int32
    int32_t iv4[4] = {0, 0, -1, -1};
    memcpy(iv4, p, 2 * sizeof(int32_t));  p += 2 * sizeof(int32_t);
    ctx.tile_size  = iv4[0];
    ctx.gauss_zone = iv4[1];

    // v2+：再读 2×int32(num_rows, num_cols)
    if (mdb_val.mv_size >= V2_SIZE) {
        memcpy(&iv4[2], p, 2 * sizeof(int32_t));  p += 2 * sizeof(int32_t);
        ctx.num_rows = iv4[2];
        ctx.num_cols = iv4[3];
    }

    // v3+：再读 4×double(lon_min, lat_min, lon_max, lat_max)
    if (mdb_val.mv_size >= V3_SIZE) {
        double bbox[4];
        memcpy(bbox, p, 4 * sizeof(double));  p += 4 * sizeof(double);
        ctx.lon_min = bbox[0];
        ctx.lat_min = bbox[1];
        ctx.lon_max = bbox[2];
        ctx.lat_max = bbox[3];
    }

    // v4+：再读 2×double(resolution_x, resolution_y)
    if (mdb_val.mv_size >= V4_SIZE) {
        double res[2];
        memcpy(res, p, 2 * sizeof(double));
        ctx.resolution_x = res[0];
        ctx.resolution_y = res[1];
    }

    // 重要：这里必须 commit，不能 abort！
    // mdb_dbi_open 打开的子库句柄(dbi)只有在其所在事务成功 commit 后，
    // 才会固化到 env 里供其他事务复用；如果用 abort 收尾，句柄会被
    // LMDB 自动关闭，后续所有 mdb_get 都会返回 EINVAL(22)，
    // 表现就是"怎么查都是 0 个瓦片"——而且跟坐标、key 格式完全无关。
    rc = mdb_txn_commit(txn);
    if (rc != 0) {
        std::string msg = "mdb_txn_commit failed: " + std::to_string(rc) + " (" + mdb_strerror(rc) + ")";
        mdb_env_close(ctx.env);
        ctx.env = nullptr;
        return fail(msg);
    }

    // 无条件打印关键元数据，便于启动时确认库是否正确加载
    printf("[tile_db] Open OK: tile_size=%d gauss_zone=%d\n",
           ctx.tile_size, ctx.gauss_zone);
    if (ctx.num_rows >= 0 && ctx.num_cols >= 0)
        printf("[tile_db] Grid %d cols x %d rows (total %d)\n",
               ctx.num_rows, ctx.num_cols, ctx.num_rows * ctx.num_cols);
    else
        printf("[tile_db] Row/col count not stored (legacy DB)\n");
    if (ctx.lon_min != 0.0 || ctx.lat_min != 0.0)
        printf("[tile_db] Extent [%.6f~%.6f E, %.6f~%.6f N]\n",
               ctx.lon_min, ctx.lon_max, ctx.lat_min, ctx.lat_max);
    else
        printf("[tile_db] Lon/lat extent not stored (legacy DB)\n");
    if (ctx.resolution_x != 0.0 || ctx.resolution_y != 0.0)
        printf("[tile_db] WGS84 resolution %.10f deg/px (lon) %.10f deg/px (lat)\n",
               ctx.resolution_x, ctx.resolution_y);
    else
        printf("[tile_db] WGS84 resolution not stored (legacy DB)\n");

    if (ctx.debug_log) {
        fprintf(stderr, "[tile_db] Open OK: geo_origin=(%.3f, %.3f) pixel_size=(%.8f, %.8f) "
                "tile_size=%d gauss_zone=%d num_rows=%d num_cols=%d "
                "lon=[%.6f, %.6f] lat=[%.6f, %.6f] "
                "resolution=(%.10f, %.10f)\n",
                ctx.geo_origin_x, ctx.geo_origin_y,
                ctx.pixel_size_x, ctx.pixel_size_y,
                ctx.tile_size, ctx.gauss_zone,
                ctx.num_rows, ctx.num_cols,
                ctx.lon_min, ctx.lon_max, ctx.lat_min, ctx.lat_max,
                ctx.resolution_x, ctx.resolution_y);
    }
    return true;
}

bool TileDB_QueryNeighborhood(TileDBContext& ctx,
                              double lon, double lat,
                              std::vector<TileData>& results)
{
    // 1. 坐标转换
    // 库里记录了建库时的带号（gauss_zone，3° 带）时，用它对应的中央子午线，
    // 这样查询点靠近分带边界时也与建库坐标一致；旧库没有带号(0)时按经度就近取带。
    double gauss_x, gauss_y;
    if (ctx.gauss_zone > 0)
        LonLatToGauss(lon, lat, ctx.gauss_zone * 3.0, 3, gauss_x, gauss_y);
    else
        LonLatToGauss(lon, lat, 3, gauss_x, gauss_y);

    // pixel_size_y 为负值，两者相除后 floor 结果为正整数，方向正确
    double tile_w = ctx.tile_size * ctx.pixel_size_x;
    double tile_h = ctx.tile_size * ctx.pixel_size_y;
    int center_col = static_cast<int>(floor((gauss_x - ctx.geo_origin_x) / tile_w));
    int center_row = static_cast<int>(floor((gauss_y - ctx.geo_origin_y) / tile_h));

    if (ctx.debug_log) {
        fprintf(stderr, "[tile_db] Query lon=%.9f lat=%.9f -> gauss=(%.3f, %.3f) "
                "tile_w=%.6f tile_h=%.6f -> center=(row=%d, col=%d) "
                "last_center=(row=%d, col=%d)\n",
                lon, lat, gauss_x, gauss_y, tile_w, tile_h,
                center_row, center_col, ctx.last_center_row, ctx.last_center_col);
    }

    // 2. 全命中短路
    if (center_row == ctx.last_center_row && center_col == ctx.last_center_col) {
        results.clear();
        for (int dr = -1; dr <= 1; ++dr)
            for (int dc = -1; dc <= 1; ++dc) {
                auto it = ctx.cache.find(MakeCacheKey(center_row + dr, center_col + dc));
                if (it != ctx.cache.end())
                    results.push_back(it->second);
            }
        if (ctx.debug_log) {
            fprintf(stderr, "[tile_db] 中心未变，命中缓存 %zu/9\n", results.size());
        }
        return !results.empty();
    }

    // 3. 淘汰不在新 3×3 内的缓存条目
    if (ctx.last_center_row != INT_MIN) {
        for (int dr = -1; dr <= 1; ++dr)
            for (int dc = -1; dc <= 1; ++dc) {
                int r = ctx.last_center_row + dr;
                int c = ctx.last_center_col + dc;
                if (abs(r - center_row) > 1 || abs(c - center_col) > 1)
                    ctx.cache.erase(MakeCacheKey(r, c));
            }
    }

    // 4. 查 LMDB：只补新增的格子
    MDB_txn* txn = nullptr;
    int rc = mdb_txn_begin(ctx.env, nullptr, MDB_RDONLY, &txn);
    if (rc != 0) {
        if (ctx.debug_log) {
            fprintf(stderr, "[tile_db] mdb_txn_begin failed: rc=%d (%s)\n", rc, mdb_strerror(rc));
        }
        return false;
    }

    int newly_read_ok = 0, newly_read_fail = 0, skipped_cached = 0;

    for (int dr = -1; dr <= 1; ++dr) {
        for (int dc = -1; dc <= 1; ++dc) {
            int r = center_row + dr;
            int c = center_col + dc;
            // 在旧 3×3 内且缓存存在 → 跳过
            if (ctx.last_center_row != INT_MIN
                && abs(r - ctx.last_center_row) <= 1
                && abs(c - ctx.last_center_col) <= 1) {
                ++skipped_cached;
                continue;
            }

            TileData td;
            if (ReadOneTile(txn, ctx.dbi_images, ctx.dbi_features, ctx.dbi_meta, r, c, td, ctx.debug_log)) {
                ctx.cache[MakeCacheKey(r, c)] = std::move(td);
                ++newly_read_ok;
            } else {
                ++newly_read_fail;
            }
        }
    }

    mdb_txn_abort(txn);

    // 5. 更新中心，组装结果
    ctx.last_center_row = center_row;
    ctx.last_center_col = center_col;

    results.clear();
    for (int dr = -1; dr <= 1; ++dr)
        for (int dc = -1; dc <= 1; ++dc) {
            auto it = ctx.cache.find(MakeCacheKey(center_row + dr, center_col + dc));
            if (it != ctx.cache.end())
                results.push_back(it->second);
        }

    if (ctx.debug_log) {
        fprintf(stderr, "[tile_db] 本次查询：新读成功=%d 新读失败=%d 跳过(已缓存)=%d -> 最终结果=%zu/9\n",
                newly_read_ok, newly_read_fail, skipped_cached, results.size());
        if (results.empty()) {
            fprintf(stderr, "[tile_db] *** 9 个格子全部未命中，建议调用 TileDB_DumpKeyRange(ctx) "
                    "确认 (row=%d, col=%d) 是否在库覆盖范围内 ***\n", center_row, center_col);
        }
    }

    return !results.empty();
}

void TileDB_Close(TileDBContext& ctx)
{
    if (ctx.env) {
        mdb_env_close(ctx.env);
        ctx.env = nullptr;
    }
    ctx.cache.clear();
    ctx.last_center_row = INT_MIN;
    ctx.last_center_col = INT_MIN;
}

// ============================================================
// 调试工具
// ============================================================

void TileDB_DumpKeyRange(TileDBContext& ctx)
{
    if (!ctx.env) {
        fprintf(stderr, "[tile_db] DumpKeyRange: env 未打开\n");
        return;
    }

    fprintf(stderr, "[tile_db] ==== 全局 meta ====\n");
    fprintf(stderr, "[tile_db] geo_origin_x=%.6f geo_origin_y=%.6f\n", ctx.geo_origin_x, ctx.geo_origin_y);
    fprintf(stderr, "[tile_db] pixel_size_x=%.8f pixel_size_y=%.8f\n", ctx.pixel_size_x, ctx.pixel_size_y);
    fprintf(stderr, "[tile_db] tile_size=%d gauss_zone=%d\n", ctx.tile_size, ctx.gauss_zone);

    MDB_txn* txn = nullptr;
    int rc = mdb_txn_begin(ctx.env, nullptr, MDB_RDONLY, &txn);
    if (rc != 0) {
        fprintf(stderr, "[tile_db] DumpKeyRange: mdb_txn_begin failed rc=%d (%s)\n", rc, mdb_strerror(rc));
        return;
    }

    auto scan_dbi = [&](MDB_dbi dbi, const char* dbi_name) {
        MDB_cursor* cur = nullptr;
        rc = mdb_cursor_open(txn, dbi, &cur);
        if (rc != 0) {
            fprintf(stderr, "[tile_db] DumpKeyRange: mdb_cursor_open(%s) failed rc=%d (%s)\n",
                    dbi_name, rc, mdb_strerror(rc));
            return;
        }

        int minr = INT_MAX, maxr = INT_MIN, minc = INT_MAX, maxc = INT_MIN;
        long long total = 0, skipped_non8 = 0;

        MDB_val k, v;
        rc = mdb_cursor_get(cur, &k, &v, MDB_FIRST);
        while (rc == 0) {
            if (k.mv_size == 8) {
                int32_t r, c;
                memcpy(&r, k.mv_data, 4);
                memcpy(&c, static_cast<uint8_t*>(k.mv_data) + 4, 4);
                minr = std::min(minr, (int)r);
                maxr = std::max(maxr, (int)r);
                minc = std::min(minc, (int)c);
                maxc = std::max(maxc, (int)c);
                ++total;
            } else {
                // 例如 "__global__" 这种非瓦片 key
                ++skipped_non8;
            }
            rc = mdb_cursor_get(cur, &k, &v, MDB_NEXT);
        }
        mdb_cursor_close(cur);

        if (total > 0) {
            fprintf(stderr, "[tile_db] [%s] 瓦片总数=%lld  row范围=[%d, %d]  col范围=[%d, %d]  (跳过非瓦片key=%lld)\n",
                    dbi_name, total, minr, maxr, minc, maxc, skipped_non8);
        } else {
            fprintf(stderr, "[tile_db] [%s] 没有任何 8 字节的瓦片 key！(跳过非瓦片key=%lld)\n",
                    dbi_name, skipped_non8);
        }
    };

    fprintf(stderr, "[tile_db] ==== 扫描各子库 key 范围 ====\n");
    scan_dbi(ctx.dbi_images,   "tile_images");
    scan_dbi(ctx.dbi_features, "tile_features");
    scan_dbi(ctx.dbi_meta,     "tile_meta");

    mdb_txn_abort(txn);
}