﻿// OrtProviders.h —— 给 Ort::SessionOptions 挂执行器（头文件内联，不进库）。
//   Jetson（PLATFORM_JETSON）：TensorRT（FP16，engine 缓存到 cacheDir）→ CUDA（TensorRT 接不住的算子落到它）→ 其余 CPU。
//   其他平台：什么都不挂，默认 CPU。
// 挂载失败（版本不匹配等）只降级、不抛异常。cacheDir 请与模型文件一一对应（如 <模型路径>_cache），换模型时不会读到旧 engine。
// 返回实际挂上的执行器描述，打日志用。
#pragma once

#include <filesystem>
#include <string>
#include <system_error>

#include <onnxruntime_cxx_api.h>

inline std::string AppendOrtProviders(Ort::SessionOptions& opts, const std::string& cacheDir)
{
#if defined(PLATFORM_JETSON)
    std::string used;
    try {
        OrtTensorRTProviderOptions trt{};
        trt.device_id = 0;
        trt.trt_fp16_enable = 1;
        std::error_code ec;
        std::filesystem::create_directories(cacheDir, ec);
        trt.trt_engine_cache_enable = ec ? 0 : 1;   // 建不出缓存目录就不缓存：每次启动重编 engine，慢但能跑
        trt.trt_engine_cache_path = cacheDir.c_str();
        opts.AppendExecutionProvider_TensorRT(trt);
        used = ec ? "TensorRT(FP16，缓存目录建不出来)" : "TensorRT(FP16)";
    } catch (const std::exception& e) {
        used = std::string("TensorRT 挂载失败（") + e.what() + "）";
    }
    try {
        OrtCUDAProviderOptions cuda{};
        cuda.device_id = 0;
        opts.AppendExecutionProvider_CUDA(cuda);
        used += " → CUDA";
    } catch (const std::exception& e) {
        used += std::string(" → CUDA 挂载失败（") + e.what() + "）";
    }
    return used + " → CPU";
#else
    (void) opts;
    (void) cacheDir;
    return "CPU";
#endif
}
