#include "OpenCVHelper.h"
#include <cstdio>

// ─────────────────────────────────────────────────────────────────────────────
// UYVY → RGB
// ─────────────────────────────────────────────────────────────────────────────

bool BigBufferUYVYToRGB(unsigned char* yuv_buffer, unsigned char* rgb_buffer, int cols, int rows)
{
    int numPixels = cols * rows / 2;
    for (int index = 0; index < numPixels; index++)
    {
        auto yuv_start_ptr = yuv_buffer + index * 4;
        auto rgb_start_ptr = rgb_buffer + index * 6;
        auto U  = *(yuv_start_ptr)     - 128;
        auto Y1 = *(yuv_start_ptr + 1);
        auto V  = *(yuv_start_ptr + 2) - 128;
        auto Y2 = *(yuv_start_ptr + 3);
        auto R1 = static_cast<int>(Y1 + 1.4075 * V);
        auto G1 = static_cast<int>(Y1 - 0.3455 * U - 0.7169 * V);
        auto B1 = static_cast<int>(Y1 + 1.779  * U);
        auto R2 = static_cast<int>(Y2 + 1.4075 * V);
        auto G2 = static_cast<int>(Y2 - 0.3455 * U - 0.7169 * V);
        auto B2 = static_cast<int>(Y2 + 1.779  * U);
        *(rgb_start_ptr + 0) = static_cast<unsigned char>((std::min)((std::max)(R1, 0), 255));
        *(rgb_start_ptr + 1) = static_cast<unsigned char>((std::min)((std::max)(G1, 0), 255));
        *(rgb_start_ptr + 2) = static_cast<unsigned char>((std::min)((std::max)(B1, 0), 255));
        *(rgb_start_ptr + 3) = static_cast<unsigned char>((std::min)((std::max)(R2, 0), 255));
        *(rgb_start_ptr + 4) = static_cast<unsigned char>((std::min)((std::max)(G2, 0), 255));
        *(rgb_start_ptr + 5) = static_cast<unsigned char>((std::min)((std::max)(B2, 0), 255));
    }
    return true;
}

// ─────────────────────────────────────────────────────────────────────────────
// ComputeHomographyFn
// ─────────────────────────────────────────────────────────────────────────────
cv::Mat ComputeHomographyFn(std::vector<cv::Point2f>& srcPts,
                             std::vector<cv::Point2f>& dstPts,
                             double                    ransacReprojThreshold,
                             cv::Mat&                  outMask)
{
    if (srcPts.size() < 4 || srcPts.size() != dstPts.size())
        return cv::Mat();
    return cv::findHomography(srcPts, dstPts, cv::RANSAC,
                              ransacReprojThreshold, outMask);
}

// ─────────────────────────────────────────────────────────────────────────────
// ValidateHomography
// ─────────────────────────────────────────────────────────────────────────────
bool ValidateHomography(const cv::Mat& H, const cv::Mat& mask,
                         const std::string& frameTag, std::string& outReason)
{
    outReason.clear();

    if (H.empty())
    {
        outReason = "Homography is empty [" + frameTag + "]";
        return false;
    }

    const int inliers = cv::countNonZero(mask);
    if (inliers < 4)
    {
        outReason = "Inlier count too low: " + std::to_string(inliers);
        return false;
    }

    const double det = cv::determinant(H);
    if (det < 0)
    {
        outReason = "Homography produces flip, det=" + std::to_string(det);
        return false;
    }
    if (det < 0.01 || det > 100.0)
    {
        outReason = "Homography scale anomaly, det=" + std::to_string(det)
                  + " (expected [0.01, 100.0])";
        return false;
    }

    const double skew = std::abs(H.at<double>(2, 0)) + std::abs(H.at<double>(2, 1));
    if (skew > 1.5)
    {
        printf("[ValidateHomography] Warning: large perspective skew=%.3f [%s]\n",
               skew, frameTag.c_str());
    }

    return true;
}

// ─────────────────────────────────────────────────────────────────────────────
// ExtractYawFromHomography
// ─────────────────────────────────────────────────────────────────────────────
double ExtractYawFromHomography(const cv::Mat& H)
{
    cv::Mat A = H(cv::Rect(0, 0, 2, 2));
    cv::Mat w, U, Vt;
    cv::SVD::compute(A, w, U, Vt);
    cv::Mat R = U * Vt;
    if (cv::determinant(R) < 0)
    {
        U.col(1) *= -1.0;
        R = U * Vt;
    }
    const double angleRad = std::atan2(R.at<double>(1, 0), R.at<double>(0, 0));
    double angleDeg = angleRad * 180.0 / CV_PI;
    while (angleDeg >= 180.0)  angleDeg -= 360.0;
    while (angleDeg < -180.0)  angleDeg += 360.0;
    return angleDeg;
}

// ─────────────────────────────────────────────────────────────────────────────
// WarpCenteredRotate
// ─────────────────────────────────────────────────────────────────────────────
cv::Mat WarpCenteredRotate(const cv::Mat& src, double angleDeg, double scale, cv::Size outSize,
                            const cv::Scalar& border, bool withAlpha)
{
    if (src.empty() || outSize.width <= 0 || outSize.height <= 0 || scale <= 0) return cv::Mat();

    // getRotationMatrix2D 正角度 = 逆时针，传 -angleDeg 让内容顺时针转 angleDeg；
    // 像素中心坐标用 (n-1)/2，再把原图中心平移到输出图中心
    const cv::Point2f srcC((src.cols - 1) * 0.5f, (src.rows - 1) * 0.5f);
    cv::Mat M = cv::getRotationMatrix2D(srcC, -angleDeg, scale);
    M.at<double>(0, 2) += (outSize.width  - 1) * 0.5 - srcC.x;
    M.at<double>(1, 2) += (outSize.height - 1) * 0.5 - srcC.y;

    cv::Mat dst;
    cv::warpAffine(src, dst, M, outSize, cv::INTER_LINEAR, cv::BORDER_CONSTANT, border);
    if (!withAlpha) return dst;

    cv::Mat alpha;
    cv::warpAffine(cv::Mat(src.size(), CV_8UC1, cv::Scalar(255)), alpha, M, outSize,
                   cv::INTER_LINEAR, cv::BORDER_CONSTANT, cv::Scalar(0));
    std::vector<cv::Mat> ch;
    cv::split(dst, ch);
    ch.push_back(alpha);
    cv::merge(ch, dst);
    return dst;
}
