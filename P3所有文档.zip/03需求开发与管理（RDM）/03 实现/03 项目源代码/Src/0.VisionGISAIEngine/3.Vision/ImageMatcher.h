#pragma once
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include <opencv2/opencv.hpp>
#include <onnxruntime_cxx_api.h>

#include "../1.Common/MacroEnumStruct.h"

struct SplgOrtFeatures
{
    cv::Size origSize0;                 // 图0 原始尺寸，用于还原坐标
    cv::Size origSize1;                 // 图1 原始尺寸
    int64_t  numKpts = 0;               // 每张图的关键点槽位数 N
    std::vector<int64_t> keypoints;     // [2, N, 2]，模型输入坐标系像素 (x, y)
    std::vector<int64_t> matches;       // [M, 3]，(batch_id, idx0, idx1)
    std::vector<float>   scores;        // [M]，匹配置信度

    bool Empty() const { return matches.empty(); }
};

class VGA_API SplgOrt
{
public:
    // 加载模型并创建 session。modelInputSize：模型固定输入边长（正方形）。
    void Init(const std::string& modelPath, int modelInputSize);

    // 预处理 + 模型推理。输入 BGR 图，返回模型原始输出。
    SplgOrtFeatures Extract(const cv::Mat& img0, const cv::Mat& img1);

    // 阈值过滤 + 还原到原图坐标。返回 (图0 点, 图1 点)，一一对应。
    std::pair<std::vector<cv::Point2f>, std::vector<cv::Point2f>>
        Match(const SplgOrtFeatures& feats) const;

private:
    std::unique_ptr<Ort::Env>     m_env;
    std::unique_ptr<Ort::Session> m_session;
    int m_modelInputSize = 640;
};