#pragma once

#include "../1.Common/MacroEnumStruct.h"
#include <opencv2/opencv.hpp>
using cv::Mat;

// ── 格式转换 ──────────────────────────────────────────────────────────────────

VGA_API bool BigBufferUYVYToRGB(unsigned char* yuv_buffer, unsigned char* rgb_buffer,
                                 int cols, int rows);

// ── 单应性 ────────────────────────────────────────────────────────────────────

// RANSAC 求单应性矩阵
// 返回 H（失败时为空矩阵）；mask 用于后续内点统计
VGA_API cv::Mat ComputeHomographyFn(std::vector<cv::Point2f>& srcPts,
                                     std::vector<cv::Point2f>& dstPts,
                                     double                    ransacReprojThreshold,
                                     cv::Mat&                  outMask);

// 单应性矩阵合法性校验
// 返回 false 时 outReason 填充失败原因
VGA_API bool ValidateHomography(const cv::Mat& H,
                                 const cv::Mat& mask,
                                 const std::string& frameTag,
                                 std::string& outReason);

// 从单应矩阵提取偏航角（度，[-180, 180)）
VGA_API double ExtractYawFromHomography(const cv::Mat& H);

// ── 图像变换 ──────────────────────────────────────────────────────────────────
// 绕原图中心旋转并缩放，原图中心落在输出图中心（一次 warpAffine）。
//   angleDeg : 旋转 -angleDeg（顺时针转 angleDeg），即把"机头/航向指向 angleDeg 的方向"转到画面上方；
//              航向自正北顺时针时，输出即"正北向上"。
//   scale    : 缩放倍数（1 = 保持原分辨率；统一到目标 GSD 时传 srcGSD / dstGSD）。
//   border   : 原图外区域的填充色。
//   withAlpha: true 时输出多一个 alpha 通道，原图外为 0，原图内为 255（如 3 通道输入 → BGRA）。
VGA_API cv::Mat WarpCenteredRotate(const cv::Mat& src, double angleDeg, double scale, cv::Size outSize,
                                    const cv::Scalar& border = cv::Scalar(), bool withAlpha = false);
