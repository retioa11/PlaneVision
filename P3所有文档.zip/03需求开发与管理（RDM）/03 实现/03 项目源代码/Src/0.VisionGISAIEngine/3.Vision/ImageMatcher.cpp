﻿#include "ImageMatcher.h"

#include <cstring>
#include <filesystem>
#include <iostream>

namespace
{
constexpr float kMatchThresh = 0.1f;

// BGR -> 灰度 -> resize 到 S×S -> 归一化 [0,1]，返回 S*S 的 float 数据；同时输出原图尺寸
std::vector<float> PreprocessBgrToGray(const cv::Mat& bgr, cv::Size& outOrigSize, int modelInputSize)
{
    outOrigSize = bgr.size();
    cv::Mat gray;
    cv::cvtColor(bgr, gray, cv::COLOR_BGR2GRAY);
    if (gray.size() != cv::Size(modelInputSize, modelInputSize)) {
        cv::resize(gray, gray, {modelInputSize, modelInputSize});
    }
    gray.convertTo(gray, CV_32F, 1.f / 255.f);
    std::vector<float> blob(static_cast<size_t>(modelInputSize) * modelInputSize);
    std::memcpy(blob.data(), gray.data, blob.size() * sizeof(float));
    return blob;
}

// 把 Ort 输出张量拷贝到 vector
template <typename T>
std::vector<T> CopyTensor(Ort::Value& v)
{
    const size_t n = v.GetTensorTypeAndShapeInfo().GetElementCount();
    const T* p = v.GetTensorData<T>();
    return std::vector<T>(p, p + n);
}
}  // namespace

// ─────────────────────────────── Init ───────────────────────────────
void SplgOrt::Init(const std::string& modelPath, int modelInputSize)
{
    m_modelInputSize = modelInputSize;
    m_env = std::make_unique<Ort::Env>(ORT_LOGGING_LEVEL_WARNING, "ImageMatcher_SPLG_Ort");

    Ort::SessionOptions opts;
    opts.SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_ALL);

    // ── 平台差异只在这里：Execution Provider 的选择 ──
#if defined(PLATFORM_JETSON)
    // TensorRT 优先，不支持的算子自动 fallback 到 CUDA。
    // engine 缓存目录要提前存在且可写，否则每次启动都重新编译 engine。
    OrtTensorRTProviderOptions trt_options{};
    trt_options.device_id               = 0;
    trt_options.trt_fp16_enable         = 1;
    trt_options.trt_engine_cache_enable = 1;
    const std::string cacheDir = modelPath + "_cache";
    {
        std::error_code ec;   // 缓存目录必须已存在且可写；建不出来只告警，之后每次启动都会重新编译 engine
        std::filesystem::create_directories(cacheDir, ec);
        if (ec) std::cerr << "[ImageMatcher_SPLG_Ort] 无法创建 TensorRT 缓存目录 " << cacheDir << ": " << ec.message() << std::endl;
    }
    trt_options.trt_engine_cache_path = cacheDir.c_str();
    opts.AppendExecutionProvider_TensorRT(trt_options);

    OrtCUDAProviderOptions cuda_options{};
    cuda_options.device_id = 0;
    opts.AppendExecutionProvider_CUDA(cuda_options);
#endif
    // PLATFORM_WINDOWS：不追加 Provider，默认 CPU。

#if defined(PLATFORM_WINDOWS)
    std::wstring wpath(modelPath.begin(), modelPath.end());
    m_session = std::make_unique<Ort::Session>(*m_env, wpath.c_str(), opts);
#else
    std::cerr << "[ImageMatcher_SPLG_Ort] loading model from: " << modelPath << std::endl;
    m_session = std::make_unique<Ort::Session>(*m_env, modelPath.c_str(), opts);
#endif
}

// ────────────────────────────── Extract ─────────────────────────────
SplgOrtFeatures SplgOrt::Extract(const cv::Mat& img0, const cv::Mat& img1)
{
    SplgOrtFeatures feats;

    if (img0.empty() || img1.empty())
        return feats;

    if (!m_session)
    {
        std::cerr << "[ImageMatcher_SPLG_Ort] 模型未初始化，请先调用 Init()" << std::endl;
        return feats;
    }

    // 预处理：两图各自转灰度+resize+归一化，按 batch 维拼成 [2,1,S,S]
    const size_t planeSize = static_cast<size_t>(m_modelInputSize) * m_modelInputSize;
    std::vector<float> blob0 = PreprocessBgrToGray(img0, feats.origSize0, m_modelInputSize);
    std::vector<float> blob1 = PreprocessBgrToGray(img1, feats.origSize1, m_modelInputSize);

    std::vector<float> images(2 * planeSize);
    std::memcpy(images.data(),             blob0.data(), planeSize * sizeof(float));
    std::memcpy(images.data() + planeSize, blob1.data(), planeSize * sizeof(float));

    // 推理
    auto mem = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);
    int64_t imgDims[4] = {2, 1, m_modelInputSize, m_modelInputSize};
    Ort::Value inputTensor = Ort::Value::CreateTensor<float>(mem, images.data(), images.size(), imgDims, 4);

    const char* inNames[]  = {"images"};
    const char* outNames[] = {"keypoints", "matches", "mscores"};
    auto outs = m_session->Run(Ort::RunOptions{nullptr}, inNames, &inputTensor, 1, outNames, 3);

    // 拷贝输出：keypoints int64[2,N,2]，matches int64[M,3]，mscores float[M]
    feats.numKpts   = outs[0].GetTensorTypeAndShapeInfo().GetShape()[1];
    feats.keypoints = CopyTensor<int64_t>(outs[0]);
    feats.matches   = CopyTensor<int64_t>(outs[1]);
    feats.scores    = CopyTensor<float>(outs[2]);
    return feats;
}

// ─────────────────────────────── Match ──────────────────────────────
std::pair<std::vector<cv::Point2f>, std::vector<cv::Point2f>>
SplgOrt::Match(const SplgOrtFeatures& feats) const
{
    std::vector<cv::Point2f> left_kpts, right_kpts;
    if (feats.Empty())
        return {left_kpts, right_kpts};

    const int64_t N = feats.numKpts;
    const int     M = static_cast<int>(feats.matches.size() / 3);

    // 模型输入坐标 -> 原图坐标 的缩放系数
    const float scaleX0 = static_cast<float>(feats.origSize0.width)  / m_modelInputSize;
    const float scaleY0 = static_cast<float>(feats.origSize0.height) / m_modelInputSize;
    const float scaleX1 = static_cast<float>(feats.origSize1.width)  / m_modelInputSize;
    const float scaleY1 = static_cast<float>(feats.origSize1.height) / m_modelInputSize;

    left_kpts.reserve(M);
    right_kpts.reserve(M);

    for (int idx = 0; idx < M; ++idx)
    {
        const int64_t batchId = feats.matches[idx * 3 + 0];
        const int64_t i       = feats.matches[idx * 3 + 1];
        const int64_t j       = feats.matches[idx * 3 + 2];

        if (batchId != 0) continue;                 // 只有一对图像，batch_id 恒为 0
        if (i < 0 || j < 0 || i >= N || j >= N) continue;   // 无效占位 / 越界保护
        if (feats.scores[idx] < kMatchThresh) continue;

        const float x0 = static_cast<float>(feats.keypoints[(0 * N + i) * 2 + 0]);
        const float y0 = static_cast<float>(feats.keypoints[(0 * N + i) * 2 + 1]);
        const float x1 = static_cast<float>(feats.keypoints[(1 * N + j) * 2 + 0]);
        const float y1 = static_cast<float>(feats.keypoints[(1 * N + j) * 2 + 1]);

        if (x0 < 0 || y0 < 0 || x1 < 0 || y1 < 0) continue;  // 过滤占位点

        left_kpts.emplace_back(x0 * scaleX0, y0 * scaleY0);
        right_kpts.emplace_back(x1 * scaleX1, y1 * scaleY1);
    }

    return {left_kpts, right_kpts};
}