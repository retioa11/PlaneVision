﻿#include "FileSender.h"

#include <cstdio>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <system_error>

#include <zmq.hpp>

namespace fs = std::filesystem;

struct FileSender::Impl
{
    zmq::context_t                ctx{1};      // 声明在 sock 之前：析构时先关 socket、再关 context
    std::unique_ptr<zmq::socket_t> sock;
    std::string                   root;
    int                           port    = 0;
    bool                          verbose = false;
    mutable std::mutex            mtx;         // zmq socket 不是线程安全的；同时保护 root / verbose
};

FileSender::FileSender() : m_impl(new Impl) {}
FileSender::~FileSender() { Close(); }

bool FileSender::Init(int port, const std::string& rootDir, std::string* err, int sendHwm)
{
    Close();
    auto fail = [&](const std::string& msg) { if (err) *err = msg; return false; };

    if (port <= 0 || port > 65535) return fail("端口无效: " + std::to_string(port));
    if (rootDir.empty())           return fail("rootDir 为空");

    Impl& m = *m_impl;
    std::lock_guard<std::mutex> lk(m.mtx);
    const std::string endpoint = "tcp://*:" + std::to_string(port);
    try {
        auto s = std::make_unique<zmq::socket_t>(m.ctx, ZMQ_PUSH);
        s->set(zmq::sockopt::linger, 2000);   // 关闭时最多等 2 秒把队列发完，没有接收者也不会一直卡
        if (sendHwm > 0) s->set(zmq::sockopt::sndhwm, sendHwm);   // 必须在 bind 之前设置才对之后的连接生效
        s->bind(endpoint);
        m.sock = std::move(s);
    } catch (const zmq::error_t& e) {
        return fail("FileSender 绑定失败 " + endpoint + "：" + e.what() + "（errno " + std::to_string(e.num()) +
                    "）。端口可能被其他进程占用，或上次程序没有正常退出。");
    }
    m.root = rootDir;
    m.port = port;
    if (err) err->clear();
    std::printf("[FileSender] 已绑定 %s，根目录 %s\n", endpoint.c_str(), rootDir.c_str());
    return true;
}

void FileSender::Close()
{
    Impl& m = *m_impl;
    std::lock_guard<std::mutex> lk(m.mtx);
    m.sock.reset();   // 触发 linger
    m.port = 0;
}

bool FileSender::IsReady() const
{
    std::lock_guard<std::mutex> lk(m_impl->mtx);
    return m_impl->sock != nullptr;
}

void FileSender::SetVerbose(bool on)
{
    std::lock_guard<std::mutex> lk(m_impl->mtx);
    m_impl->verbose = on;
}

FileSender::Status FileSender::SendFile(const std::string& relPath, std::string* why)
{
    auto done = [&](Status st, const char* reason) {
        if (why) *why = (st == Status::Sent) ? std::string() : std::string(reason);
        return st;
    };

    Impl& m = *m_impl;
    std::lock_guard<std::mutex> lk(m.mtx);
    if (!m.sock) return done(Status::Failed, "NotReady");

    // 路径必须是 rootDir 之下的相对路径
    const fs::path rel(relPath);
    bool bad = relPath.empty() || rel.is_absolute() || rel.has_root_name() || rel.has_root_directory();
    for (const auto& part : rel) if (part == "..") { bad = true; break; }
    if (bad) return done(Status::Failed, "BadPath");

    const fs::path abs = fs::path(m.root) / rel;
    std::error_code ec;
    if (!fs::is_regular_file(abs, ec) || ec) return done(Status::Missing, "Missing");
    const std::uintmax_t size = fs::file_size(abs, ec);
    if (ec) return done(Status::Failed, "ReadFailed");

    try {
        zmq::message_t dataMsg(static_cast<size_t>(size));
        if (size > 0) {
            std::ifstream f(abs, std::ios::binary);
            if (!f.is_open()) return done(Status::Failed, "ReadFailed");
            f.read(dataMsg.data<char>(), static_cast<std::streamsize>(size));
            if (static_cast<std::uintmax_t>(f.gcount()) != size) return done(Status::Failed, "ReadFailed");
        }

        // 一条多段消息：路径 + 内容。第一段被接受后，后面的段不会再因队列满失败
        zmq::message_t pathMsg(relPath.data(), relPath.size());
        const auto r1 = m.sock->send(pathMsg, zmq::send_flags::sndmore | zmq::send_flags::dontwait);
        if (!r1) return done(Status::Failed, "NoReceiver");   // 没有接收者连上，或发送队列已满
        const auto r2 = m.sock->send(dataMsg, zmq::send_flags::dontwait);
        if (!r2) return done(Status::Failed, "SendPartial");
    } catch (const zmq::error_t& e) {
        if (why) *why = std::string("ZmqError:") + e.what();
        return Status::Failed;
    } catch (const std::exception& e) {   // 内存不足等
        if (why) *why = std::string("Exception:") + e.what();
        return Status::Failed;
    }

    if (m.verbose) std::printf("[FileSender] 已发送 %s (%llu 字节)\n", relPath.c_str(), static_cast<unsigned long long>(size));
    return done(Status::Sent, "");
}

FileSender::Result FileSender::SendFiles(const std::vector<std::string>& relPaths)
{
    Result r;
    for (const std::string& p : relPaths) {
        std::string why;
        switch (SendFile(p, &why)) {
        case Status::Sent:    ++r.sent; break;
        case Status::Missing: ++r.missing; break;
        case Status::Failed:
            ++r.failed;
            std::printf("[FileSender] 发送失败 %s: %s\n", p.c_str(), why.c_str());
            break;
        }
    }
    return r;
}
