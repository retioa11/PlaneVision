﻿#pragma once
// 原子写文件：先写 <path>.tmp，写完 flush 再 rename 成 <path>。
// 读的一方（本机其他进程、或 FileSender 发送时）要么看到旧文件 / 没有文件，要么看到完整的新文件，不会读到写了一半的内容。
// 同一目录内的 rename 在 Linux 和 Windows 上都会覆盖已存在的目标文件。
//
// 要用"完成标记"的场景（一包里有多个文件）：先写主体（如 JPG），最后写标记（如 TXT）；读的一方看到标记就表示整包已齐。
//
// 失败时返回 false，err（非空时）写原因；临时文件会被清掉。不会替调用方建父目录。
#include <cstddef>
#include <filesystem>
#include <string>
#include <vector>

#include "MacroEnumStruct.h"

VGA_API bool WriteFileAtomic(const std::filesystem::path& path, const void* data, std::size_t size, std::string* err = nullptr);

inline bool WriteFileAtomic(const std::filesystem::path& path, const std::string& bytes, std::string* err = nullptr)
{
    return WriteFileAtomic(path, bytes.data(), bytes.size(), err);
}

// cv::imencode 输出的就是这个类型
inline bool WriteFileAtomic(const std::filesystem::path& path, const std::vector<unsigned char>& bytes, std::string* err = nullptr)
{
    return WriteFileAtomic(path, bytes.data(), bytes.size(), err);
}
