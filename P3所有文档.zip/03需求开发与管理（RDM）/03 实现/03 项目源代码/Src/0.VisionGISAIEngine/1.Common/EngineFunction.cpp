﻿#include "EngineFunction.h"
#include <cmath>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <QtCore/QDebug>
#include <QtCore/QThread>

#include "json.hpp"
#include "TextTransferJetson.h"

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#else
#include <unistd.h>
#include <climits>
#endif

namespace fs = std::filesystem;

using std::istringstream;
using std::to_string;
std::vector<ChangeKind> m_change_kinds;

vector<string> SplitString(const string &str, char delimiter) {
    vector<string> tokens;
    string token;
    istringstream tokenStream(str);
    while (getline(tokenStream, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}

// 参考自: https://www.cnblogs.com/feipeng8848/p/17046957.html
string ReplaceAll(string &str, string oldStr, string newStr) {
    string::size_type pos = str.find(oldStr);
    while (pos != string::npos) {
        str.replace(pos, oldStr.size(), newStr);
        pos = str.find(oldStr);
    }
    return str;
}

std::string DoubleToString(double value, int precision)
{
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(precision) << value;
    return oss.str();
}

// 对整数的前缀补零，支持2-6位整数
string FillZeroAsPrefix(int number, int bit_count) {
    auto s = to_string(number);
    while ((int)s.length() < bit_count) s = "0" + s;
    return s;
}

bool ParseFramePos(const string& fileName, FramePos& out)
{
    static const struct { const char* key; double FramePos::* field; } kKeys[] = {
        {"RtkLon", &FramePos::lon}, {"GpsLon", &FramePos::lon}, {"Longitude", &FramePos::lon}, {"Lon", &FramePos::lon},
        {"RtkLat", &FramePos::lat}, {"GpsLat", &FramePos::lat}, {"Latitude",  &FramePos::lat}, {"Lat", &FramePos::lat},
        {"RelAlt", &FramePos::relAlt}, {"RelHeight", &FramePos::relAlt},
        {"Roll", &FramePos::roll}, {"Pitch", &FramePos::pitch},
        {"Yaw", &FramePos::yaw}, {"YawTruth", &FramePos::yaw}, {"YawDelta", &FramePos::yawDelta},
    };

    out = FramePos();
    const size_t slash = fileName.find_last_of("/\\");
    const string base = slash == string::npos ? fileName : fileName.substr(slash + 1);

    bool first = true;
    for (const string& token : SplitString(base, '_'))
    {
        if (first)
        {
            first = false;
            if (token.size() >= 6 && token.find_first_not_of("0123456789") == string::npos)
            {
                out.tsec = std::stoi(token.substr(0, 2)) * 3600 + std::stoi(token.substr(2, 2)) * 60 + std::stoi(token.substr(4, 2));
                continue;
            }
        }
        // 键与数值的分界：第一个数字/正负号/小数点。数值用 strtod 取前缀，末尾的 ".jpg" 之类会被自然忽略
        const size_t k = token.find_first_of("0123456789+-.");
        if (k == 0 || k == string::npos) continue;
        char* end = nullptr;
        const double value = std::strtod(token.c_str() + k, &end);
        if (end == token.c_str() + k) continue;
        const string key = token.substr(0, k);
        for (const auto& e : kKeys)
            if (key == e.key) { out.*(e.field) = value; break; }
    }
    return std::isfinite(out.lon) && std::isfinite(out.lat);
}

// ── 路径编码转换（本地编码 ↔ UTF-8）──────────────────────────────────────────
#ifdef _WIN32
namespace
{
std::string Convert(const std::string& in, UINT from, UINT to)
{
    if (in.empty()) return {};
    bool ascii = true;
    for (unsigned char c : in) if (c >= 0x80) { ascii = false; break; }
    if (ascii) return in;

    const int wn = MultiByteToWideChar(from, 0, in.data(), static_cast<int>(in.size()), nullptr, 0);
    if (wn <= 0) return in;
    std::wstring w(static_cast<size_t>(wn), L'\0');
    MultiByteToWideChar(from, 0, in.data(), static_cast<int>(in.size()), &w[0], wn);

    const int n = WideCharToMultiByte(to, 0, w.data(), wn, nullptr, 0, nullptr, nullptr);
    if (n <= 0) return in;
    std::string out(static_cast<size_t>(n), '\0');
    WideCharToMultiByte(to, 0, w.data(), wn, &out[0], n, nullptr, nullptr);
    return out;
}
}  // namespace

string Utf8ToLocal(const string& utf8)  { return Convert(utf8, CP_UTF8, CP_ACP); }
string LocalToUtf8(const string& local) { return Convert(local, CP_ACP, CP_UTF8); }
#else
string Utf8ToLocal(const string& utf8)  { return utf8; }
string LocalToUtf8(const string& local) { return local; }
#endif

fs::path GetExeDir()
{
    std::error_code ec;
    fs::path dir;
#ifdef _WIN32
    wchar_t buf[MAX_PATH * 4];
    const DWORD n = GetModuleFileNameW(nullptr, buf, static_cast<DWORD>(sizeof(buf) / sizeof(buf[0])));
    if (n > 0 && n < sizeof(buf) / sizeof(buf[0])) dir = fs::path(std::wstring(buf, n)).parent_path();
#else
    char buf[PATH_MAX];
    const ssize_t n = readlink("/proc/self/exe", buf, sizeof(buf) - 1);
    if (n > 0) dir = fs::path(std::string(buf, static_cast<size_t>(n))).parent_path();
#endif
    if (dir.empty()) dir = fs::current_path(ec);
    return dir / "";            // 末尾补分隔符
}

cv::Point MapCenterByHomography(cv::Mat& H, cv::Point center_point)
{
    if (H.empty()) return {0, 0};
    if (std::abs(H.at<double>(0, 0)) > 5 || std::abs(H.at<double>(1, 1)) > 5) return {0, 0};
    std::vector<cv::Point2f> srcPts = {center_point};
    std::vector<cv::Point2f> dstPts;
    cv::perspectiveTransform(srcPts, dstPts, H);
    return cv::Point((int)dstPts[0].x, (int)dstPts[0].y);
}

void SaveRawMatchResult(std::string& image_path,const cv::Mat& realtime_image,const cv::Mat& reference_image,
                        std::vector<cv::Point2f>& source_points, std::vector<cv::Point2f>& target_points,
                        const std::vector<cv::Point2f>* realtime_keypoints,
                        const std::vector<cv::Point2f>* reference_keypoints)
{
    if (realtime_image.empty() || reference_image.empty()) return;

    int      canvas_h = std::max(realtime_image.rows, reference_image.rows);
    int      canvas_w = realtime_image.cols + reference_image.cols;
    cv::Mat  canvas   = cv::Mat::zeros(canvas_h, canvas_w, CV_8UC3);
    realtime_image.copyTo(canvas(cv::Rect(0, 0, realtime_image.cols, realtime_image.rows)));
    reference_image.copyTo(canvas(cv::Rect(realtime_image.cols, 0, reference_image.cols, reference_image.rows)));

    // 先画全部检测到的特征点（蓝橙色小圆，半径2），在连线和匹配点之下
    cv::Scalar kpt_color(255, 128, 0);
    if (realtime_keypoints)
        for (const auto& pt : *realtime_keypoints)
            cv::circle(canvas, pt, 2, kpt_color, -1);
    if (reference_keypoints)
        for (const auto& pt : *reference_keypoints)
            cv::circle(canvas, cv::Point2f(pt.x + realtime_image.cols, pt.y), 2, kpt_color, -1);

    cv::Scalar color(0, 200, 255);
    for (size_t i = 0; i < source_points.size(); ++i)
    {
        cv::Point2f pt1 = source_points[i];
        cv::Point2f pt2 = cv::Point2f(target_points[i].x + realtime_image.cols, target_points[i].y);
        cv::line(canvas, pt1, pt2, color, 1, cv::LINE_AA);
        cv::circle(canvas, pt1, 3, color, -1);
        cv::circle(canvas, pt2, 3, color, -1);
    }

    cv::putText(canvas, "Realtime (Camera)",  cv::Point(10, 25),                    cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(255,255,255), 2);
    cv::putText(canvas, "Reference (DOM)",    cv::Point(realtime_image.cols+10, 25), cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(255,255,255), 2);
    std::string stats = "Keypoints: " + std::to_string(realtime_keypoints ? realtime_keypoints->size() : 0)
                      + " | Raw matches: " + std::to_string(source_points.size());
    cv::putText(canvas, stats, cv::Point(10, canvas_h - 10), cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(0,200,255), 2);

    try { cv::imwrite(image_path, canvas); }
    catch (const cv::Exception& ex) { std::cerr << "SaveRawMatchResult error: " << ex.what() << std::endl; }
}

void SaveInlierMatchResult(std::string& image_path,const cv::Mat& realtime_image,const cv::Mat& reference_image,
                           std::vector<cv::Point2f>& source_points, std::vector<cv::Point2f>& target_points,
                           cv::Mat& mask)
{
    if (realtime_image.empty() || reference_image.empty()) return;

    int     canvas_h = std::max(realtime_image.rows, reference_image.rows);
    int     canvas_w = realtime_image.cols + reference_image.cols;
    cv::Mat canvas   = cv::Mat::zeros(canvas_h, canvas_w, CV_8UC3);
    realtime_image.copyTo(canvas(cv::Rect(0, 0, realtime_image.cols, realtime_image.rows)));
    reference_image.copyTo(canvas(cv::Rect(realtime_image.cols, 0, reference_image.cols, reference_image.rows)));

    int inlier_count = 0;
    for (size_t i = 0; i < source_points.size(); ++i)
    {
        bool       is_inlier = (!mask.empty() && mask.at<uchar>(i) != 0);
        cv::Point2f pt1      = source_points[i];
        cv::Point2f pt2      = cv::Point2f(target_points[i].x + realtime_image.cols, target_points[i].y);
        cv::Scalar  color    = is_inlier ? cv::Scalar(0, 255, 0) : cv::Scalar(0, 0, 255);
        if (is_inlier) { cv::line(canvas, pt1, pt2, color, 1, cv::LINE_AA); inlier_count++; }
        cv::circle(canvas, pt1, 3, color, -1);
        cv::circle(canvas, pt2, 3, color, -1);
    }

    cv::putText(canvas, "Realtime (Camera)",  cv::Point(10, 25),                    cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(255,255,255), 2);
    cv::putText(canvas, "Reference (DOM)",    cv::Point(realtime_image.cols+10, 25), cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(255,255,255), 2);
    std::string stats = "Inliers: " + std::to_string(inlier_count) + " / " + std::to_string(source_points.size());
    cv::putText(canvas, stats, cv::Point(10, canvas_h - 10), cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(0,255,255), 2);

    try { cv::imwrite(image_path, canvas); }
    catch (const cv::Exception& ex) { std::cerr << "SaveInlierMatchResult error: " << ex.what() << std::endl; }
}

void SaveShowTransformResult(std::string& image_path,const cv::Mat& realtime_image,
                            const cv::Mat& reference_image,const cv::Mat& homography_mat)
{
    auto realtime_image11  = realtime_image.clone();
    auto reference_image11 = reference_image.clone();

    auto shrink = realtime_image11.cols / 4;
    std::vector<cv::Point2f> obj_corners(5), scene_corners(5);
    obj_corners[0] = cv::Point(shrink,                       shrink);
    obj_corners[1] = cv::Point(realtime_image11.cols - shrink, shrink);
    obj_corners[2] = cv::Point(realtime_image11.cols - shrink, realtime_image11.rows - shrink);
    obj_corners[3] = cv::Point(shrink,                       realtime_image11.rows - shrink);
    obj_corners[4] = cv::Point(realtime_image11.cols / 2,      realtime_image11.rows / 2);
    perspectiveTransform(obj_corners, scene_corners, homography_mat);

    cv::line(realtime_image11, obj_corners[0], obj_corners[1], cv::Scalar(0,255,0), 1);
    cv::line(realtime_image11, obj_corners[1], obj_corners[2], cv::Scalar(0,255,0), 1);
    cv::line(realtime_image11, obj_corners[2], obj_corners[3], cv::Scalar(0,255,0), 1);
    cv::line(realtime_image11, obj_corners[3], obj_corners[0], cv::Scalar(0,255,0), 1);
    cv::line(realtime_image11, cv::Point(0,0),                    cv::Point(realtime_image11.cols, realtime_image11.rows), cv::Scalar(0,255,0), 1);
    cv::line(realtime_image11, cv::Point(0, realtime_image11.rows), cv::Point(realtime_image11.cols, 0),                   cv::Scalar(0,255,0), 1);

    int centerX = realtime_image11.cols / 2;
    int centerY = realtime_image11.rows / 2;

    auto drawDashedLine = [](cv::Mat& img, cv::Point p1, cv::Point p2, cv::Scalar color, int thickness = 1, int dash = 10, int gap = 6)
    {
        cv::LineIterator it(img, p1, p2, 8);
        int seg = dash + gap;
        for (int i = 0; i < it.count; i++, ++it)
            if (i % seg < dash)
                cv::line(img, it.pos(), it.pos(), color, thickness);
    };
    drawDashedLine(reference_image11, cv::Point(centerX, 0),                  cv::Point(centerX, reference_image11.rows), cv::Scalar(0,0,255));
    drawDashedLine(reference_image11, cv::Point(0, centerY),                  cv::Point(reference_image11.cols, centerY), cv::Scalar(0,0,255));

    cv::line(reference_image11, scene_corners[0], scene_corners[1], cv::Scalar(0,255,0), 1);
    cv::line(reference_image11, scene_corners[1], scene_corners[2], cv::Scalar(0,255,0), 1);
    cv::line(reference_image11, scene_corners[2], scene_corners[3], cv::Scalar(0,255,0), 1);
    cv::line(reference_image11, scene_corners[3], scene_corners[0], cv::Scalar(0,255,0), 1);
    cv::line(reference_image11, scene_corners[0], scene_corners[2], cv::Scalar(0,255,0), 1);
    cv::line(reference_image11, scene_corners[1], scene_corners[3], cv::Scalar(0,255,0), 1);

    cv::Mat canvas = cv::Mat::zeros(realtime_image11.rows, realtime_image11.cols * 2, CV_8UC3);
    realtime_image11.copyTo(canvas(cv::Rect(0, 0, realtime_image11.cols, realtime_image11.rows)));
    reference_image11.copyTo(canvas(cv::Rect(realtime_image11.cols, 0, realtime_image11.cols, realtime_image11.rows)));

    cv::putText(canvas, "Realtime (Camera)",  cv::Point(10, 25),                    cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(255,255,255), 2);
    cv::putText(canvas, "Reference (DOM)",    cv::Point(realtime_image11.cols+10, 25), cv::FONT_HERSHEY_SIMPLEX, 0.8, cv::Scalar(255,255,255), 2);

    char center_text[128];
    snprintf(center_text, sizeof(center_text),
             "Center: (%.1f, %.1f)  ->  (%.1f, %.1f)",
             obj_corners[4].x, obj_corners[4].y, scene_corners[4].x, scene_corners[4].y);
    cv::putText(canvas, center_text, cv::Point(10, canvas.rows - 10), cv::FONT_HERSHEY_SIMPLEX, 0.7, cv::Scalar(0,255,255), 2);
    cv::imwrite(image_path, canvas);
}

int LoadChangeKind(const string& kind_json_path)
{
    std::ifstream ifs(kind_json_path);
    if (!ifs.is_open()) {
        std::cerr << "[Error] Cannot open json file: " << kind_json_path << std::endl;
        return -1;
    }

    try {
        nlohmann::json root;
        ifs >> root;

        if (!root.is_array()) {
            std::cerr << "[Error] Json root is not an array" << std::endl;
            return -1;
        }

        m_change_kinds.clear();
        for (const auto& item : root) {
            if (!item.is_object()) continue;

            ChangeKind kind;

            if (item.contains("Id") && item["Id"].is_number_integer()) {
                kind.id = item["Id"].get<int>();
            } else {
                std::cerr << "[Warning] Missing or invalid 'Id' in ChangeKind entry" << std::endl;
                continue;
            }

            if (item.contains("Name") && item["Name"].is_string()) {
                kind.name = item["Name"].get<string>();
            } else {
                kind.name = "Unknown";
            }

            if (item.contains("Color") && item["Color"].is_array() && item["Color"].size() == 3) {
                auto color_arr = item["Color"];
                kind.color = cv::Scalar(color_arr[2].get<int>(),
                                   color_arr[1].get<int>(),
                                   color_arr[0].get<int>());
            } else {
                kind.color = cv::Scalar(0, 0, 255);
            }

            m_change_kinds.push_back(kind);
        }

        return m_change_kinds.empty() ? -1 : 0;
    } catch (const nlohmann::detail::exception& e) {
        std::cerr << "[Error] Failed to parse json: " << e.what() << std::endl;
        return -1;
    }
}

cv::Scalar GetKindColor(int class_id)
{
    if (class_id >= 0 && class_id < (int)m_change_kinds.size()) {
        return m_change_kinds[class_id].color;
    }
    return cv::Scalar(255, 255, 255);
}

string GetKindName(int class_id)
{
    if (class_id >= 0 && class_id < (int)m_change_kinds.size()) {
        return m_change_kinds[class_id].name;
    }
    return "Unknown";
}

// ── 文本日志通道 ──────────────────────────────────────────────────────────────
namespace
{
    struct TextLogState
    {
        std::mutex mtx;
        std::unique_ptr<TextTransferJetson> transfer;
        int sendPort = 8888; // Jetson -> 地面端
        int recvPort = 6666; // 地面端 -> Jetson
        bool consoleEcho = true;
        bool firstSent = false; // 第一条日志用 "clearlog:"
    };

    TextLogState& LogState()
    {
        static TextLogState s; // C++11 起线程安全初始化
        return s;
    }

    // 调用方必须已持有 s.mtx。首次建立连接后等待 zmq 握手（slow joiner），
    // 保证第一条消息不丢。这个等待只发生一次，且在持锁状态下，其他线程的日志会排队等它。
    void EnsureTransferLocked(TextLogState& s)
    {
        if (s.transfer) return;
        s.transfer = std::make_unique<TextTransferJetson>(s.sendPort, s.recvPort);
        std::this_thread::sleep_for(std::chrono::milliseconds(1333));
    }
} // namespace

void InitTextLog(int sendPort, int recvPort, bool consoleEcho)
{
    auto& s = LogState();
    std::lock_guard<std::mutex> lock(s.mtx);
    s.consoleEcho = consoleEcho;
    if (s.transfer)
    {
        if (s.sendPort != sendPort || s.recvPort != recvPort)
        {
            std::cerr << "[Warn] InitTextLog: channel already created with ports "
                << s.sendPort << "/" << s.recvPort << ", ignore " << sendPort << "/" << recvPort << std::endl;
        }
        return;
    }
    s.sendPort = sendPort;
    s.recvPort = recvPort;
    EnsureTransferLocked(s);
}

void OutputLog(const std::string& log_info, bool with_enter)
{
    auto& s = LogState();
    std::lock_guard<std::mutex> lock(s.mtx);

    if (s.consoleEcho)
    {
        std::cout << log_info;
        if (with_enter)
        {
            std::cout << std::endl;
        }
    }

    EnsureTransferLocked(s);
    if (!s.firstSent)
    {
        s.firstSent = true;
        s.transfer->sendMessage("clearlog:" + log_info);
        return;
    }
    s.transfer->sendMessage("addlog:" + log_info + std::string(with_enter ? "\n" : ""));
}

bool SendTextMessage(const std::string& message)
{
    auto& s = LogState();
    std::lock_guard<std::mutex> lock(s.mtx);
    if (!s.transfer) return false;
    s.transfer->sendMessage(message);
    return true;
}
