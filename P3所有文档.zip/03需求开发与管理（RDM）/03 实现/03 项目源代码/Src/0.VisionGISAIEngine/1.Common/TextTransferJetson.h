#ifndef TEXTTRANSFERJETSON_H
#define TEXTTRANSFERJETSON_H

#include <zmq.hpp>
#include <string>
#include <thread>
#include <mutex>
#include <functional>

class TextTransferJetson {
public:
    TextTransferJetson(int send_port, int recv_port);
    ~TextTransferJetson();

    void sendMessage(const std::string& message);
    void startReceiving();
    void setMessageCallback(std::function<void(const std::string&)> callback);

private:
    void receiveLoop();

    zmq::context_t context_;
    zmq::socket_t sender_;
    zmq::socket_t receiver_;
    std::mutex send_mutex_;
    std::thread receive_thread_;
    bool running_;
    std::function<void(const std::string&)> message_callback_;
};

#endif // TEXTTRANSFERJETSON_H