﻿#pragma once
// 机载端日志出口：printf 风格格式化后交给 OutputLog（原 6.ChangeDetect/Core/ChangeDetectLog.h，提到引擎里，目标跟踪也用）。
// OutputLog 会（1）按 InitTextLog 的 consoleEcho 回显到本机控制台，（2）经文本通道发给地面端
// （第一条 "clearlog:"，之后 "addlog:"），地面端「机载单元」窗口的日志框显示的就是这些。
// 格式串里自带的 \n 原样保留（这里不再额外加换行），所以原来一行拆成几次 printf 的写法不用改。
// 用之前必须先调 InitTextLog（整个进程只调一次）；没调的话 OutputLog 会按默认端口 8888/6666 临时建通道。
#include <cstdarg>
#include <cstdio>
#include <string>
#include <vector>

#include "EngineFunction.h"   // OutputLog

#if defined(__GNUC__)
__attribute__((format(printf, 1, 2)))
#endif
inline void LogPrintf(const char* fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    va_list ap2;
    va_copy(ap2, ap);
    char buf[1024];
    const int n = std::vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (n < 0) { va_end(ap2); return; }
    if (static_cast<size_t>(n) < sizeof(buf)) {
        va_end(ap2);
        OutputLog(std::string(buf, static_cast<size_t>(n)), false);
        return;
    }
    std::vector<char> big(static_cast<size_t>(n) + 1);   // 一行超过 1023 字节时走这里，不截断
    std::vsnprintf(big.data(), big.size(), fmt, ap2);
    va_end(ap2);
    OutputLog(std::string(big.data(), static_cast<size_t>(n)), false);
}
