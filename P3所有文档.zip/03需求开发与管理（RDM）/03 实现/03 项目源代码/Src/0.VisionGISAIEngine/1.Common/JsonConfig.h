// 配置 JSON 读取辅助（header-only：调用方直接包含，JSON 对象不跨 DLL 边界传递）。
//
// 【使用规则】本头文件会把 json.hpp（约 2.4 万行）带进包含它的翻译单元：
//   只在 .cpp 里包含，不要在任何头文件里包含；一个模块的配置读取集中在一个 *Config.cpp 里即可。
//
// 用法：
//   nlohmann::json p;  std::string err;
//   if (!LoadJsonNode("XxxConfig.json", "ProjectParam", p, err)) { ... }
//   double fx = p.value("Fx", 1732.48);                 // 缺省键取默认值；类型不符会抛 nlohmann::json::exception
//   // 或者用 JsonRead：缺省键保持默认值，类型不符时返回 false 并在 err 里写出键名
//   double fy = 1723.01;  if (!JsonRead(p, "FocalLengthYPx", fy, err)) { ... }
//   std::string dir = JsonPath(p, "CameraDir");         // 字符串，或 {"Windows": "...", "Linux": "...", "Jetson": "..."}
//
// 文件格式：UTF-8（带不带 BOM 都行），允许 // 和 /* */ 注释；不允许尾随逗号。
#pragma once

#include <fstream>
#include <iterator>
#include <string>

#include "EngineFunction.h"
#include "json.hpp"

// 失败返回 false 并填 err（文件打不开 / 解析失败 / 节点不存在）。
inline bool LoadJsonNode(const std::string& fileName, const char* node, nlohmann::json& out, std::string& err)
{
    const std::string path = GetExeDir().string() + fileName;
    std::ifstream ifs(path, std::ios::binary);
    if (!ifs.is_open()) { err = "Cannot open " + fileName + ": " + path; return false; }

    std::string text((std::istreambuf_iterator<char>(ifs)), std::istreambuf_iterator<char>());
    if (text.compare(0, 3, "\xEF\xBB\xBF") == 0) text.erase(0, 3);   // 跳过 UTF-8 BOM（记事本保存的文件常带）

    try {
        const nlohmann::json root = nlohmann::json::parse(text, nullptr, /*allow_exceptions=*/true, /*ignore_comments=*/true);
        if (!root.is_object() || !root.contains(node) || !root[node].is_object()) {
            err = std::string("Node \"") + node + "\" not found in " + fileName;
            return false;
        }
        out = root[node];
        return true;
    } catch (const nlohmann::json::exception& e) {
        err = "Parse " + fileName + " failed: " + e.what();
        return false;
    }
}

// 读取键 key 到 v：键不存在或为 null 时保持 v 不变（即默认值）并返回 true；
// 类型无法转换时返回 false，err 写出键名。T 可以是 bool / int / double / std::string 等。
template <class T>
inline bool JsonRead(const nlohmann::json& p, const char* key, T& v, std::string& err)
{
    const auto it = p.find(key);
    if (it == p.end() || it->is_null()) return true;
    try {
        v = it->template get<T>();
        return true;
    } catch (const nlohmann::json::exception&) {
        err = std::string("key \"") + key + "\" has an unexpected type";
        return false;
    }
}

// 路径字段既可以是字符串，也可以按平台分开写。取不到返回空串。
// 返回值已从 JSON 的 UTF-8 转成本地编码（Windows 下含中文的目录才能被 std::filesystem / cv::imread 正确打开）。
inline std::string JsonPath(const nlohmann::json& p, const char* key)
{
    const auto it = p.find(key);
    if (it == p.end()) return {};
    const nlohmann::json& v = *it;

    std::string s;
    if (v.is_string()) {
        s = v.get<std::string>();
    } else if (v.is_object()) {
#ifdef _WIN32
        s = v.value("Windows", std::string());
#else
        s = v.contains("Linux") ? v.value("Linux", std::string()) : v.value("Jetson", std::string());
#endif
    }
    return Utf8ToLocal(s);
}
