﻿#pragma once
#include <filesystem>

#include "opencv2/opencv.hpp"

using std::string;
using std::vector;
using cv::Mat;

#include "MacroEnumStruct.h"

extern std::vector<ChangeKind> m_change_kinds;

VGA_API std::vector<std::string> SplitString(const std::string &str, char delimiter);

VGA_API std::string ReplaceAll(std::string &str, std::string oldStr, std::string newStr);

VGA_API std::string DoubleToString(double value,int precision);

VGA_API std::string FillZeroAsPrefix(int number, int bit_count);

// ── 成像几何 ──────────────────────────────────────────────────────────────────
// 像素焦距（像素）：由某方向的视场角(度)和该方向的像素数得到
inline double FocalPxFromFov(double fovDeg, int pixels) { return pixels / (2.0 * std::tan(fovDeg * CV_PI / 360.0)); }
// 地面分辨率 GSD（米/像素）= 离地高度 / 像素焦距
inline double GroundResolution(double altitude, double focalPx) { return altitude / focalPx; }

// ── 帧文件名 POS 解析 ─────────────────────────────────────────────────────────
// 文件名由 '_' 分隔的若干"键+数值"组成，顺序不限；首段若是 ≥6 位纯数字，取前 6 位作 hhmmss。
// 例："165209_RtkLon118.107573_RtkLat32.511040_RelAlt-20.59_Roll0.00_Pitch0.00_Yaw108.16.jpg"
// 识别的键（大小写敏感，精确匹配）：
//   经度 RtkLon/GpsLon/Longitude/Lon    纬度 RtkLat/GpsLat/Latitude/Lat
//   相对（离地）高度 RelAlt/RelHeight   （RtkAlt / GpsAlt / GpsHgt 已废弃，不再识别）
//   Roll / Pitch / Yaw(或 YawTruth) / YawDelta
struct FramePos
{
    int    tsec   = -1;                 // 距当天 00:00 的秒数；无时间前缀为 -1
    double lon = NAN, lat = NAN;        // 度
    double relAlt = NAN;                // 相对（离地）高度，米
    double roll = 0, pitch = 0;         // 度
    double yaw = NAN;                   // 度，自正北顺时针
    double yawDelta = 0;                // 度
};

// 解析文件名（可带目录和扩展名）。lon 与 lat 都解析到才返回 true；
// 其余字段没出现时保持默认值（NaN 或 0），是否必需由调用方用 std::isfinite 检查。
VGA_API bool ParseFramePos(const std::string& fileName, FramePos& out);

// ── 路径编码 ──────────────────────────────────────────────────────────────────
// 约定：本库对外的 std::string 路径一律是"本地编码"（Windows = 系统 ANSI 代码页，如 GBK；Linux / Jetson = UTF-8），
// 这样才能直接交给 std::filesystem / cv::imread / std::ifstream。
// JSON 文件是 UTF-8，GDAL 在 Windows 下也要 UTF-8 文件名，边界处用下面两个函数转换。
// Linux 下两者都是原样返回。无法用本地代码页表示的字符会变成 '?'（Windows）。
VGA_API std::string Utf8ToLocal(const std::string& utf8);
VGA_API std::string LocalToUtf8(const std::string& local);

VGA_API std::filesystem::path GetExeDir();

VGA_API cv::Point MapCenterByHomography(cv::Mat& H, cv::Point center_point);

VGA_API void SaveRawMatchResult(std::string& image_path,const cv::Mat& realtime_image,const cv::Mat& reference_image,
                                std::vector<cv::Point2f>& source_points, std::vector<cv::Point2f>& target_points,
                                const std::vector<cv::Point2f>* realtime_keypoints  = nullptr,
                                const std::vector<cv::Point2f>* reference_keypoints = nullptr);

VGA_API void SaveInlierMatchResult(std::string &image_path,const cv::Mat &realtime_image,const cv::Mat &reference_image,
                     std::vector<cv::Point2f>& source_points, std::vector<cv::Point2f>& target_points, cv::Mat& mask);

VGA_API void SaveShowTransformResult(std::string &image_path,const cv::Mat &realtime_image11,const cv::Mat &reference_image11,const cv::Mat& homography_mat);

int LoadChangeKind(const std::string& kind_json_path);

[[nodiscard]] cv::Scalar GetKindColor(int class_id);

[[nodiscard]] std::string GetKindName(int class_id);

VGA_API void InitTextLog(int sendPort, int recvPort, bool consoleEcho);

VGA_API void OutputLog(const std::string& log_info, bool with_enter = true);

VGA_API bool SendTextMessage(const std::string& message);