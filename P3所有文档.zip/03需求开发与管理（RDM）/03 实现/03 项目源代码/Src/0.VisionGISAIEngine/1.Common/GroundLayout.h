﻿#pragma once
// 机载端 → 地面端 下传文件的目录约定（header-only，只有常量）。
//
// 机载端把要下传的文件写在 <输出目录>/GroundEnd/<子目录>/ 下，FileSender 以 <输出目录>/GroundEnd 为根，
// 发出去的相对路径是 "<子目录>/<文件名>"，地面端 FileReceiver 按这个相对路径存到 <任务目录>/<子目录>/。
// 所以这里的子目录名必须和地面端读取的目录名一致：
//   ChangeDetect     地面端 ClientMainWindow_3ChangeDetect.cpp 等读 <任务目录>/ChangeDetect
//   TargetRecognize  地面端 ClientMainWindow_2TargetTrack.cpp 读 <任务目录>/TargetRecognize（TaskManagement.cpp 建目录）
// 要改名，这里改一处，同时改地面端上面几处。
//
// 变化检测和目标识别并列，各用一个常量；以后再加别的下传内容，在这里加一行。
#include <string>

inline constexpr const char* kGroundRootDir            = "GroundEnd";         // 下传根目录（FileSender 的 rootDir 就是 <输出目录>/GroundEnd）
inline constexpr const char* kGroundSubChangeDetect    = "ChangeDetect";      // 变化检测的矢量结果
inline constexpr const char* kGroundSubTargetRecognize = "TargetRecognize";   // 目标识别的 JPG + TXT

// 下传时的相对路径："<子目录>/<文件名>"（用 '/'，地面端按这个路径存盘）
inline std::string GroundRelPath(const char* subDir, const std::string& fileName)
{
    return std::string(subDir) + "/" + fileName;
}
