#include "TextTransferJetson.h"
#include <QtCore/QString>
#include <QtCore/QDebug>
#include <iostream>
#include <QtCore/qlogging.h>

#include "MacroEnumStruct.h"

TextTransferJetson::TextTransferJetson(int send_port, int recv_port)
        : context_(1), sender_(context_, ZMQ_PUSH), receiver_(context_, ZMQ_PULL), running_(false) {
    sender_.set(zmq::sockopt::sndhwm, 1000);
    receiver_.set(zmq::sockopt::rcvhwm, 1000);
    std::string send_endpoint = "tcp://*:" + std::to_string(send_port);
    std::string recv_endpoint = "tcp://*:" + std::to_string(recv_port);
    try {
        sender_.bind(send_endpoint);
        receiver_.bind(recv_endpoint);
        qDebug() << "Text sender: " << QString::fromLocal8Bit(send_endpoint.data(),send_endpoint.size()) << __LINE__ << "@" << __FILENAME__;
        qDebug() << "Text receiver: " << QString::fromLocal8Bit(recv_endpoint.data(),recv_endpoint.size()) << __LINE__ << "@" << __FILENAME__;
    } catch (const zmq::error_t& e) {
        std::cerr << "ZMQ Error: " << e.what() << std::endl;
    }
}

TextTransferJetson::~TextTransferJetson() {
    running_ = false;
    if (receive_thread_.joinable()) {
        receive_thread_.join();
    }
}

void TextTransferJetson::sendMessage(const std::string& message) {
    std::lock_guard<std::mutex> lock(send_mutex_);
    // std::cout << "Attempting to send message of size: " << message.size() << std::endl;
    if (message.empty()) {
        std::cerr << "Error: Empty message" << std::endl;
        return;
    }
    if (message.size() > 1024 * 1024) {
        std::cerr << "Error: Message too large (" << message.size() << " bytes)" << std::endl;
        return;
    }
    try {
        zmq::message_t msg(message.size());
        std::memcpy(msg.data(), message.data(), message.size());
        // std::cout << "Message constructed successfully" << std::endl;
        if (!sender_.send(msg, zmq::send_flags::dontwait)) {
            static auto last_log_time = std::chrono::steady_clock::now() - std::chrono::seconds(10); // 保证首次调用立即打印一次
            auto now = std::chrono::steady_clock::now();
            if (std::chrono::duration_cast<std::chrono::seconds>(now - last_log_time).count() >= 10)
            {
                last_log_time = now;
                std::cerr << "Failed to send message: queue full or no receiver" << std::endl;
            }
            return;
        }
        std::cout << "Sent message: " << message << std::endl;
    } catch (const zmq::error_t& e) {
        std::cerr << "Send error: " << e.what() << std::endl;
    }
}

void TextTransferJetson::startReceiving() {
    running_ = true;
    receive_thread_ = std::thread(&TextTransferJetson::receiveLoop, this);
}

void TextTransferJetson::setMessageCallback(std::function<void(const std::string&)> callback) {
    message_callback_ = callback;
}

void TextTransferJetson::receiveLoop() {
    while (running_) {
        zmq::message_t msg;
        try {
            if (receiver_.recv(msg, zmq::recv_flags::dontwait)) {
                std::string received_data(static_cast<char*>(msg.data()), msg.size());
                std::cout << "Received message: " << received_data << std::endl;
                if (message_callback_) {
                    message_callback_(received_data);
                }
            }
        } catch (const zmq::error_t& e) {
            std::cerr << "Receive error: " << e.what() << std::endl;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}