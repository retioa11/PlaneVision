﻿#include "AtomicFile.h"

#include <fstream>
#include <system_error>

namespace fs = std::filesystem;

bool WriteFileAtomic(const fs::path& path, const void* data, std::size_t size, std::string* err)
{
    auto fail = [&](const std::string& msg) { if (err) *err = msg; return false; };
    if (path.empty()) return fail("WriteFileAtomic：路径为空");
    if (size > 0 && data == nullptr) return fail("WriteFileAtomic：数据指针为空: " + path.string());

    fs::path tmp = path;
    tmp += ".tmp";
    {
        std::ofstream ofs(tmp, std::ios::binary | std::ios::trunc);
        if (!ofs.is_open()) return fail("打不开临时文件: " + tmp.string());
        if (size > 0) ofs.write(static_cast<const char*>(data), static_cast<std::streamsize>(size));
        ofs.flush();
        if (!ofs.good()) {
            ofs.close();
            std::error_code ec;
            fs::remove(tmp, ec);
            return fail("写文件失败（磁盘满？）: " + tmp.string());
        }
    }   // 离开作用域时关闭文件，rename 前必须已关闭

    std::error_code ec;
    fs::rename(tmp, path, ec);
    if (ec) {
        std::error_code ec2;
        fs::remove(tmp, ec2);
        return fail("rename 失败: " + tmp.string() + " -> " + path.string() + "（" + ec.message() + "）");
    }
    return true;
}
