﻿#pragma once

// https://blog.csdn.net/anlian523/article/details/102768496
#ifdef WIN32
#define __FILENAME__ (strrchr("\\" __FILE__, '\\') + 1)
#else
#define __FILENAME__ (strrchr("/" __FILE__, '/') + 1)
#endif

#ifdef WIN32
#define VGA_API __declspec(dllexport)
#else
#define VGA_API __attribute__((visibility("default")))
#endif

#include <string>
#include <opencv2/opencv.hpp>

struct ChangeKind {
    int id;
    std::string name;
    cv::Scalar color;
};

struct DetectObj {
    int class_id;
    float score;
    cv::Rect box;
    cv::Mat mask;
    std::string class_name;
};
