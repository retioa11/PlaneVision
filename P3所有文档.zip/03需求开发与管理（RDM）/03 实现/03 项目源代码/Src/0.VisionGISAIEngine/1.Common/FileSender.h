﻿#pragma once
// 文件下传（Jetson → 地面端）：ZMQ PUSH 绑定本机端口，地面端 PULL 连上来收。
//
// 协议（与地面端 FileReceiver 一致，接收端不用改）：每个文件 = 两帧，先相对路径（字节串），再文件内容。
// 与旧版的区别：
//   - 两帧作为一条多段消息（SNDMORE）发出，ZMQ 保证两帧一起、发给同一个接收者，不会路径给了 A、内容给了 B。
//   - Init 返回 bool；绑定失败（端口被占）只返回错误原因，不再 exit。
//   - 不存在的文件直接跳过（只计数，不报错）：无变化帧没有 shp 等文件，不再刷"打开失败"。
//   - 实例对象，端口和根目录由 Init 传入，不依赖全局变量；SendFile 内部加锁，多线程可调。
//   - 关闭时 linger 2 秒：没有接收者时不会在退出时一直卡住。
// 发送用 dontwait：没有接收者连上（或发送队列满）时文件被丢弃，返回 Failed 并带原因，不会阻塞流水线。
#include <memory>
#include <string>
#include <vector>

#include "MacroEnumStruct.h"

#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable : 4251)   // unique_ptr<Impl> 成员不需要导出
#endif

class VGA_API FileSender
{
public:
    enum class Status { Sent, Missing, Failed };

    struct Result
    {
        int sent    = 0;   // 已交给 ZMQ 发送队列
        int missing = 0;   // 文件不存在 / 不是普通文件（正常情况，例如无变化帧没有 shp）
        int failed  = 0;   // 路径非法、读文件失败、没有接收者 / 队列满、ZMQ 异常
    };

    FileSender();
    ~FileSender();
    FileSender(const FileSender&)            = delete;
    FileSender& operator=(const FileSender&) = delete;

    // 绑定 tcp://*:port，rootDir 是相对路径的根（发送时 绝对路径 = rootDir / 相对路径）。
    // 失败返回 false，err 写原因；可重复调用（先关闭上一次的）。
    // sendHwm > 0：发送队列上限（单位是 ZMQ 消息段，一个文件占 2 段：路径 + 内容），在 bind 之前设置；
    //   0 = 用 ZMQ 默认（1000 段）。地面端没收时文件内容在本机内存里排队，内存紧的机载端建议设小（如 32 = 约 16 个文件）。
    //   队列满时 SendFile 返回 Failed("NoReceiver")，由调用方决定重试，不会阻塞。
    bool Init(int port, const std::string& rootDir, std::string* err = nullptr, int sendHwm = 0);
    void Close();
    bool IsReady() const;

    // true：每个成功发送的文件打一行日志（旧版的行为）；默认 false，只在失败时打印。
    void SetVerbose(bool on);

    // 发一个文件。relPath 是相对 rootDir 的路径，同时也是发给地面端的路径（地面端按它存盘）。
    // relPath 不能是绝对路径，也不能含 ".."。why 在非 Sent 时写原因：
    //   NotReady / BadPath / Missing / ReadFailed / NoReceiver / SendPartial / ZmqError:...
    Status SendFile(const std::string& relPath, std::string* why = nullptr);

    // 依次发多个文件，返回统计。失败的文件会各打印一行日志，不存在的不打印。
    Result SendFiles(const std::vector<std::string>& relPaths);

private:
    struct Impl;
    std::unique_ptr<Impl> m_impl;
};

#ifdef _MSC_VER
#pragma warning(pop)
#endif
