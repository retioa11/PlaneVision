﻿#pragma once
// 地面端下发的任务参数：GroundEndConfig.json（地面端在启动机载程序前通过 SFTP 写到机载程序所在目录，即 exe 旁边）。
// 地面端写入的键见 ClientAndLabel 的 TaskManagement.cpp：
//   GuaranteedData / CalculateMode / SaveDirName / MinWorkHeight / MaxWorkHeight / InvokeInterval /
//   Jts2StaFilePort / Sta2JtsTextPort / Jts2StaTextPort / PayloadLogOutput
//
// 只解析、不改文件。必需键：SaveDirName（机载端用它命名输出目录）；其余键没写、或类型不对，都当作"地面端没给"（std::nullopt / 空串），
// 由调用方决定回退到自己的配置。
// 文件格式：UTF-8（带不带 BOM 都行），允许 // 和 /* */ 注释。
#include <optional>
#include <string>

#include "MacroEnumStruct.h"

struct GroundEndConfig
{
    std::string saveDirName;                 // 必需。输出目录名（本地编码）；不能为空，不能含路径分隔符或 ".."
    std::string guaranteedData;              // 底图（T1）路径，本地编码；没给 = 空串

    std::optional<double> minWorkHeight;     // 相对（离地）高度范围，米
    std::optional<double> maxWorkHeight;
    std::optional<double> invokeInterval;    // 地面端界面"时间间隔"的数值；单位以地面端界面为准，用之前先确认

    std::optional<int> jts2StaFilePort;      // 机载 → 地面 文件通道端口（FileSender 绑定、地面端 FileReceiver 连接）
    std::optional<int> sta2JtsTextPort;      // 地面 → 机载 文本通道端口
    std::optional<int> jts2StaTextPort;      // 机载 → 地面 文本通道端口
};

// path 为空 = exe 旁边的 GroundEndConfig.json。失败返回 false，err 写原因（打不开 / 解析失败 / SaveDirName 缺失或不合法）。
VGA_API bool LoadGroundEndConfig(GroundEndConfig& out, std::string& err, const std::string& path = "");
