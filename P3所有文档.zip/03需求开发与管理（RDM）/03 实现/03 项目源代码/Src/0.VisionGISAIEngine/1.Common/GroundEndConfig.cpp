﻿#include "GroundEndConfig.h"

#include <filesystem>
#include <fstream>
#include <iterator>

#include "EngineFunction.h"   // GetExeDir / Utf8ToLocal
#include "json.hpp"

namespace fs = std::filesystem;

namespace {

std::optional<double> ReadNumber(const nlohmann::json& root, const char* key)
{
    if (!root.contains(key)) return std::nullopt;
    const nlohmann::json& v = root[key];
    if (!v.is_number()) return std::nullopt;   // 类型不对当作没写
    return v.get<double>();
}

std::optional<int> ReadInt(const nlohmann::json& root, const char* key)
{
    if (!root.contains(key)) return std::nullopt;
    const nlohmann::json& v = root[key];
    if (!v.is_number_integer()) return std::nullopt;
    return v.get<int>();
}

std::string ReadLocalString(const nlohmann::json& root, const char* key)
{
    if (!root.contains(key) || !root[key].is_string()) return std::string();
    return Utf8ToLocal(root[key].get<std::string>());
}

}  // namespace

bool LoadGroundEndConfig(GroundEndConfig& out, std::string& err, const std::string& path)
{
    out = GroundEndConfig();
    err.clear();

    const fs::path file = path.empty() ? (GetExeDir() / "GroundEndConfig.json") : fs::path(path);
    std::ifstream ifs(file, std::ios::binary);
    if (!ifs) { err = "打不开 GroundEndConfig.json: " + file.string(); return false; }
    std::string text((std::istreambuf_iterator<char>(ifs)), std::istreambuf_iterator<char>());
    if (text.compare(0, 3, "\xEF\xBB\xBF") == 0) text.erase(0, 3);

    try {
        const nlohmann::json root = nlohmann::json::parse(text, nullptr, /*allow_exceptions=*/true, /*ignore_comments=*/true);
        if (!root.is_object() || !root.contains("SaveDirName") || !root["SaveDirName"].is_string()) {
            err = "GroundEndConfig.json 里没有字符串类型的 SaveDirName: " + file.string();
            return false;
        }
        out.saveDirName    = Utf8ToLocal(root["SaveDirName"].get<std::string>());
        out.guaranteedData = ReadLocalString(root, "GuaranteedData");
        out.minWorkHeight  = ReadNumber(root, "MinWorkHeight");
        out.maxWorkHeight  = ReadNumber(root, "MaxWorkHeight");
        out.invokeInterval = ReadNumber(root, "InvokeInterval");
        out.jts2StaFilePort = ReadInt(root, "Jts2StaFilePort");
        out.sta2JtsTextPort = ReadInt(root, "Sta2JtsTextPort");
        out.jts2StaTextPort = ReadInt(root, "Jts2StaTextPort");
    } catch (const nlohmann::json::exception& e) {
        err = std::string("解析 GroundEndConfig.json 失败: ") + e.what();
        return false;
    }

    const std::string& n = out.saveDirName;
    if (n.empty() || n.find_first_of("/\\") != std::string::npos || n.find("..") != std::string::npos) {
        err = "SaveDirName 不合法（不能为空，不能含路径分隔符或 ..）: " + n;
        return false;
    }
    return true;
}
