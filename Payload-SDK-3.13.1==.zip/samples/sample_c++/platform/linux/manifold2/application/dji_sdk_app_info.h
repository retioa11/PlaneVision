/**
 ********************************************************************
 * @file    dji_sdk_app_info.h
 * @brief   This is the header file for defining the structure and (exported) function prototypes.
 *
 * @copyright (c) 2018 DJI. All rights reserved.
 *
 * All information contained herein is, and remains, the property of DJI.
 * The intellectual and technical concepts contained herein are proprietary
 * to DJI and may be covered by U.S. and foreign patents, patents in process,
 * and protected by trade secret or copyright law.  Dissemination of this
 * information, including but not limited to data and other proprietary
 * material(s) incorporated within the information, in any form, is strictly
 * prohibited without the express written consent of DJI.
 *
 * If you receive this source code without DJI’s authorization, you may not
 * further disseminate the information, and you must immediately remove the
 * source code and notify DJI of its removal. DJI reserves the right to pursue
 * legal actions against you for any loss(es) or damage(s) caused by your
 * failure to do so.
 *
 *********************************************************************
 */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef DJI_SDK_APP_INFO_H
#define DJI_SDK_APP_INFO_H

/* Includes ------------------------------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/* Exported constants --------------------------------------------------------*/
// ATTENTION: User must goto https://developer.dji.com/user/apps/#all to create your own dji sdk application, get dji sdk application
// information then fill in the application information here.
#define USER_APP_NAME               "AirDect"
#define USER_APP_ID                 "104289"
#define USER_APP_KEY                "318373410613f499bb43c344b248526"
#define USER_APP_LICENSE            "qbSOKJ4ag1b7knJajLLe5zAHYX4ssW0JNvYbNqGzft6ixS0UBLPxBuQN8u4JrvtE9ycYar8L65fdYIQ2HdLSqv0xFxgPdHntzx6VqwsbUavhUHT+QeLsvA5x7Hh4zJVMk2i5RBOq4T8EoHuHnaP3uifImwqCZEBT0Dqte85+/8SVQvct2qSFG7JPEKc3+KpQWP3Kz+OpHIm4qZmtae1KD89FIV26U9Or262rokU0yGwJ+h27r3Ac2YRFHjML/njkoCB8QOfQ807yoN8RcUlWgV33XMbrALAYaKn/4bN+N+pNUcdsMlgLjPNgHQeH8wyd/42TrTOTJ6kJ2o1zTUKEOA=="
#define USER_DEVELOPER_ACCOUNT      "136833764@qq.com"
#define USER_BAUD_RATE              "921600"

/* Exported types ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/


#ifdef __cplusplus
}
#endif

#endif // DJI_SDK_APP_INFO_H
/************************ (C) COPYRIGHT DJI Innovations *******END OF FILE******/
